<template>
  <div class="">
    <h2>我的收藏</h2>
    <el-card style="margin-top:10px">
      <div class="">
        尚无收藏内容
      </div>
    </el-card>
  </div>
</template>
<script >
export default {
  data () {
    return {
    };
  },
  methods: {
  }
}
</script>
<style lang = 'less' scoped >
</style>