<template>
  <div class="player——box">
    <div class="gWidth player_box_ss"
         v-if="!ifBlock">
      <div class="left_box fl">
        <el-card>
          <div class="player_header">
            <div class="player_header_left">
              <h3>{{headerData.name_j}}</h3>
              <p>{{headerData.name_e}}</p>
              <div class="details">
                <dl>
                  <dd v-if="placeLen">
                    <b>俱乐部：</b>{{headerData.place[0].teamID__name_j}}</dd>
                  <dd v-if="placeLen">
                    <b>位置：</b>{{headerData.place[0].place}}</dd>
                  <dd v-if="placeLen">
                    <span v-if="headerData.kind == 1">
                      <b>号码：</b>
                      <span v-if="headerData.place[0].number">{{headerData.place[0].number}}号</span>
                    </span>

                  </dd>
                  <dd>
                    <span v-if="headerData.kind == 1">
                      <b>预计身价：</b>
                      <span>{{headerData.expectedValue}}万英镑</span>
                    </span>
                    <span v-else>
                      <b>首选阵型：</b>
                      <span>{{headerData.firstFormation}}</span>
                    </span>
                  </dd>
                </dl>
                <dl>
                  <dd>
                    <b>国籍：</b>{{headerData.country}}</dd>
                  <dd>
                    <b>年龄：</b>{{age}}岁</dd>
                  <dd>
                    <b>生日：</b>{{headerData.birthday}}</dd>
                </dl>
                <dl>
                  <dd>
                    <b>身高：</b>
                    <span v-if="headerData.tallness">{{headerData.tallness}}CM</span>
                  </dd>
                  <dd>
                    <b>体重：</b>
                    <span v-if="headerData.weight">{{headerData.weight}}KG</span>
                  </dd>
                  <dd>
                    <span v-if="headerData.kind == 1">
                      <b>惯用脚：</b>{{idiomaticFeet[headerData.idiomaticFeet]}}</span>
                    <!-- <span v-else>
                    <b>支教特征：</b>{{idiomaticFeet[headerData.idiomaticFeet]}}</span> -->
                  </dd>

                </dl>
              </div>
            </div>
            <div class="player_header_right">
              <el-image :src="`http://qiuguantx.com/img/player/${headerData.photo}`"></el-image>
            </div>

          </div>
        </el-card>
        <!-- 左下内容 -->
        <el-card class="left_box_bottom">

          <!-- 选项卡 -->
          <el-tabs v-model="activeName"
                   @tab-click="handleClick">
            <el-tab-pane label="转会"
                         name="first"></el-tab-pane>
            <el-tab-pane label="信息统计"
                         name="second"></el-tab-pane>
            <el-tab-pane label="详细数据统计"
                         v-if="playerTj.length"
                         name="third"></el-tab-pane>
            <el-tab-pane label="教练执教球路图"
                         v-if="coachTj.length"
                         name="fourth"></el-tab-pane>
          </el-tabs>
          <!-- 现效力球队 -->
          <div v-if="activeName == 'fourth'">
          </div>

          <div class="kua zhuanh"
               v-else-if="activeName == 'first' ">
            <!-- 转会 -->
            <el-divider content-position="left">
              <h6>转会</h6>
            </el-divider>
            <!-- 教练履历 -->
            <el-table :data="coachTransfer"
                      :row-class-name="tabRowClassName"
                      size="mini"
                      v-if="coachTransfer.length"
                      :header-cell-style="{
    'color': '#000',
       'background-color': 'rgb(131, 162, 202)',
    'font-size':'14px'
}"
                      style="width: 100%">
              <el-table-column prop="toTeamName"
                               align="center"
                               label="教练履历">
                <template slot="header">
                  <div style="color:rgb(248, 51, 71);font-size: 18px;">
                    <b>教练履历</b>
                  </div>
                </template>
                <el-table-column prop="toTeamName"
                                 label="俱乐部"
                                 align="center"
                                 width="">
                  <template slot-scope="scope">
                    <p class="zh_p">
                      <span>
                        <div class="image_div">
                          <el-image :src="'http://qiuguantx.com/img/team/'+scope.row.toTeamImg"></el-image>
                        </div>

                        <router-link target="_blank"
                                     v-if="scope.row.toTeamId"
                                     :to="{name:'lineup',params:{teamID:scope.row.toTeamId}}">{{scope.row.toTeamName}}</router-link>
                      </span>

                    </p>
                  </template>
                </el-table-column>
                <el-table-column prop="transferTime"
                                 label="被任命"
                                 align="center"
                                 width="150"
                                 sortable>
                </el-table-column>
                <el-table-column prop="endTime"
                                 sortable
                                 align="center"
                                 width="150"
                                 label="截止日期">
                </el-table-column>
                <el-table-column prop="duty"
                                 align="center"
                                 width="150"
                                 label="位置">
                  <template slot-scope="scope">
                    <span>{{duty[scope.row.duty]}}</span>
                  </template>
                </el-table-column>
              </el-table-column>
            </el-table>
            <!-- 球员转会 -->
            <el-table :data="playerTransfer"
                      size="mini"
                      v-if="playerTransfer.length"
                      :row-class-name="tabRowClassName"
                      :header-cell-style="{
    'color': '#000',
       'background-color': 'rgb(131, 162, 202)',
    'font-size':'14px'
}"
                      style="width: 100%">
              <el-table-column prop="toTeamName"
                               align="center"
                               label="球员转会">
                <template slot="header">
                  <div style="color:rgb(248, 51, 71);font-size: 18px;">
                    <b>球员转会</b>
                  </div>
                </template>
                <el-table-column prop="transferTime"
                                 label="转会时间"
                                 align="center"
                                 sortable
                                 width="150">
                </el-table-column>
                <el-table-column prop="transferTime"
                                 label="转会详细"
                                 align="center">
                  <template slot-scope="scope">
                    <div class="zh_p">
                      <div class="image_div">
                        <el-image :src="'http://qiuguantx.com/img/team/'+scope.row.fromTeamImg"></el-image>
                      </div>
                      <router-link target="_blank"
                                   v-if="scope.row.fromTeamId"
                                   :to="{name:'lineup',params:{teamID:scope.row.fromTeamId}}">{{scope.row.fromTeamName}}</router-link> &nbsp;&nbsp;&nbsp;
                      <i class="el-icon-right"></i>&nbsp;&nbsp;&nbsp;
                      <router-link target="_blank"
                                   v-if="scope.row.toTeamId"
                                   :to="{name:'lineup',params:{teamID:scope.row.toTeamId}}">{{scope.row.toTeamName}}</router-link>
                      <div class="image_div">
                        <el-image :src="'http://qiuguantx.com/img/team/'+scope.row.toTeamImg"></el-image>
                      </div>
                    </div>
                  </template>
                </el-table-column>
                <el-table-column prop="endTime"
                                 align="center"
                                 width="200"
                                 label="转会类型">
                  <template slot-scope="scope">
                    <span style="display:flex">{{transferType[scope.row.transferType]}}
                      <span v-if="scope.row.money">({{scope.row.money}}万欧元)</span>
                    </span>
                  </template>
                </el-table-column>
              </el-table-column>
            </el-table>
            <div class="wusj"
                 v-if="!playerTransfer.length && !coachTransfer.length"> 暂无数据</div>
          </div>
          <!-- 信息统计 -->
          <div v-else-if="activeName == 'second' ">
            <el-divider content-position="left">
              <h6>信息统计</h6>
            </el-divider>
            <div>
              <div class="cursor_sty">
                <el-tag :type="typeClor == 0?'success':'info'"
                        size="mini"
                        @click="Onxiaoz()">总计</el-tag>
                <el-tag :type="typeClor == 1?'success':'info'"
                        size="mini"
                        @click="Onxiaoz(1)">联赛</el-tag>
                <el-tag :type="typeClor == 2?'success':'info'"
                        size="mini"
                        @click="Onxiaoz(2)">杯赛</el-tag>
              </div>
              <!-- 球员 -->
              <el-table :data="playerTj"
                        size="mini"
                        v-if="playerTj&&playerTj.length"
                        :row-class-name="tabRowClassName"
                        :header-cell-style="{
    'color': '#000',
       'background-color': 'rgb(131, 162, 202)',
    'font-size':'14px'
}"
                        style="width: 100%">
                <el-table-column align="center"
                                 label="">
                  <template slot="header"
                            slot-scope="scope">
                    <div style="color:rgb(248, 51, 71);font-size: 18px;">
                      <b>球员信息统计</b>
                    </div>
                  </template>
                  <el-table-column prop="sclassName"
                                   label="赛事"
                                   align="center"
                                   width="100">
                  </el-table-column>
                  <el-table-column prop="matchSeason"
                                   label="赛季"
                                   align="center"
                                   width="100">
                  </el-table-column>
                  <el-table-column prop="teamName"
                                   label="俱乐部"
                                   align="center"
                                   width="">
                    <template slot-scope="scope">
                      <router-link target="_blank"
                                   v-if="scope.row.teamID"
                                   :to="{name:'lineup',params:{teamID:scope.row.teamID}}">{{scope.row.teamName}}</router-link>
                    </template>
                  </el-table-column>
                  <el-table-column prop="count"
                                   label="上场"
                                   align="center"
                                   width="40">
                  </el-table-column>
                  <el-table-column prop="first"
                                   label="首发"
                                   align="center"
                                   width="40">
                  </el-table-column>
                  <el-table-column prop="penaltyGoals"
                                   label="点球进球"
                                   align="center"
                                   width="60">
                  </el-table-column>
                  <el-table-column prop="notPenaltyGoals"
                                   label="射门进球"
                                   align="center"
                                   width="60">
                  </el-table-column>
                  <el-table-column prop="assist"
                                   label="助攻"
                                   align="center"
                                   width="40">
                  </el-table-column>
                  <el-table-column prop="yellow"
                                   label="黄牌"
                                   align="center"
                                   width="40">
                  </el-table-column>
                  <el-table-column prop="red"
                                   label="红牌"
                                   align="center"
                                   width="40">
                  </el-table-column>
                  <el-table-column prop="owngoals"
                                   label="乌龙"
                                   align="center"
                                   width="40">
                  </el-table-column>
                </el-table-column>
              </el-table>
              <!-- 教练 -->
              <el-table :data="coachTj"
                        size="mini"
                        v-if="coachTj.length"
                        :row-class-name="tabRowClassName"
                        :header-cell-style="{
    'color': '#000',
       'background-color': 'rgb(131, 162, 202)',
    'font-size':'14px'
}"
                        style="width: 100%">
                <el-table-column align="center"
                                 label="">
                  <template slot="header"
                            slot-scope="scope">
                    <div style="color:rgb(248, 51, 71);font-size: 18px;">
                      <b>教练信息统计</b>
                    </div>
                  </template>
                  <el-table-column prop="sclassName"
                                   label="赛事"
                                   align="center"
                                   width="150">
                  </el-table-column>
                  <el-table-column prop="season"
                                   label="赛季"
                                   align="center"
                                   width="100">
                  </el-table-column>
                  <el-table-column label="俱乐部"
                                   align="center"
                                   width="">
                    <template slot-scope="scope">
                      <router-link target="_blank"
                                   v-if="scope.row.teamId"
                                   :to="{name:'lineup',params:{teamID:scope.row.teamId}}">{{scope.row.teamName}}</router-link>
                    </template>
                  </el-table-column>
                  <el-table-column prop="score"
                                   label="总得分"
                                   align="center"
                                   width="60">
                  </el-table-column>
                  <el-table-column prop="win"
                                   label="胜"
                                   align="center"
                                   width="60">
                  </el-table-column>
                  <el-table-column prop="flat"
                                   label="平"
                                   align="center"
                                   width="60">
                  </el-table-column>
                  <el-table-column prop="fail"
                                   label="负"
                                   align="center"
                                   width="60">
                  </el-table-column>
                </el-table-column>
              </el-table>
              <div v-if="coachTj.length && playerTj.length"> 暂无数据</div>
            </div>
          </div>
          <!-- 详细数据统计 -->
          <div v-else>
            <PlayerTechStatisticsTwo></PlayerTechStatisticsTwo>
          </div>
        </el-card>
      </div>

      <!-- 右边内容 -->
      <el-card class="right_box fr">
        <h6>相关队员</h6>
        <el-table :data="playerList"
                  size="mini"
                  class-name="aaa"
                  :header-cell-style="{
    'color': '#303133',
    'border-bottom': '1px rgb(103, 194, 58) solid',
    'font-size':'14px'
}"
                  style="width: 296px">
          <el-table-column prop="number"
                           class-name="aa"
                           label="号码"
                           align="center"
                           width="30">
          </el-table-column>
          <el-table-column prop="place"
                           label="位置"
                           align="center"
                           width="40">
            <template slot-scope="scope">
              <span style="width:100%;height:100%;display:block;"
                    :style="{'background':scope.row.colors}">{{scope.row.place}}</span>
            </template>
          </el-table-column>
          <el-table-column prop="playerName"
                           align="center"
                           label="姓名">
            <template slot-scope="scope">
              <router-link target="_blank"
                           :to="{name:'playerDetails',params:{playerID:scope.row.playerID}}">{{scope.row.playerName}}</router-link>
            </template>
          </el-table-column>
          <el-table-column prop="country"
                           align="center"
                           width="60"
                           label="国籍">
          </el-table-column>
        </el-table>
      </el-card>
    </div>
    <div class="tk-box"
         v-if="ifBlock">
      <Playerqiulu></Playerqiulu>
    </div>
    <div class="loading_box"
         v-if="ifBlock">
      <el-image style="height:100%"
                src="/static/loading.gif"></el-image>
    </div>
    <div class="anniu"
         v-if="ifBlock"
         @click="gb_qiul">
      <el-button type="primary"
                 icon="el-icon-close"
                 circle></el-button>
    </div>
  </div>

</template>
<script >
import PlayerTechStatisticsTwo from './playerTechStatisticsTwo'
import Playerqiulu from './player_qiulu'

export default {
  components: {
    PlayerTechStatisticsTwo,
    Playerqiulu
  },
  data () {
    return {
      activeName: '3',
      age: '',
      timeList: [],
      timeListVe: '全部',
      currentPage1: 1,
      hideOnsingle: false,
      headerData: [],
      playerTransfer: [],
      idiomaticFeet: { 0: '左脚', 1: '右脚', 2: '双脚' },
      playerList: [],
      placeLen: '',
      activeName: 'first',
      // 联赛杯赛
      coachTransfer: [],
      transferType: { 1: '完全所有', 2: "租借", 3: '自由转会', 4: '租借结束', 5: '共同所有' },
      duty: {        2: "教练", 4: "助理教练", 6: "临时教练", 7: "体育主管", 8: "CEO", 9: "分析师",
        10: "副主席", 11: "经理", 12: "主席", 13: "青训主管", 14: "发展部主管", 15: "球探主管",
        16: "技术主管", 17: "顾问", 18: "协调主管", 19: "老板", 20: "董事", 21: "体育协调",
        22: "秘书长", 23: "市场主管"      },
      // 统计
      playerTj: [],
      coachTj: [],
      playerTjs: [],
      coachTjs: [],
      typeClor: 0,
      ifBlock: false,
    };
  },
  created () {
    this.scheduleID = this.$route.params.playerID
    // console.log(this.$route.name)
    this.dataList1()
    this.dataList2()
    this.dataList3()
    // 时间获取
    let ii = 0
    for (let i = 2014; i <= new Date().getFullYear(); i++) {
      this.timeList[ii] = {}
      this.timeList[ii].value = i
      this.timeList[ii].label = i
      ii++
    }
    this.timeList[0].value = '全部'
    this.timeList[0].label = '全部'
    // 其他球员信息
    var temp = sessionStorage.getItem("lineupList")
    this.playerList = JSON.parse(temp);
  },
  methods: {
    // 选项卡
    handleClick (tab, event) {
      if (tab.name == 'fourth') {
        this.ifBlock = true
      }
    },
    // ck_qiul () {
    //   this.ifBlock = true
    // },
    gb_qiul () {
      this.ifBlock = false
      this.activeName = 'second'
    },

    //  球员基本信息
    async dataList1 () {
      const res = await this.$http.get('teamInfo/player/' + this.scheduleID);
      if (res.data.birthday) {
        var birthday = new Date(res.data.birthday.replace(/-/g, "\/"));
        var d = new Date();
        var age = d.getFullYear() - birthday.getFullYear() - ((d.getMonth() < birthday.getMonth() || d.getMonth() == birthday.getMonth() && d.getDate() < birthday.getDate()) ? 1 : 0);
        this.age = age
      }
      this.headerData = res.data
      this.placeLen = res.data.place.length
    },

    async dataList2 () {
      const res = await this.$http.get(`teamInfo/player/${this.scheduleID}/playerTransfer/`);
      this.playerTransfer = res.data.playerTransfer
      this.coachTransfer = res.data.coachTransfer
    },


    async dataList3 () {
      const res = await this.$http.get(`teamInfo/player/${this.scheduleID}/playerTechStatistics`);
      if (res.data.coachTj) {
        this.coachTjs = res.data.coachTj
        this.coachTj = res.data.coachTj
      } else {
        this.playerTjs = res.data.playerTj
        this.playerTj = res.data.playerTj
      }

    },
    Onxiaoz (v) {
      if (v) {
        this.coachTj = this.coachTjs.filter(item => {
          return item.kind == v
        })
        this.playerTj = this.playerTjs.filter(item => {
          return item.kind == v
        })
        this.typeClor = v
      } else {
        this.coachTj = this.coachTjs
        this.playerTj = this.playerTjs
        this.typeClor = 0
      }

    },

    tabRowClassName ({ row, rowIndex }) {
      let index = rowIndex + 1;
      if (index % 2 == 0) {
        return 'warning-row'
      }
    }

  }
}
</script>
<style lang = 'less'  >
.player——box {
  position: relative;
  width: 100%;
  height: 100vh;
  /* background: red; */
  .tk-box {
    height: 100vh;
    width: 100%;
    background: rgba(0, 0, 0, 0.7);
    overflow: auto;
    position: absolute;
    top: 0;
    left: 0;
    z-index: 999;
  }
  .anniu {
    position: absolute;
    right: 70px;
    top: 20px;
    z-index: 999;
  }
  .loading_box {
    width: 100px;
    height: 100px;
    margin: auto;
    position: absolute;
    top: 100px;
    left: 50%;
    margin-left: -50px;
  }
}

.player_box_ss .el-table .warning-row {
  background: rgba(160, 189, 226, 0.2) !important;
}
.player_box_ss .el-table--enable-row-hover .el-table__body tr:hover > td {
  background-color: rgba(160, 189, 226, 0.5);
}
.player_box_ss a {
  display: block;
  /* width: 100%; */
  /* height: 100%; */
  &:hover {
    color: #409eff;
  }
}
.player_box_ss .el-table--mini td,
.player_box_ss .el-table--mini th {
  padding: 0 !important;
}
.player_box_ss .el-table .cell {
  height: 100%;
  line-height: 36px !important;
  display: flex;
  justify-content: center;
  align-items: center;
}
.player_box_ss .cell span {
  display: block;
}
.player_box_ss .el-table--border {
  overflow: hidden !important;
}
</style>
<style lang = 'less' scoped >
.el-card {
  margin-bottom: 10px;
  width: 872px;
}
.player_header {
  display: flex;
  justify-content: space-around;
  align-items: center;
  .player_header_left {
    width: 530px;
    h3 {
      font-size: 26px;
      color: #25180b;
      line-height: 38px;
      font-weight: 600;
    }
    p {
      color: #a8a5a4;
      font-size: 14px;
      margin-bottom: 8px;
    }
    .details {
      width: 100%;
      display: flex;
      justify-content: space-between;
      dl {
        dd {
          line-height: 28px;
          color: #050200;
        }
      }
    }
  }
  .player_header_right {
    width: 150px;
    height: 150px;
    .el-image {
      width: 80%;
      height: 100%;
    }
  }
}

.left_box_bottom {
  h6 {
    font-size: 18px;
    font-weight: 600;
  }
  .wusj {
    text-align: center;
  }
  .kua {
    padding: 20 px;
  }
  /* 比赛数据 */
  .table_NeiRong {
    color: #555;
    tr {
      height: 30px;
      font-size: 14px;
    }
    td {
      border-bottom: 1px solid #ececec;
      border-left: 1px solid #ececec;
      &:last-child {
        border-right: 1px solid #ececec;
      }
    }
    .table_NeiRong_one {
      background: #f5f7fa;
      font-size: 16px;
      height: 60px;
      line-height: 30px;
    }
    .table_NeiRong_two {
      &:hover {
        background: #f3f4ef;
      }
    }
  }
  .zh_p {
    font-size: 14px;
    width: 100%;
    overflow: hidden;
    text-align: center;
    display: flex;
    justify-content: space-around;
    align-items: center;
    span {
      display: flex;
      align-items: center;
    }
  }
}
/* 右边内容 */
.right_box {
  width: 316px;
  h6 {
    font-size: 18px;
    font-weight: 900;
  }
}

.el-pagination {
  text-align: center;
}

.tableHead {
  font-weight: 600;
  color: #303133;
  font-size: 14px;
  height: 50px;
}
.linue-header {
  height: 30px;
  line-height: 30px;
  font-weight: 600;
  text-align: center;
  font-size: 18px;
  color: #303133;
}
a {
  &:hover {
    color: #409eff;
  }
}

.el-table--mini td,
.el-table--mini th {
  padding: 0 !important;
}
.el-table .cell {
  background: red !important;
  height: 36px !important;
  line-height: 38px !important;
}
.cursor_sty {
  .el-tag {
    cursor: pointer;
    margin-right: 10px;
  }
}

.image_div {
  width: 20px;
  height: 20px;
  border-radius: 50%;
  overflow: hidden;
  .el-image {
    width: 20px;
  }
}
</style>