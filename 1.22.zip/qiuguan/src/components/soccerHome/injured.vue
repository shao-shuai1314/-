<template>
  <div class="gWidth injured_box">
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/index' }">首页</el-breadcrumb-item>
      <el-breadcrumb-item :to="{ path: '/soccer' }">足球中心</el-breadcrumb-item>
      <el-breadcrumb-item>球员最新伤停</el-breadcrumb-item>
    </el-breadcrumb>
    <!-- 左边 -->
    <navigation :datas=[...datas]></navigation>
    <el-card style="width:942px;"
             class="fr">
      <el-table :data="tableData"
                :row-class-name="tabRowClassName"
                border
                :header-cell-style="{
    'color': '#303133',
    'border-bottom': '1px rgb(103, 194, 58) solid',
    'background-color': 'rgb(131, 162, 202)',
    'font-size':'14px',
}"
                size="mini">
        <el-table-column prop="matchSeason"
                         align="center">
          <template slot="header"
                    slot-scope="scope">
            <span style="color:rgb(248, 51, 71);font-size: 18px;">
              {{datas[0]}}俱乐部简介
            </span>
          </template>
          <el-table-column align="center"
                           prop="count"
                           label="序号">
            <template slot-scope="scope">
              {{scope.$index+1}}
            </template>
          </el-table-column>
          <el-table-column align="center"
                           prop="count"
                           label="序号">
            <template slot-scope="scope">
              {{scope.$index+1}}
            </template>
          </el-table-column>
          <el-table-column align="center"
                           prop="count"
                           label="序号">
            <template slot-scope="scope">
              {{scope.$index+1}}
            </template>
          </el-table-column>
          <el-table-column align="center"
                           prop="count"
                           label="序号">
            <template slot-scope="scope">
              {{scope.$index+1}}
            </template>
          </el-table-column>
          <el-table-column align="center"
                           prop="count"
                           label="序号">
            <template slot-scope="scope">
              {{scope.$index+1}}
            </template>
          </el-table-column>
          <el-table-column align="center"
                           prop="count"
                           label="序号">
            <template slot-scope="scope">
              {{scope.$index+1}}
            </template>
          </el-table-column>

        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>
<script >
import navigation from './SideNavigation';
export default {
  components: {
    navigation
  },
  data () {
    return {
      datas: [],
      tableData: []
    };
  },
  created () {
    var temp = sessionStorage.getItem("seasonList")
    let seasonList = JSON.parse(temp);
    this.datas = [sessionStorage.getItem('sclassName'), sessionStorage.getItem('sclass_rule'), sessionStorage.getItem('matchSeason'), seasonList, sessionStorage.getItem('sclass_pic')]
    document.title = `${this.datas[2]} -  ${this.datas[0]} - 伤停统计`;
    this.playerSuspend()
  },
  methods: {
    async playerSuspend () {
      const res = await this.$http.get(`/soccer/sclass/${this.$route.params.sclassID}/playerSuspend/`);
      console.log(res.data.data)
      this.tableData = res.data.data

    },
    tabRowClassName ({ row, rowIndex }) {
      let index = rowIndex + 1;
      if (index % 2 == 0) {
        return 'warning-row'
      }
    },
  }
}
</script>
<style lang = 'less' >
.injured_box .el-table .warning-row {
  background: rgba(160, 189, 226, 0.2) !important;
}
.injured_box a {
  display: block;
  cursor: pointer;
  width: 100%;
  height: 100%;
  &:hover {
    color: #409eff;
  }
}
.injured_box .el-table--mini td,
.injured_box .el-table--mini th {
  padding: 0 !important;
}
.injured_box .el-table .cell {
  height: 100%;
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  line-height: 36px !important;
}
.injured_box .cell span {
  display: flex;
  align-items: center;
  display: block;
}
.injured_box .el-table--enable-row-hover .el-table__body tr:hover > td {
  background-color: rgba(160, 189, 226, 0.5);
}
</style>