<template>
  <div class="gWidth lineup_boxss">
    <el-table :data="dataList"
              size="mini"
              border
              :header-cell-style="{ 
    'color': '#303133',
    'border-bottom': '1px rgb(103, 194, 58) solid',
    'background-color': 'rgb(131, 162, 202)',
    'font-size':'14px',
}"
              :row-class-name="tabRowClassName"
              style="width: 1160px">
      <el-table-column prop="number"
                       align="center"
                       width="80"
                       label="球衣号码">
      </el-table-column>
      <el-table-column prop="place"
                       align="center"
                       width="80"
                       label="位置">
        <template slot-scope="scope">
          <span style="width:100%;height:100%;display:block;"
                :style="{'background':scope.row.colors}">{{scope.row.place}}</span>
        </template>
      </el-table-column>
      <el-table-column prop="playerName"
                       align="center"
                       label="中文名">
        <template slot-scope="scope">
          <b v-if="scope.row.captaintypeID == 1"
             style="margin-right:20px;color:red">C</b>
          <router-link target="_blank"
                       :to="{name:'playerDetails',params:{playerID:scope.row.playerID}}">{{scope.row.playerName}}</router-link>
        </template>
      </el-table-column>
      <el-table-column prop="country"
                       align="center"
                       width="100"
                       label="国籍">
        <template slot="header"
                  slot-scope="scope">
          <span>国籍</span>
          <span class="actv"
                @click="Onau()">排序</span>
        </template>
        <template slot-scope="scope">
          <span class="span_s"
                :style="`background:${scope.row[scope.row.country]}`">{{scope.row.country}}</span>
        </template>
      </el-table-column>
      <el-table-column align="center"
                       label="生日">
        <template slot-scope="scope">
          <span>{{scope.row.birthday}}</span>
        </template>
      </el-table-column>
      <el-table-column align="center"
                       width="80"
                       label="预计身价">
        <template slot-scope="scope">
          {{scope.row.expectedValue}}万
        </template>
      </el-table-column>
      <el-table-column align="center"
                       width="80"
                       label="出场(替补)">
        <template slot-scope="scope">
          {{scope.row.count}}({{scope.row.first}})
        </template>

      </el-table-column>
      <el-table-column align="center"
                       width="80"
                       label="出场时间">
        <template slot-scope="scope">
          {{scope.row.playTime}}
        </template>
      </el-table-column>
      <el-table-column align="center"
                       width="80"
                       label="进球(点)">
        <template slot-scope="scope">
          <span v-if="scope.row.notPenaltyGoals||scope.row.penaltyGoals">
            {{scope.row.notPenaltyGoals+scope.row.penaltyGoals}}({{scope.row.penaltyGoals}})
          </span>
          <span v-else>
            0(0)
          </span>
        </template>
      </el-table-column>
      <el-table-column align="center"
                       width="80"
                       label="红牌(黄牌)">
        <template slot-scope="scope">
          <span v-if="scope.row.red||scope.row.yellow">
            {{scope.row.red}}({{scope.row.yellow}})
          </span>
          <span v-else>
            0(0)
          </span>
        </template>
      </el-table-column>
      <el-table-column align="center"
                       width="180"
                       label="合同截止">
        <template slot-scope="scope">
          {{scope.row.endTime}}
        </template>
      </el-table-column>
      <!-- <el-table-column align="center"
                       width="80"
                       label="惯用脚">
        <template slot-scope="scope">
          <span v-if="scope.row.idiomaticFeet==1">右脚</span>
          <span v-else-if="scope.row.idiomaticFeet==2">双脚</span>
          <span v-else>左脚</span>
        </template>
      </el-table-column> -->
    </el-table>
  </div>
</template>
<script >
export default {
  data () {
    return {
      dataList: [],
      au: false
    };
  },
  created () {
    this.scheduleID = this.$route.params.teamID
    this.OnListG()
  },
  methods: {
    Onau () {
      this.au = !this.au
      if (this.au) {
        this.dataList = this.aaa()
      } else {
        this.dataList = this.dataListss
      }
    },
    aaa () {
      let bbb = {}
      this.dataLists.forEach(item => {
        if (!bbb.hasOwnProperty(item.country)) {
          bbb[item.country] = 0;
        }
        bbb[item.country] += 1;
        if (bbb.hasOwnProperty('null')) {
          bbb['null'] = 0;
        }
      });
      for (var i = 0; i < this.dataLists.length; i++) {
        for (var j = 0; j < this.dataLists.length - i - 1; j++) {
          var a = this.dataLists[j];
          var b = this.dataLists[j + 1];
          var aaaa = a["country"]
          var bbbb = b["country"]
          if (bbb[bbbb] == bbb[aaaa]) {
            if (aaaa > bbbb) {
              this.dataLists[j] = b
              this.dataLists[j + 1] = a
            }
          } else if (bbb[bbbb] > bbb[aaaa]) {
            this.dataLists[j] = b
            this.dataLists[j + 1] = a
          }
        }
      }
      return this.dataLists
    },
    async OnListG () {
      const res = await this.$http.get('teamInfo/' + this.$route.params.teamID + '/lineup/');
      var Coachcolors = { '前锋': 'rgba(190,76,89,0.5)', '中场': 'rgba(100,76,89,0.5)', '后卫': 'rgba(180,16,89,0.5)', '守门员': 'rgba(110,106,89,0.5)', '替补': 'rgba(170,76,29,0.5)' }
      // 颜色
      console.log(res.data.data)
      res.data.data.forEach((item) => {
        item.colors = Coachcolors[item.place]
      })
      this.dataList = [].concat(res.data.data)
      this.dataLists = [].concat(res.data.data)
      let ccc = {}
      this.dataLists.forEach((item, index) => {
        if (!ccc.hasOwnProperty(item.country)) {
          ccc[item.country] = `rgba(${Math.floor(Math.random() * 50 * index) + ',' + Math.floor(Math.random() * 50 * index) + ',' + Math.floor(Math.random() * 50 * index)},0.4)`
        }
        item[item.country] = ccc[item.country]
      })
      this.dataListss = [].concat(res.data.data)

      sessionStorage.setItem("lineupList", JSON.stringify(res.data.data));
    },
    tabRowClassName ({ row, rowIndex }) {
      let index = rowIndex + 1;
      if (index % 2 == 0) {
        return 'warning-row'
      }
    }
  }
}
</script>
<style lang = 'less'  >
.lineup_boxss .el-table .warning-row {
  background: rgba(160, 189, 226, 0.2) !important;
}
.lineup_boxss .el-table--enable-row-hover .el-table__body tr:hover > td {
  background-color: rgba(160, 189, 226, 0.5);
}
.lineup_boxss a {
  display: block;
  height: 100%;
  &:hover {
    color: #409eff;
  }
}
.lineup_boxss .el-table--mini td,
.lineup_boxss .el-table--mini th {
  padding: 0 !important;
}
.lineup_boxss .el-table .cell {
  font-size: 14px;
  width: 100%;
  height: 100%;
  line-height: 36px !important;
  display: flex;
  justify-content: center;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.lineup_boxss .cell span {
  display: block;
}
.lineup_boxss .actv {
  height: 30px;
  margin-top: 2px;
  font-size: 12px;
  padding: 0 6px;
  line-height: 30px;
  margin-left: 10px;
  display: inline-block;
  background: #666;
  border-radius: 6px;
  color: #409eff;
  /* display: block; */
  cursor: pointer;
}
</style>