<template>
  <div class="matchNew_box">
    <el-card class="matchNew_box_left">
      <ul class="">
        <li v-for="(item,index) in new_list"
            :key="index">
          <router-link target="_blank"
                       :to="{name:'newdetail',params:{recordId:item.recordId}}">
            <div class="item_new">
              <div class="item_new_image">
                <el-image :src="item.img?`https://www.qiuguantx.com/imgs/Journalism/${item.img}`: ''"></el-image>
              </div>
              <div class="item_new_text">
                <p>{{item.title}}</p>
                <div class="item_new_text_t">
                  <span>{{item.publicTime}}</span>
                  <b>{{item.Reprinted}}</b>
                </div>
              </div>
            </div>
            <el-divider></el-divider>
          </router-link>
        </li>
      </ul>
      <p class="load-more"
         @click="loadMore">点击加载更多</p>
    </el-card>
  </div>
</template>
<script >
export default {
  data () {
    return {
      new_list: [],
      scroll_id: ''
    };
  },
  created () {
    var temp = sessionStorage.getItem("name_j")
    if (sessionStorage.getItem("name_short")) {
      var temps = sessionStorage.getItem("name_short")
      if (temp == temps) {
        this.jk({ keyword: temp })
      } else {
        var tempss = temp + temps
        this.jk({ keyword: tempss })
      }
    } else {
      this.jk({ keyword: temp })
    }


  },
  methods: {
    async jk (obj) {
      const { data: res } = await this.$http.get(`/journalism/`, { params: obj });
      if (res.data.length != 0) {
        this.new_list.push(...res.data)
      }
      if (res.data.length == 0) {
        return this.$message.error('已经加载全部')
        this.scroll_id = ''
      } else {
        this.scroll_id = res.scroll_id
      }

    },
    loadMore () {
      if (this.scroll_id) {
        this.jk({ scroll_id: this.scroll_id })
      } else {
        return this.$message.error('已经加载全部')
      }

    }
  }
}
</script>
<style lang = 'less' scoped >
.matchNew_box {
  margin-top: 20px;
  .matchNew_box_left {
    float: left;
    width: 900px;
    .item_new {
      display: flex;
      .item_new_image {
        width: 150px;
        height: 100px;
        overflow: hidden;
        margin-right: 20px;
        .el-image {
          width: 150px;
          height: 100px;
        }
      }
      .item_new_text {
        width: 100%;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        p {
          font-size: 18px;
          color: #333;
        }
        .item_new_text_t {
          display: flex;
          justify-content: space-between;
          span {
            font-size: 12px;
            color: #999;
          }
          b {
            font-size: 12px;
            color: #999;
          }
        }
      }
    }
    .load-more {
      width: 100%;
      height: 50px;
      line-height: 50px;
      text-align: center;
      background: #ececec;
      color: #888;
      cursor: pointer;
    }
  }
}
</style>