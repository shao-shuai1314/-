<template>
  <div class="analyse_box"
       v-if="isTrue">
    <div class="analyse_box1">
      <h2>本场比赛前（主、客队）重大新闻、信息提醒及临场信息提示与说明</h2>
      <dl class="analyse_box_header">
        <dd class="analyse_box_1 jc_a">序号</dd>
        <dd class="analyse_box_2 jz_a jc_a">新闻与信息内容</dd>
        <dd class="analyse_box_3">
          <div class="zk_biao jc_a">
            <span>主队</span>
            <span>客队</span>
          </div>
          <div class="jc_a"
               style="margin-left:10px">是或有（√）不是或没有（x）</div>
        </dd>
        <dd class="analyse_box_4 jz_a jc_a">具体说明（新闻与信息）</dd>
      </dl>
      <dl class="analyse_box_conter"
          v-for="(item,index) in obj.tit_l"
          :key="index">
        <dd class="analyse_box_1">{{index+1}}</dd>
        <dd class="analyse_box_2">{{item.title}}</dd>
        <dd class="analyse_box_3 jz_a">
          <div class="span_div_x">
            <p class="span_x ">
              <b v-if="item.isTrue ==2">×</b>
              <b v-if="item.isTrue ==1">√</b>
              <b v-else></b>
            </p>
            <p>
              <b v-if="item.radio ==4">×</b>
              <b v-if="item.radio ==3">√</b>
              <b v-else></b>
            </p>
          </div>
        </dd>
        <dd class="analyse_box_4">{{item.conters}}</dd>
      </dl>
    </div>

    <div class="analyse_box2">
      <h2>本场比赛综合分析</h2>
      <div class="analyse_box2ss">
        <div class="zd_s">
          <div class="ylys">
            <h3 class="bcsm">主 队</h3>
            <div class="ylys1">
              <div>有 利 因 素</div>
              <ul>
                <li>{{obj.zhudui_list&&obj.zhudui_list.ylYs.yl1}}</li>
                <li>{{obj.zhudui_list&&obj.zhudui_list.ylYs.yl2}}</li>
                <li>{{obj.zhudui_list&&obj.zhudui_list.ylYs.yl3}}</li>
              </ul>
            </div>
            <div class="ylys1">
              <div>不 利 因 素</div>
              <ul>
                <li>{{obj.zhudui_list&&obj.zhudui_list.blYs.bl1}}</li>
                <li>{{obj.zhudui_list&&obj.zhudui_list.blYs.bl2}}</li>
                <li>{{obj.zhudui_list&&obj.zhudui_list.blYs.bl3}}</li>
              </ul>
            </div>
            <div class="bcsm">
              <p>补充与重点说明:{{obj.zhudui_list&&obj.zhudui_list.suoming}}</p>
            </div>
            <div class="bcsm">
              本场推荐 1、正路（
              <i v-if="obj.zhudui_list&&obj.zhudui_list.bctj==1">√</i> ）； 2、防冷（
              <i v-if="obj.zhudui_list&&obj.zhudui_list.bctj==2">√</i> ）； 3、搏冷（
              <i v-if="obj.zhudui_list&&obj.zhudui_list.bctj==3">√</i> ）
            </div>
          </div>
        </div>

        <div class="zd_s">
          <div class="ylys">
            <h3 class="bcsm">客 队</h3>
            <div class="ylys1">
              <div>有 利 因 素</div>
              <ul>
                <li>{{obj.kedui_list&&obj.kedui_list.ylYs.yl1}}</li>
                <li>{{obj.kedui_list&&obj.kedui_list.ylYs.yl2}}</li>
                <li>{{obj.kedui_list&&obj.kedui_list.ylYs.yl3}}</li>
              </ul>
            </div>
            <div class="ylys1">
              <div>不 利 因 素</div>
              <ul>
                <li>{{obj.kedui_list&&obj.kedui_list.blYs.bl1}}</li>
                <li>{{obj.kedui_list&&obj.kedui_list.blYs.bl2}}</li>
                <li>{{obj.kedui_list&&obj.kedui_list.blYs.bl3}}</li>
              </ul>
            </div>
            <div class="bcsm">
              <p>补充与重点说明:{{obj.kedui_list&&obj.kedui_list.suoming}}</p>
            </div>
            <div class="bcsm">
              最终推荐：{{obj.kedui_list&&obj.kedui_list.zztj}}
            </div>
          </div>
        </div>

      </div>
    </div>

  </div>
</template>
<script >
import Qs from 'qs'
import QRCode from "qrcodejs2"
export default {
  data () {
    return {
      obj: {},
      isTrue: true
    }
  },
  created () {
    this.matchState = sessionStorage.getItem('matchState')
    // 标题
    let datas_ss = [sessionStorage.getItem('sclassName'), sessionStorage.getItem('matchSeason')]
    var temp_ss = sessionStorage.getItem("TeamName").split(",")
    document.title = `${temp_ss[0]} vs ${temp_ss[2]} - ${datas_ss[1]}${datas_ss[0]} -  赛前分析`
    this.getanalyse()
  },
  methods: {
    async getanalyse () {
      const { data: res } = await this.$http.get(`/soccer/matchInfo/${this.$route.params.scheduleID}/fenxi_table/`);
      if (res.data.content) {
        let obj = JSON.parse(res.data.content)
        this.obj = obj
        console.log(obj.zhudui_list.bctj)
      } else {
        this.isTrue = false
      }
    }

  }

}
</script>
<style lang = 'less' scoped>
h2 {
  text-align: center;
}
.analyse_box dl {
  display: flex;
}
/* .analyse_box {
  border: 1px solid;
} */
.analyse_box_conter dd,
.analyse_box_header dd {
  border: 1px solid #8b8b8b;
  font-size: 14px;
  /* font-weight: 600; */
}
.analyse_box_1 {
  width: 40px;
  display: flex;
  justify-content: center;
  align-items: center;
}
.analyse_box_2 {
  width: 430px;
}
.analyse_box_3 {
  width: 200px;
}
.analyse_box_4 {
  width: 470px;
}
.zk_biao {
  width: 100%;
  border-bottom: 1px solid #8b8b8b;
  text-align: center;
}
.jz_a {
  display: flex;
  justify-content: center;
  align-items: center;
}
.jc_a {
  font-weight: 900;
}
/* -------------------------------- */
.analyse_box2 {
  .analyse_box2ss {
    display: flex;
    width: 100%;
  }
  .zd_s {
    width: 50%;
    .ylys {
      h3 {
        text-align: center;
      }
      .ylys1 {
        display: flex;
        div {
          width: 10%;
          border: 1px solid #8b8b8b;
          -webkit-writing-mode: vertical-rl;
          writing-mode: vertical-rl;
          display: flex;
          justify-content: center;
          align-items: center;
        }
        ul {
          width: 90%;
          li {
            height: 50px;
            border: 1px solid #8b8b8b;
          }
        }
      }
      .bcsm {
        height: 50px;
        border: 1px solid #8b8b8b;
        line-height: 50px;
      }
    }
  }
}
.analyse_box1,
.analyse_box2 {
  border: 6px solid #8b8b8b;
  /* background: rgba(207, 232, 204); */
}
.span_x {
  border-right: 2px solid;
}
.span_div_x {
  width: 100%;
  display: flex;
  justify-content: space-between;
  p {
    width: 50%;
    text-align: center;
  }
}
</style>
