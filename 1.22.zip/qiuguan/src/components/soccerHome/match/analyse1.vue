<template>
  <div class="analyse_box">
    <!-- 支付方式 -->
    <div class="zf_sty_ss"
         v-if="block_s_zf">
      <el-card class="zf_sty_s">
        <div class="zf_sty_p">
          <!-- <p>商品订单：{{item.out_trade_no}}</p> -->

          <p>购买商品：笔记收费</p>
          <p>应付金额：￥{{yfje}}元</p>
          <!-- <p class=" goum_fs">购买方式：
            <el-select v-model="goum_fs_v"
                       size="mini"
                       placeholder="请选择">
              <el-option v-for="item in goum_fs"
                         :key="item.value"
                         :label="item.label"
                         :value="item.value">
              </el-option>
            </el-select>
          </p> -->
        </div>

        <div class="zf_ewm">
          <div id="qrcode"></div>
        </div>
        <el-link type="primary"
                 :underline="false"
                 class="zf_sty_a">《交易协议》</el-link>
        <div>
          <el-link type="info"
                   class="zf_sty_X"
                   @click="On_X">X</el-link>
        </div>
      </el-card>
    </div>

    <el-card class="analyse_left">
      <div v-if="!active">
        <dl>
          <dd v-for="(item,index) in textList"
              :key="index">
            <div class="yhxinxi">
              <div class="users">
                <el-image style="width:40px;border-radius:50px"
                          src="https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png"></el-image>
                <p>{{item.username}}</p>
              </div>

              <div class="yhP">
                <div>
                  <p>
                    <b style="color: #f46859;font-size: 16px;margin-bottom:20px"
                       v-if="item.firstChoice && !item.twoChoice">单选：{{item.firstChoice}}</b>
                    <b style="color: #f46859;font-size: 16px;"
                       v-if="item.twoChoice">首选：{{item.firstChoice}}</b>
                    <b v-if="item.twoChoice">次选：{{item.twoChoice}}</b>
                  </p>
                  <p v-html="item.content"></p>
                  <div style="margin-top:20px">
                    <b style="color: #c1c1c1;font-size: 12px">{{item.publicTime}}</b>
                    <span class="span_goumai">
                      <b style="color: #f46859;font-size: 16px;margin-left:20px"
                         v-if="item.notePrice">付费阅读：{{item.notePrice}}元</b>
                      <b class=" goum_fs"
                         v-if="item.notePrice">
                        购买方式：
                        <el-select @change="aaa_s"
                                   v-model="item.goum_fs_v"
                                   size="mini"
                                   placeholder="请选择">
                          <el-option v-for="i in item.goum_fs"
                                     :key="i.value"
                                     :label="i.label"
                                     :value="i.value">
                          </el-option>
                        </el-select>
                      </b>
                      <el-button @click="ONz_h(item.noteId,item.goum_fs_v)"
                                 v-if="item.z_h"
                                 size="mini"
                                 type="primary"
                                 round>展开</el-button>
                      <el-button type="primary"
                                 size="mini"
                                 @click="ONs_q(item.noteId)"
                                 v-else>收回</el-button>

                    </span>

                    <!-- <b style="color: #f46859;font-size: 16px;margin-left:20px">{{item.payNumber}}</b> -->

                  </div>
                </div>
              </div>

            </div>

            <el-divider></el-divider>
          </dd>
        </dl>
        <div v-if="textList.length == 0"
             style="text-align: center">暂无数据</div>
      </div>

      <div class="fbk_box"
           v-else>
        <div class="zf_div_ss">
          <div style="width:350px">
            <el-button size="small"
                       @click="Onbt">表态+</el-button>
            <span v-if="checkList.length">
              <b style="font-size:14px;margin-left:10px">胜平负 : &nbsp;&nbsp;</b>
              <span style="color:red;font-size:12px ">
                <b style="margin-right:20px">首选： {{checkList[0]}}&nbsp;&nbsp;</b>
                <b v-if="checkList[1]">次选： {{checkList[1]}}</b>
              </span>
            </span>
            <el-card class="xians"
                     style="width:300px;margin-top:6px"
                     v-if="spf">
              <span class="el-icon-circle-close chahao"
                    @click="Oncha"></span>
              <h4>
                <b>选择表态</b>&nbsp;&nbsp;
                <b style="font-size:12px">首选:胜平负(必选)</b>
              </h4>
              <br>
              <el-checkbox-group v-model="checkList"
                                 @change="chec_s"
                                 :max="2">
                <el-checkbox label="胜"></el-checkbox>
                <el-checkbox label="平"></el-checkbox>
                <el-checkbox label="负"></el-checkbox>
              </el-checkbox-group>

            </el-card>
          </div>

          <div class="is_FF">
            <el-checkbox v-model="checked_v">是否收费（可选）</el-checkbox>
            <el-select v-model="value_ss"
                       v-if="checked_v"
                       size="mini"
                       placeholder="请选择">
              <el-option v-for="item in options_ss"
                         :key="item.value"
                         :label="item.label"
                         :value="item.value">
              </el-option>
            </el-select>
          </div>
        </div>

        <!-- 富文本 -->
        <div class="analyse_container">
          <quill-editor v-model="analyse_content"
                        style="height:400px;"
                        ref="myQuillEditor"
                        :options="editorOption"
                        @blur="onEditorBlur($event)"
                        @focus="onEditorFocus($event)"
                        @change="onEditorChange($event)">
          </quill-editor>
        </div>
        <el-button type="info"
                   class="fr"
                   style="margin-top:60px;margin-bottom:20px"
                   size="mini"
                   v-on:click="saveHtml">发布</el-button>
      </div>
    </el-card>

    <div class="analyse_right">
      <el-button icon="el-icon-edit"
                 type="primary"
                 :disabled="matchState == -1?true:false"
                 @click="ONwrite">写笔记</el-button>
      <el-button icon="el-icon-view"
                 type="primary"
                 @click="ONsea">查看笔记</el-button>

    </div>

  </div>
</template>
<script >
import Qs from 'qs'
import QRCode from "qrcodejs2"
export default {
  data () {
    return {
      spf: false,
      checkList: [],
      active: false,
      textList: [],
      textList_s: [],
      checked_v: false,
      matchState: '',


      analyse_content: ``,
      editorOption: {},
      goum_fs_v: "微信",
      options_ss: [{
        value: '0.01',
        label: '0.01'
      }, {
        value: '0.02',
        label: '0.02'
      }, {
        value: '0.03',
        label: '0.03'
      },],
      value_ss: '',
      block_s_zf: false,
      yfje: ''
    };
  },
  components: { QRCode },
  created () {
    this.tixtList()
    this.matchState = sessionStorage.getItem('matchState')
    // 标题
    let datas_ss = [sessionStorage.getItem('sclassName'), sessionStorage.getItem('matchSeason')]
    var temp_ss = sessionStorage.getItem("TeamName").split(",")
    document.title = `${temp_ss[0]} vs ${temp_ss[2]} - ${datas_ss[1]}${datas_ss[0]} -  赛前分析`
  },
  destroyed () {
    clearInterval(this.Polling);
  },
  methods: {
    //  生成二维码
    qrcode (link) {
      // let that = this;
      let qrcode = new QRCode('qrcode', {
        width: 125,
        height: 125,        // 高度
        // text: this.link,   // 二维码内容
        text: link,
        // render: 'canvas' ,   // 设置渲染方式（有两种方式 table和canvas，默认是canvas）
        // background: '#f0f',   // 背景色
        // foreground: '#ff0'    // 前景色
      })
    },
    onEditorReady (editor) { // 准备编辑器
    },
    onEditorBlur () { }, // 失去焦点事件
    onEditorFocus () { }, // 获得焦点事件
    onEditorChange () { }, // 内容改变事件
    async saveHtml () {
      if (this.checkList.length == 0) {
        return this.$message.error('请您发表动态')
      }
      if (this.checked_v) {
        if (this.value_ss == '') {
          return this.$message.error('请您设置收费额度或不要勾选“是否付费”')
        }
      } else {
        this.value_ss = ''
      }
      if (!this.analyse_content) {
        return this.$message.error('内容不能为空')
      }
      let spf = { '胜': 3, '平': 1, '负': 0 }
      var formData = Qs.stringify({
        scheduleId: this.$route.params.scheduleID,
        content: this.analyse_content,
        firstChoice: spf[this.checkList[0]],
        twoChoice: spf[this.checkList[1]],
        notePrice: this.value_ss || ''
      });
      console.log(formData, spf[this.checkList[1]])
      const tokenStr = localStorage.getItem('token')
      if (!this.$getMyConfig.getConfig() && tokenStr) {
        const { data: res } = await this.$http.request({
          url: `/user/forecastNotes/`,
          method: 'POST',
          data: formData,
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
          }
        })
        this.$message.success(res.msg)
        this.analyse_content = ""
      } else {
        return this.$message.error('请先登录')
      }

    },
    // 初始笔记
    async tixtList () {
      let obj_s = {
        data_type: 'match',
        scheduleId: this.$route.params.scheduleID
      }
      var regex = /(<([^>]+)>)/ig
      const { data: res } = await this.$http.get(`/user/forecastNotes/`, { params: obj_s });
      // console.log(res)
      res.results.forEach(item => {
        // 去标签
        item.content = item.content.replace(regex, "")
        item.z_h = true
        item.goum_fs_v = "微信"
        item.goum_fs = [{
          value: '微信',
          label: '微信'
        }, {
          value: '支付宝',
          label: '支付宝'
        }, {
          value: '球冠币',
          label: '球冠币'
        },]
      })
      // 去标签
      // let result = res.data_list.forEach(item => {
      //   item.content_s = item.content.replace(regex, "")
      //   item.z_h = true

      // });
      this.textList = res.results
    },

    // 支付关闭
    On_X () {
      this.block_s_zf = false
      clearInterval(this.Polling);
    },
    //  支付方式切换
    aaa_s (v) {
      // console.log(v)
      this.goum_fs_v = v
    },
    //  是否展开
    async ONz_h (v, goum_fs_v) {
      // console.log(1111)
      const tokenStr = localStorage.getItem('token')
      if (!this.$getMyConfig.getConfig() && tokenStr) {

        const { data: res } = await this.$http.get(`/user/forecastNotes/${v}/`);
        var that = this
        if (res.code == 2415) {
          // console.log(goum_fs_v, 1234)
          let yfje = this.textList.find(item => item.noteId == v)
          // console.log(yfje.notePrice)
          this.block_s_zf = true
          this.yfje = yfje.notePrice
          let goum_fs_v = { 球冠币: 1, 微信: 2, 支付宝: 3 }
          var WXPayNote_V = Qs.stringify({
            noteId: v,
            payType: goum_fs_v[this.goum_fs_v]
          });
          const { data: WXPayNote } = await this.$http.request({
            url: `/pay/WXPayNote`,
            method: 'POST',
            data: WXPayNote_V,
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
            }
          })
          this.qrcode(WXPayNote.code_url)

          //支付笔记
          async function userPay_s () {
            const { data: res_ss } = await that.$http.get(`/user/forecastNotes/${v}/`);
            // that.textList = res_ss.results
            let obj_s = { 3: "主胜", 1: "平", 0: "负" }
            that.textList.forEach(item => {
              if (item.noteId == v) {
                item.content = res_ss.content
                item.z_h = false
                item.firstChoice = obj_s[res_ss.firstChoice]
                item.twoChoice = obj_s[res_ss.twoChoice]
              }
            })

            that.On_X()
            // console.log(res_ss, 'goumai_11')
            // console.log(that.textList, 'goumai_11')
          }


          // 微信支付
          async function myInterval () {
            var formDatas = Qs.stringify({
              out_trade_no: WXPayNote.out_trade_no
            });
            var { data: WinXinPayState } = await that.$http.request({
              url: '/pay/WinXinPayState',
              method: 'POST',
              data: formDatas,
              headers: {
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
              }
            })
            // console.log(WinXinPayState)
            if (WinXinPayState.return_code == 1) {
              userPay_s()
            }
          }
          // myInterval()
          if (WXPayNote.return_msg == 'OK' && WXPayNote.return_code == "SUCCESS") {
            this.Polling = setInterval(() => {
              myInterval()
            }, 3000)
          }
          // console.log(WXPayNote.code_url)
        } else {
          // console.log(res, 'bushigoumai')
          let obj_s = { 3: "主胜", 1: "平", 0: "负" }
          this.textList.forEach(item => {
            if (item.noteId == v) {
              item.content = res.content
              item.z_h = false
              item.firstChoice = obj_s[res.firstChoice]
              item.twoChoice = obj_s[res.twoChoice]
            }
          })
        }

      }
      else {
        return this.$message.error('登录过期请重新登录')
      }


      // console.log(res)
    },
    // 是否收回
    async ONs_q (v) {
      let obj_s = {
        data_type: 'match',
        scheduleId: this.$route.params.scheduleID
      }
      // 去标签
      var regex = /(<([^>]+)>)/ig
      const { data: res } = await this.$http.get(`/user/forecastNotes/`, { params: obj_s });
      this.textList_s = res.results
      // console.log(res)

      let textList_s = this.textList_s.find(item => item.noteId == v)
      this.textList.forEach(item => {
        if (item.noteId == v) {
          // 去标签
          item.content = textList_s.content.replace(regex, "")
          // item.content = textList_s.content
          item.firstChoice = ''
          item.twoChoice = ''
          item.z_h = true
        }
      })
      console.log(this.textList_s)
    },
    ONwrite () {
      this.active = true
    },
    ONsea () {
      this.active = false
      this.tixtList()
    },
    Oncha () {
      this.spf = false
    },
    Onbt () {
      this.spf = true
    },


    //  首选可选
    chec_s (v) {
      console.log(v)
    }

  }
}
</script>
<style lang = 'less' scoped >
a {
  &:hover {
    color: #91c1f8;
  }
}

.analyse_box {
  margin-top: 20px;
  display: flex;
  justify-content: space-between;
}
.analyse_left {
  width: 900px;
  .yhxinxi {
    display: flex;
    justify-content: space-between;
    align-items: center;
    .users {
      width: 20%;
      display: flex;
      justify-content: center;
      flex-direction: column;
      align-items: center;
    }
  }
  .yhP {
    width: 80%;
    font-size: 14px;
    /* text-indent:2em; */
    line-height: 20px;
    /* span {
      float: right;
    } */
    .ppp {
      display: -webkit-box;
      -webkit-box-orient: vertical;
      -webkit-line-clamp: 5;
      overflow: hidden;
    }
    span {
      cursor: pointer;
      &:hover {
        color: #91c1f8;
      }
    }
  }
}
.analyse_right {
  width: 240px;
}

/* 富文本 */
.fbk_box {
  .xians {
    position: relative;
  }
  .chahao {
    position: absolute;
    right: 10px;
    top: 10px;
    font-size: 26px;
    cursor: pointer;
  }
  .zf_div_ss {
    display: flex;
  }
  .is_FF {
    height: 30px;
    display: flex;
    align-items: center;
    justify-content: center;
    /* flex-direction: column; */
  }
}
.analyse_container {
  padding: 20px 0;
}
.zf_sty_ss {
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  position: fixed;
  z-index: 999;
  background: rgba(0, 0, 0, 0.2);
  .zf_sty_s {
    position: absolute;
    width: 300px;
    height: 300px;
    background: #fff;
    top: 50%;
    margin-top: -150px;
    left: 50%;
    margin-left: -150px;
    .zf_sty_p {
      text-align: center;
      margin: 20px 0;
      p {
        font-size: 14px;
        line-height: 20px;
        color: #999;
      }
    }
    .zf_sty_a {
      text-align: center;
      width: 100%;
      margin-top: 20px;
    }
    .zf_sty_X {
      position: absolute;
      right: 20px;
      top: 20px;
    }
    .zf_ewm {
      display: flex;
      justify-content: center;
    }
  }
}
.goum_fs {
  /* float: right; */
  width: 170px;
  display: flex;
  align-items: center;
  /* flex-direction: column; */
  justify-content: center;
  float: left;
  margin: 10px;
}
.span_goumai {
  display: flex;
  align-items: center;
  flex-direction: column;
  /* justify-content: center; */
  float: right;
}
</style>
<style lang = 'less'>
.is_FF {
  .el-input {
    width: 70% !important;
    margin-left: 10px !important;
  }
}

.goum_fs {
  .el-input {
    width: 100px !important;
    /* overflow: hidden; */
  }
  .el-select {
    width: 100px !important;
  }
}
</style>
