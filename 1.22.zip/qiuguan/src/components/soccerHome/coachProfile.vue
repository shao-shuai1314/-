<template>
  <div class="gWidth present_s_box">
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/index' }">首页</el-breadcrumb-item>
      <el-breadcrumb-item :to="{ path: '/soccer' }">足球中心</el-breadcrumb-item>
      <el-breadcrumb-item :to="{name:'league',params:{sclassID}}">{{this.datas[2]}}{{this.datas[0]}}</el-breadcrumb-item>
      <el-breadcrumb-item>教练简表</el-breadcrumb-item>
    </el-breadcrumb>
    <!-- 左边 -->
    <navigation :datas=[...datas]></navigation>

    <el-card style="width:942px;"
             class="fr">

      <el-table :data="coachList"
                :key="Math.random()"
                @sort-change="sortChange1"
                :row-class-name="tabRowClassName"
                border
                :header-cell-style="{
    'color': '#303133',
    'border-bottom': '1px rgb(103, 194, 58) solid',
    'background-color': 'rgb(131, 162, 202)',
    'font-size':'14px',
}"
                size="mini">
        <el-table-column prop="matchSeason"
                         align="center">
          <template slot="header"
                    slot-scope="scope">
            <span style="color:rgb(248, 51, 71);font-size: 18px;">
              {{datas[0]}}教练简表
            </span>
          </template>
          <el-table-column align="center"
                           prop="count"
                           label="序号"
                           width="40">
            <template slot-scope="scope">
              {{scope.$index+1}}
            </template>
          </el-table-column>
          <el-table-column align="center"
                           prop="teamName"
                           label="球队"
                           width="">
            <template slot-scope="scope">
              <router-link target="_blank"
                           class="aaa"
                           v-if="scope.row.teamID"
                           :to="{name:'lineup',params:{teamID:scope.row.teamID}}">{{scope.row.teamName}}
                <span v-if="scope.row.rank">[{{scope.row.rank}}]</span>
                <span v-else-if="scope.row.grouping2">[{{scope.row.grouping2}}]</span>
              </router-link>
            </template>
          </el-table-column>
          <el-table-column align="center"
                           prop="coachName"
                           label="教练"
                           width="">
            <template slot-scope="scope">
              <router-link target="_blank"
                           v-if="scope.row.coachId"
                           :to="{name:'playerDetails',params:{playerID:scope.row.coachId}}">{{scope.row.coachName}}</router-link>
            </template>
          </el-table-column>
          <el-table-column align="center"
                           prop="coachCountry"
                           label="国籍"
                           width="">
            <template slot="header"
                      slot-scope="scope">
              <span>国籍</span>
              <span class="actv"
                    @click="Onau()">排序</span>
            </template>
            <template slot-scope="scope">
              <span class="span_s"
                    :style="`background:${scope.row[scope.row.coachCountry]}`">{{scope.row.coachCountry}}</span>
            </template>
          </el-table-column>

          <el-table-column align="center"
                           label="出生年份"
                           prop="coachYear"
                           sortable
                           width="130">
          </el-table-column>
          <el-table-column align="center"
                           prop="coachMonth"
                           label="出生日期"
                           sortable
                           width="130">
          </el-table-column>
          <el-table-column align="center"
                           prop="age"
                           sortable
                           label="年龄"
                           width="80">
          </el-table-column>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>
<script >
import navigation from './SideNavigation';
export default {
  components: {
    navigation
  },
  data () {
    return {
      datas: [],
      coachList: [],
      myDate: new Date(),
      sclassID: this.$route.params.sclassID,
    };
  },
  created () {
    var temp = sessionStorage.getItem("seasonList")
    let seasonList = JSON.parse(temp);
    this.datas = [sessionStorage.getItem('sclassName'), sessionStorage.getItem('sclass_rule'), sessionStorage.getItem('matchSeason'), seasonList, sessionStorage.getItem('sclass_pic')]
    // console.log(this.$route)
    document.title = `${this.datas[2]} -  ${this.datas[0]} - 教练简表`
    this.coachList_s()
  },
  methods: {
    Onau () {
      this.au = !this.au
      if (this.au) {
        this.coachList = this.aaa()
      } else {
        this.coachList = this.coachLists_s
      }
    },
    // 重新排序
    sortChange1 (obj) {
      if (obj.prop == "coachBirthday") {
        if (obj.order == "ascending") {
          this.coachList.sort(this.compare('money'))
        } else if (obj.order == "descending") {
          this.coachList.sort(this.compares('money'))
        }
      }
    },
    aaa (num) {
      let bbb = {}
      this.coachLists.forEach(item => {
        if (!bbb.hasOwnProperty(item.coachCountry)) {
          bbb[item.coachCountry] = 0;
        }
        bbb[item.coachCountry] += 1;
        if (bbb.hasOwnProperty('null')) {
          bbb['null'] = 0;
        }
      })
      for (var i = 0; i < this.coachLists.length; i++) {
        for (var j = 0; j < this.coachLists.length - i - 1; j++) {
          let a = this.coachLists[j]
          let b = this.coachLists[j + 1]
          let aaaa = a["coachCountry"]
          let bbbb = b["coachCountry"]
          if (bbb[aaaa] == bbb[bbbb]) {
            if (aaaa > bbbb) {
              this.coachLists[j] = b
              this.coachLists[j + 1] = a
            }
          } else if (bbb[bbbb] > bbb[aaaa]) {
            this.coachLists[j] = b
            this.coachLists[j + 1] = a
          }
        }
      }
      return this.coachLists
    },
    async coachList_s () {
      let obj = {}
      if (sessionStorage.getItem('subsClassID_z')) {
        obj.subsClassID = sessionStorage.getItem('subsClassID_z')
      }
      obj.matchSeason = sessionStorage.getItem('matchSeason')
      const res = await this.$http.get(`/soccer/sclass/${this.$route.params.sclassID}/coachList/`, { params: obj })
      let coachCountry = {}
      res.data.data_list.forEach((item, index) => {
        if (!coachCountry.hasOwnProperty(item.coachCountry)) {
          coachCountry[item.coachCountry] = `rgba(${Math.floor(Math.random() * 50 * index) + ',' + Math.floor(Math.random() * 50 * index) + ',' + Math.floor(Math.random() * 50 * index)},0.4)`
        }
        item[item.coachCountry] = coachCountry[item.coachCountry]
        if (item.coachBirthday) {
          item.year = item.coachBirthday.slice(0, 4)
          item.coachYear = item.coachBirthday.slice(0, 4)
          item.coachMonth = item.coachBirthday.slice(5)
          var csrq = item.coachBirthday;
          var age = '';
          var d = new Date();
          var year = d.getFullYear();
          var month = d.getMonth() + 1;
          var day = d.getDate();
          if (month < 10) {
            month = '0' + month;
          }
          if (day < 10) {
            day = '0' + day;
          }
          var now = year + '-' + month + '-' + day;
          if (now.substring(0, 4) >= csrq.substring(0, 4) && now.substring(5, 7) >= csrq.substring(5, 7)
            && now.substring(8, 10) >= csrq.substring(8, 10)) {
            age = year - parseInt(csrq.substring(0, 4));
          } else {
            age = year - parseInt(csrq.substring(0, 4)) - 1;
          }
          item.age = age
        }
      })
      this.coachList = [].concat(res.data.data_list)
      this.coachLists = [].concat(res.data.data_list)
      this.coachLists_s = [].concat(res.data.data_list)
    },
    tabRowClassName ({ row, rowIndex }) {
      let index = rowIndex + 1;
      if (index % 2 == 0) {
        return 'warning-row'
      }
    },
  }
}
</script>
<style lang = 'less' >
.present_s_box .el-table .warning-row {
  background: rgba(160, 189, 226, 0.2) !important;
}
.present_s_box a {
  display: block;
  cursor: pointer;
  width: 100%;
  height: 100%;
  &:hover {
    color: #409eff;
  }
}
.present_s_box .el-table--mini td,
.present_s_box .el-table--mini th {
  padding: 0 !important;
}
.present_s_box .el-table .cell {
  height: 100%;
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  line-height: 36px !important;
}
.present_s_box .cell span {
  display: flex;
  align-items: center;
  display: block;
}
.span_s {
  width: 100%;
}
.present_s_box .el-table--enable-row-hover .el-table__body tr:hover > td {
  background-color: rgba(160, 189, 226, 0.5);
}

.present_s_img {
  .el-image {
    width: 30px;
    height: 30px;
    border-radius: 50%;
  }
  overflow: hidden;
  display: flex;
  justify-content: center;
  align-items: center;
}

.present_s_box .aaa {
  display: flex;
  justify-content: center;
}
.present_s_box .actv {
  height: 30px;
  margin-top: 2px;
  font-size: 12px;
  padding: 0 6px;
  line-height: 30px;
  margin-left: 10px;
  display: inline-block;
  background: #666;
  border-radius: 6px;
  color: #409eff;
  /* display: block; */
  cursor: pointer;
}
</style>