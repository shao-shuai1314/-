<template>
  <div class="gWidth injured_box">
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/index' }">首页</el-breadcrumb-item>
      <el-breadcrumb-item :to="{ path: '/soccer' }">足球中心</el-breadcrumb-item>
      <el-breadcrumb-item>球员信息统计</el-breadcrumb-item>
    </el-breadcrumb>
    <!-- 左边 -->
    <navigation :datas=[...datas]></navigation>
    <el-card style="width:942px;"
             class="fr">
      <el-tabs v-model="activeName"
               @tab-click="handleClick">
        <el-tab-pane label="射手榜"
                     name="first"></el-tab-pane>
        <el-tab-pane label="红黄牌统计"
                     name="second"></el-tab-pane>
      </el-tabs>
      <el-table :data="tableData"
                :row-class-name="tabRowClassName"
                border
                :header-cell-style="{
    'color': '#303133',
    'border-bottom': '1px rgb(103, 194, 58) solid',
    'background-color': 'rgb(131, 162, 202)',
    'font-size':'14px',
}"
                size="mini">
        <el-table-column prop="matchSeason"
                         align="center">
          <template slot="header"
                    slot-scope="scope">
            <span style="color:rgb(248, 51, 71);font-size: 18px;">
              {{datas[0]}}球员信息统计
            </span>
          </template>
          <el-table-column align="center"
                           prop="count"
                           width="40"
                           label="排名">
            <template slot-scope="scope">
              {{scope.$index+1}}
            </template>
          </el-table-column>
          <el-table-column align="center"
                           prop="playerName"
                           label="球员">
          </el-table-column>
          <el-table-column align="center"
                           prop="teamName"
                           label="球队">
            <template slot-scope="scope">
              <router-link target="_blank"
                           :to="{name:'lineup',params:{teamID:scope.row.teamID}}">{{scope.row.teamName}}
              </router-link>
            </template>
          </el-table-column>
          <el-table-column align="center"
                           prop="count"
                           width="100"
                           label="出场次数">
          </el-table-column>
          <el-table-column align="center"
                           prop="isFirstTeam"
                           width="80"
                           label="首发次数">
          </el-table-column>
          <el-table-column align="center"
                           prop="notPenaltyGoals"
                           width="60"
                           label="总进球">
          </el-table-column>
          <el-table-column align="center"
                           prop="penaltyGoals"
                           width="60"
                           label="点球数">
          </el-table-column>
          <el-table-column align="center"
                           prop="red"
                           width="60"
                           label="红牌">
          </el-table-column>
          <el-table-column align="center"
                           prop="yellow"
                           width="60"
                           label="黄牌">
          </el-table-column>
          <el-table-column align="center"
                           width="100"
                           prop="playingTime"
                           label="总上场时间">
          </el-table-column>

        </el-table-column>
      </el-table>

    </el-card>
  </div>
</template>
<script >
import navigation from './SideNavigation';
export default {
  components: {
    navigation
  },
  data () {
    return {
      datas: [],
      tableData: [],
      activeName: 'first'
    };
  },
  created () {
    var temp = sessionStorage.getItem("seasonList")
    let seasonList = JSON.parse(temp);
    this.datas = [sessionStorage.getItem('sclassName'), sessionStorage.getItem('sclass_rule'), sessionStorage.getItem('matchSeason'), seasonList, sessionStorage.getItem('sclass_pic')]
    document.title = `${this.datas[2]} -  ${this.datas[0]} - 射手榜`;
    this.playerTechStatistics()
  },
  methods: {
    async playerTechStatistics () {
      let obj = {}
      if (sessionStorage.getItem('subsClassID_z')) {
        obj.subsClassID = sessionStorage.getItem('subsClassID_z')
      }
      obj.matchSeason = sessionStorage.getItem('matchSeason')
      const res = await this.$http.get(`/soccer/sclass/${this.$route.params.sclassID}/playerTechStatistics/`, { params: obj });
      this.tableData_s = res.data.data
      this.tableData = this.tableData_s.filter((item) => { return item.notPenaltyGoals || item.penaltyGoals })
    },
    // xuanxiangka 
    handleClick (tab) {
      if (tab.name == "second") {
        this.tableData = this.tableData_s.filter((item) => { return item.red || item.yellow })
        for (var i = 0; i < this.tableData.length; i++) {
          for (var j = 0; j < this.tableData.length - i - 1; j++) {
            let a = this.tableData[j]
            let b = this.tableData[j + 1]
            let aa = a["red"]
            let aaa = a["yellow"]
            let aaaa = aa + aaa
            let bb = b["red"]
            let bbb = b["yellow"]
            let bbbb = bb + bbb
            if (bb > aa) {
              this.tableData[j] = b
              this.tableData[j + 1] = a
            } else if (bb == aa) {
              if (bbb > aaa) {
                this.tableData[j] = b
                this.tableData[j + 1] = a
              }
            }
          }
        }
      } else {
        this.tableData = this.tableData_s.filter((item) => { return item.notPenaltyGoals || item.penaltyGoals })
      }
    },
    tabRowClassName ({ row, rowIndex }) {
      let index = rowIndex + 1;
      if (index % 2 == 0) {
        return 'warning-row'
      }
    },
  }
}
</script>
<style lang = 'less' >
.injured_box .el-table .warning-row {
  background: rgba(160, 189, 226, 0.2) !important;
}
.injured_box a {
  display: block;
  cursor: pointer;
  width: 100%;
  height: 100%;
  &:hover {
    color: #409eff;
  }
}
.injured_box .el-table--mini td,
.injured_box .el-table--mini th {
  padding: 0 !important;
}
.injured_box .el-table .cell {
  height: 100%;
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  line-height: 36px !important;
}
.injured_box .cell span {
  display: flex;
  align-items: center;
  display: block;
}
.injured_box .el-table--enable-row-hover .el-table__body tr:hover > td {
  background-color: rgba(160, 189, 226, 0.5);
}
.injured_box .fy {
  display: flex;
  justify-content: center;
}
</style>