<template>
  <div class="gWidth new_ss">
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/index' }">首页</el-breadcrumb-item>
      <el-breadcrumb-item :to="{ path: '/news' }">资讯</el-breadcrumb-item>
    </el-breadcrumb>
    <div class="qrcode"
         ref="qrCodeUrl"></div>
    <el-card class="gWidth box_new">
      <h2>{{li.title}}</h2>
      <h6> &nbsp; {{li.publicTime}} {{li.reprinted}} </h6>
      <el-divider></el-divider>
      <div class="box_new_p">
        <p v-html="li.content"></p>
      </div>
    </el-card>
  </div>
</template>
<script >
import QRCode from 'qrcodejs2'
export default {
  data () {
    return {
      li: []
    };
  },
  created () {
    this.list();
  },
  mounted () {
    this.creatQrCode();
  },
  methods: {
    async list () {
      const { data: res } = await this.$http.get(`/journalism/${this.$route.params.recordId}/`);
      // res.content = res.content.slice(res.content.indexOf('</h1>') + 5)
      this.li = res
      document.title = `${this.li.title} -  资讯详情页`
    },
    creatQrCode () {
      var qrcode = new QRCode(this.$refs.qrCodeUrl, {
        text: `${window.location.href}`, // 需要转换为二维码的内容
        width: 90,
        height: 90,
        colorDark: '#000000',
        colorLight: '#ffffff',
        correctLevel: QRCode.CorrectLevel.H
      })
    },

  }
}
</script>
<style lang = 'less' scoped >
/* pc端 */
/* @media all and (max-width: 1024px) { */
.box_new {
  background: #fff;
  h2 {
    width: 100%;
    text-align: center;
    line-height: 50px;
  }
  h6 {
    text-align: center;
    font-size: 16px;
  }
  .box_new_p {
    width: 1000px;
    margin-left: 80px;
  }
}
.qrcode {
  display: inline-block;
  position: absolute;
  top: 170px;
  margin-left: 20px;
  img {
    width: 102px;
    height: 102px;
    background-color: #fff;
    padding: 6px;
    box-sizing: border-box;
  }
}
/* } */

/* 适配手机 */
/* @media all and (max-width: 768px) {
  .qrcode {
    display: none;
  }
  .box_new {
    width: 100%; 
    overflow: hidden;
  }
  h2 {
    color: red;
    font-size: 1.6rem !important;
  }
} */
@media all and (max-width: 480px) {
  /* .gWidth {
    width: 100%;
  } */
  .qrcode {
    display: none;
  }
  /* .box_new {
    min-width: 480px !important;
    overflow: hidden;
  }
  .box_new_p {
    min-width: 460px !important;
    overflow: hidden;
  }
  h2 {
    color: red;
    font-size: 1.2rem !important;
    line-height: 2rem !important;
  } */
}
</style>
<style>
.box_new p {
  text-indent: 2em;
  line-height: 26px;
  /* width: 98%; */
}
.box_new img {
  width: 700px !important;
  transform: translateX(100px) !important;
  margin: 20px 0 !important;
}
</style>　