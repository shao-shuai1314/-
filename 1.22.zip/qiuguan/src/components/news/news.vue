<template>
  <div class="gWidth matchNew_box">
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/index' }">首页</el-breadcrumb-item>
      <el-breadcrumb-item>资讯</el-breadcrumb-item>
    </el-breadcrumb>
    <el-card class="matchNew_box_left">
      <div class="New_headers">
        <h1>联赛新闻</h1>
        <div>
          <el-date-picker v-model="value2"
                          align="right"
                          type="date"
                          @change='ondate'
                          value-format="yyyy-MM-dd"
                          placeholder="选择日期"
                          :picker-options="pickerOptions">
          </el-date-picker>
          <el-input style="width:220px;margin-left:20px;"
                    placeholder="请输入内容"
                    prefix-icon="el-icon-search"
                    @change="keyword_s"
                    v-model="input1">
          </el-input>
        </div>
      </div>
      <el-divider></el-divider>
      <el-tabs v-model="activeName"
               @tab-click="handleClick">
        <el-tab-pane label="英超"
                     name="36"></el-tab-pane>
        <el-tab-pane label="德甲"
                     name="8"></el-tab-pane>
        <el-tab-pane label="意甲"
                     name="34"></el-tab-pane>
        <el-tab-pane label="西甲"
                     name="31"></el-tab-pane>
        <el-tab-pane label="法甲"
                     name="11"></el-tab-pane>
        <el-tab-pane label="全部"
                     name="six"></el-tab-pane>
      </el-tabs>
      <ul class="">
        <li v-for="(item,index) in new_list"
            :key="index">
          <router-link target="_blank"
                       :to="{name:'newdetail',params:{recordId:item.recordId}}">
            <div class="item_new">
              <div class="item_new_image">
                <el-image :src="item.img?`https://www.qiuguantx.com/imgs/Journalism/${item.img}`: ''"></el-image>
              </div>
              <div class="item_new_text">
                <p>{{item.title}}</p>
                <div class="item_new_text_t">
                  <span>{{item.publicTime}}</span>
                  <b>{{item.Reprinted}}</b>
                </div>
              </div>
            </div>
            <el-divider></el-divider>
          </router-link>
        </li>
      </ul>
      <p class="load-more"
         @click="loadMore">点击加载更多</p>
    </el-card>
    <!-- 新闻右边内容 -->
    <div class="news_right_box fr">
      <h3 style="margin-left:10px;">球冠热门新闻</h3>
      <el-divider></el-divider>
      <div class="news_right_top">
        <div class="img_tit"
             v-for="(item,index) in results.slice(0,6)"
             :key="index">
          <div class="imgs">
            <el-image :src="item.img?`https://www.qiuguantx.com/imgs/Journalism/${item.img}`: ''"></el-image>
          </div>
          <p>
            <router-link target="_blank"
                         :to="{name:'newdetail',params:{recordId:item.recordId}}">{{item.title}}</router-link>

          </p>
        </div>

      </div>
      <div class="news_right_bottom">
        <p v-for="(item,index) in results.slice(6)"
           :key="index">
          <router-link target="_blank"
                       :to="{name:'newdetail',params:{recordId:item.recordId}}">{{item.title}}</router-link>
        </p>
      </div>
    </div>
  </div>
</template>
<script >
export default {
  data () {
    return {
      new_list: [],
      scroll_id: '',
      activeName: '36',
      pickerOptions: {
        disabledDate (time) {
          return time.getTime() > Date.now();
        },
        shortcuts: [{
          text: '今天',
          onClick (picker) {
            picker.$emit('pick', new Date());
          }
        }, {
          text: '昨天',
          onClick (picker) {
            const date = new Date();
            date.setTime(date.getTime() - 3600 * 1000 * 24);
            picker.$emit('pick', date);
          }
        }, {
          text: '一周前',
          onClick (picker) {
            const date = new Date();
            date.setTime(date.getTime() - 3600 * 1000 * 24 * 7);
            picker.$emit('pick', date);
          }
        }]
      },
      value2: '',
      input1: '',
      scroll_id: '',
      results: []
    };
  },
  created () {
    this.jk()
    this.rm()
  },
  methods: {
    async rm () {
      let obj = { hotNews: 1 }
      const { data: res } = await this.$http.get(`/journalism`, { params: obj });
      this.results = res.data
    },
    async jk (scroll_id) {
      let obj = {}
      if (this.activeName == 'six') {
        obj.keyword = this.input1
        obj.sclassId = ''
        obj.publicTime = this.value2
      } else {
        obj.keyword = this.input1
        obj.sclassId = this.activeName
        obj.publicTime = this.value2
      }

      if (scroll_id) {
        obj.scroll_id = scroll_id
      }
      const { data: res } = await this.$http.get(`/journalism/`, { params: obj });
      if (res.data.length != 0) {
        if (scroll_id) {
          this.new_list.push(...res.data)
        } else {
          this.new_list = res.data
        }
        this.scroll_id = res.scroll_id
      } else {
        return this.$message.error('已经加载全部')
        this.scroll_id = ''
      }
    },
    loadMore () {
      if (this.scroll_id) {
        this.jk(this.scroll_id)
      } else {
        return this.$message.error('已经加载全部')
      }
    },
    // 联赛切换
    handleClick (tab, event) {
      this.activeName = tab.name
      this.value2 = ''
      this.input1 = ''
      this.scroll_id = ''
      this.jk()
    },
    // 时间选择
    async ondate () {
      this.scroll_id = ''
      this.input1 = ''
      this.jk()
    },
    // 搜索
    keyword_s (v) {
      this.activeName = 'six'
      this.input1 = v
      this.value2 = ''
      this.jk()
    }
  }

}
</script>
<style lang = 'less' scoped >
.matchNew_box {
  margin-top: 20px;
  .matchNew_box_left {
    .New_headers {
      display: flex;
      justify-content: space-between;
    }
    float: left;
    width: 900px;
    .item_new {
      display: flex;
      .item_new_image {
        width: 150px;
        height: 100px;
        overflow: hidden;
        margin-right: 20px;
        .el-image {
          width: 150px;
          height: 100px;
        }
      }
      .item_new_text {
        width: 100%;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        p {
          font-size: 18px;
          color: #333;
        }
        .item_new_text_t {
          display: flex;
          justify-content: space-between;
          span {
            font-size: 12px;
            color: #999;
          }
          b {
            font-size: 12px;
            color: #999;
          }
        }
      }
    }
    .load-more {
      width: 100%;
      height: 50px;
      line-height: 50px;
      text-align: center;
      background: #ececec;
      color: #888;
      cursor: pointer;
    }
  }
  .news_right_box {
    width: 280px;
    background: #fff;
    padding: 20px 0;

    h6 {
      margin-left: 10px;
    }
    .news_right_top {
      color: #898a89;
      margin-left: 10px;
      .img_tit {
        height: 70px;
        width: 260px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 6px;
        &:hover .el-image {
          transform: scale(1.2);
          transition: 0.2s;
        }
        .imgs {
          width: 100px;
          height: 70px;
          overflow: hidden;
          .el-image {
            width: 100%;
            height: 100%;
          }
        }
        p {
          width: 150px;
          font-size: 14px;
          display: -webkit-box;
          -webkit-box-orient: vertical;
          -webkit-line-clamp: 2;
          overflow: hidden;
        }
      }
    }
    .news_right_bottom {
      width: 260px;
      margin-left: 10px;
      p {
        width: 100%;
        font-size: 14px;
        line-height: 30px;
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 1;
        overflow: hidden;
      }
    }
  }
}
</style>