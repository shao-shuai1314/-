<template>
  <div class="gWidth zucai_box"
       v-cloak>
    <el-card>
      <!-- 选项 -->
      <el-tabs v-model="activeName"
               @tab-click="handleClick">
        <el-tab-pane label="足彩"
                     name="zc14"></el-tab-pane>
        <el-tab-pane label="竞彩"
                     name="jczq"></el-tab-pane>
        <el-tab-pane label="北京单场"
                     name="bd"></el-tab-pane>
      </el-tabs>
      <div class="zuc_s">
        <div>
          <el-select v-model="value"
                     @change="onOptions"
                     placeholder="请选择">
            <el-option v-for="(item,index) in options"
                       :key="index"
                       :label="item.val"
                       :value="{value:item.val,label:item.time}">
            </el-option>
          </el-select>
          <!-- 最新彩票比赛 -->
          <el-link :type="value==item?'primary':''"
                   style="margin:0 10px"
                   v-for="item in new_nums"
                   :key="item.val"
                   @click="new_num(item)">{{item.val}}</el-link>
        </div>
        <div>
          <el-checkbox style="margin-left:20px"
                       v-if="isTrue"
                       v-model="checked"
                       @change="onchecked">隐藏已停售比赛</el-checkbox>
          <el-select v-if="isTrue"
                     v-model="value_s"
                     style="margin-left:20px"
                     @change="onOptions_s"
                     placeholder="日期筛选">
            <el-option v-for="(item,index) in options_s"
                       :key="index"
                       :label="item"
                       :value="index">
            </el-option>
          </el-select>
        </div>

        <div class="dd"
             v-if="zucai_true">
          <p class="ppp">
            倍数：
            <el-input :value="v_b"
                      @input="e => (v_b = isnumber(e))"></el-input>
            <span style="margin-right:20px">1-99的整数</span>
          </p>

          <div>
            <span>{{v_b}}倍，</span>
            <span>共
              <b>{{val_xz}}</b> 注 , </span>
            <span>
              <b>{{val_M}}</b>元</span>
          </div>
        </div>

      </div>

      <div v-if="isTrue"
           style="margin-top:10px">
        <b>
          {{weekday}}
        </b>
      </div>

      <el-table :data="tableData"
                size="mini"
                border
                :header-cell-style="{
    'color': '#303133',
    'border-bottom': '1px rgb(103, 194, 58) solid',
    'text-align':'center',
    'font-size':'16px',
}"
                style="width: 100%">
        <el-table-column prop="num"
                         label=""
                         align="center"
                         width="30">
        </el-table-column>
        <el-table-column prop="matchtime"
                         label="比赛时间"
                         align="center"
                         width="">
          <template slot-scope="scope">
            <div class="shij"
                 style="display: flex;justify-content: center"
                 :class="scope.row.gX?'guanxi':''"
                 :style="{ color: (scope.row.color_jl?scope.row.color_jl:scope.row.color_sj), fontWeight:(scope.row.color_jl||scope.row.color_sj?900:'')  }">
              <el-tooltip class="item"
                          v-if="scope.row.gX"
                          effect="light"
                          placement="top">
                <div slot="content"
                     v-for="(item,i) in scope.row.guanxi"
                     :key="i">
                  <b>{{item}}</b>
                </div>
                <span>{{scope.row.matchtime.replace("T"," ")　}}</span>
              </el-tooltip>
              <el-tooltip class="item"
                          v-else-if="scope.row.color_jl"
                          effect="light"
                          placement="top">
                <div slot="content">
                  <p>
                    <b>主队教练生日：{{scope.row.homeCoachBirthday}}</b>
                  </p>
                  <p>
                    <b>客队教练生日：{{scope.row.guestCoachBirthday}}</b>
                  </p>
                </div>
                <span>{{scope.row.matchtime.replace("T"," ")　}}</span>
              </el-tooltip>
              <el-tooltip class="item"
                          v-else-if="scope.row.color_sj"
                          effect="light"
                          placement="top">
                <div slot="content">
                  <p>
                    <b>主队创建日期：{{scope.row.homeFoundDate}}</b>
                  </p>
                  <p>
                    <b>客队创建日期：{{scope.row.guestFoundDate}}</b>
                  </p>
                </div>
                <span>{{scope.row.matchtime.replace("T"," ")　}}</span>
              </el-tooltip>
              <span v-else-if="scope.row.matchtime">{{scope.row.matchtime.replace("T"," ")　}}</span>
              <!-- <div v-if="scope.row.gX"
                   class="cell_h">
                <p class="cell_p"
                   v-for="(item,i) in scope.row.guanxi"
                   :key="i">
                  <b>{{item}}</b>
                </p>
              </div>
              <div v-if="scope.row.color_jl"
                   class="cell_h">
                <p class="cell_p">主队教练生日：{{scope.row.homeCoachBirthday}}</p>
                <p class="cell_p">客队教练生日：{{scope.row.guestCoachBirthday}}</p>
              </div>
              <div v-if="scope.row.color_sj"
                   class="cell_h">
                <p class="cell_p">主队创建日期：{{scope.row.homeFoundDate}}</p>
                <p class="cell_p">客队创建日期：{{scope.row.guestFoundDate}}</p>
              </div> -->
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="sclassName"
                         label="联  赛"
                         align="center"
                         width="80">
          <template slot-scope="scope">
            <div style="display: flex;justify-content: center">
              <div style="width:150px;font-weight: 900;">
                <router-link target="_blank"
                             v-if="scope.row.sclassId"
                             :style="{'color':scope.row.color?scope.row.color:''}"
                             :to="{name:'league',params:{sclassID:scope.row.sclassId}}">{{scope.row.sclassName}}</router-link>
              </div>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="homeName"
                         label="主  队"
                         align="center"
                         width="">
          <template slot-scope="scope">
            <div class="cell_j">
              <router-link target="_blank"
                           v-if="scope.row.hometeamId"
                           :to="{name:'lineup',params:{teamID:scope.row.hometeamId}}">{{scope.row.homeName}}</router-link>
              <b class="cell_s">{{scope.row.homeCoachName}}</b>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="address"
                         align="center"
                         width="50"
                         label="比  分">
          <template slot-scope="scope">
            <div @click="getmatchSeason(scope.row.matchSeason,scope.row.sclassName,scope.row.scheduleId)"
                 style="cursor: pointer;">
              <span v-if="scope.row.matchState == -1">
                <span style="color:rgb(244, 104, 89);font-weight: 900;">{{scope.row.homeScore}}-{{scope.row.guestScore}}</span>
              </span>
              <span v-else>VS</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="guestName"
                         align="center"
                         label="客  队">
          <template slot-scope="scope">
            <div class="cell_j">
              <router-link target="_blank"
                           v-if="scope.row.guestteamId"
                           :to="{name:'lineup',params:{teamID:scope.row.guestteamId}}">{{scope.row.guestName}}</router-link>
              <b class="cell_s">{{scope.row.guestCoachName}}</b>
            </div>
          </template>
        </el-table-column>
        <!-- <el-table-column v-if="sty_name == 'zc14'"
                         prop="guanxi"
                         align="center"
                         label="教练关系">
          <template slot-scope="scope">
            <div v-for="(item,i) in scope.row.guanxi"
                 class="cell_h"
                 :key="i">
              <span style="font-size:12px">
                {{item}}
              </span>
            </div>
          </template>
        </el-table-column> -->
        <el-table-column prop="scheduleId"
                         v-if="zucai_true"
                         align="center"
                         width="180"
                         label="欧赔">
          <template slot-scope="scope">
            <div v-for="(item,i) in oddsList"
                 :key="i">
              <div v-if="item.scheduleID == scope.row.scheduleId"
                   class="oddsList">
                <!-- <span>{{sum}}</span> -->
                <span v-if="scope.row.matchState == -1"
                      :class="`${scope.row.homeScore > scope.row.guestScore?'ys_s':''}`">
                  {{item.firstUpOdds}}
                </span>
                <span v-else>
                  {{item.firstUpOdds}}
                </span>
                <span v-if="scope.row.matchState == -1"
                      :class="`${scope.row.homeScore == scope.row.guestScore?'ys_s':''}`">
                  {{item.firstGoal}}
                </span>
                <span v-else>
                  {{item.firstGoal}}
                </span>
                <span v-if="scope.row.matchState == -1"
                      :class="`${scope.row.guestScore > scope.row.homeScore?'ys_s':''}`">
                  {{item.firstDownOdds}}
                </span>
                <span v-else>
                  {{item.firstDownOdds}}
                </span>
              </div>
            </div>
          </template>
        </el-table-column>
        <el-table-column v-if="zucai_true"
                         prop="guestName"
                         align="center"
                         label="选 项">
          <template slot-scope="scope">
            <div class="quan_tj">
              <el-button size="mini"
                         :type="`${scope.row.col3?'primary':''}`"
                         @click="onC(scope.row.o3,scope.$index)"
                         circle>{{scope.row.o3}}</el-button>
              <el-button size="mini"
                         :type="`${scope.row.col1?'primary':''}`"
                         @click="onC(scope.row.o1,scope.$index)"
                         circle>{{scope.row.o1}}</el-button>
              <el-button size="mini"
                         :type="`${scope.row.col0?'primary':''}`"
                         @click="onC(scope.row.o0,scope.$index)"
                         circle>{{scope.row.o0}}</el-button>
              <span style="cursor:pointer"
                    @click="onC_che(scope.row.o3,scope.$index)">全</span>
            </div>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>
<script >
export default {
  data () {
    return {
      tableData: [],
      options: [],
      value: '',
      new_nums: [],
      sty_name: 'zc14',
      options_s: [],
      value_s: '',
      timelist: [],
      weekdayL: [],
      weekday: '',
      isTrue: false,
      act: false,
      activeName: 'zc14',
      jkname: 'zc14',
      checked: false,
      zucai_true: true,
      val_xz: 0,
      val_M: 0,
      v_b: 1,
      oddsList: [
        {
          col0: false,
          col1: false,
          col3: false,
          o_list: 0
        }
      ],
    };
  },
  created () {
    this.onDataList('zc14')
  },
  watch: {
    v_b (v) {
      // console.log(v == '')
      if (v <= 99) {
        this.v_b = v
        if (this.v_b) {
          this.val_M = this.v_b * this.val_M_s
        }
      } else if (v > 99 || v == '') {
        this.v_b = 1
        if (this.v_b) {
          this.val_M = this.v_b * this.val_M_s
        }
      }
    }
  },
  computed: {
    // sum: function () {
    //   return this.oddsList.find(item => {
    //     return item.scheduleID == 1907177
    //   })
    // },
  },

  methods: {
    // 点击跳转
    getmatchSeason (matchSeason, sclassName, scheduleId) {
      sessionStorage.setItem("matchSeason", matchSeason);
      sessionStorage.setItem("sclassName", sclassName);
      let routeUrl = this.$router.resolve({
        name: "history",
        params: { scheduleID: scheduleId }
      });
      window.open(routeUrl.href, '_blank');
    },
    onC_che (v, i) {
      this.tableData[i].checked_q = !this.tableData[i].checked_q
      if (this.tableData[i].checked_q) {
        this.tableData[i].col0 = true
        this.tableData[i].col1 = true
        this.tableData[i].col3 = true
      } else {
        this.tableData[i].col0 = false
        this.tableData[i].col1 = false
        this.tableData[i].col3 = false
      }
      this.js_aa()
      this.$set(this.tableData, i, this.tableData[i])
    },
    js_aa () {
      // 计算
      this.tableData.forEach(item => {
        if (item.col0 && item.col1 && item.col3) {
          item.o_list = 3
        } else if (item.col0 && item.col1 || item.col0 && item.col3 || item.col1 && item.col3) {
          item.o_list = 2
        } else if (item.col0 || item.col3 || item.col1) {
          item.o_list = 1
        } else {
          item.o_list = 0
        }
      })
      let a1 = this.tableData.filter(item => item.o_list == 1)
      let a2 = this.tableData.filter(item => item.o_list == 2)
      let a3 = this.tableData.filter(item => item.o_list == 3)

      // console.log(a1, a2, a3)
      if (a1.length + a2.length + a3.length == 14) {
        this.val_xz = Math.pow(1, a1.length) * Math.pow(2, a2.length) * Math.pow(3, a3.length)
        if (this.v_b) {
          this.val_M = this.val_xz * 2 * this.v_b
        } else {
          this.val_M = this.val_xz * 2
        }
        this.val_M_s = this.val_xz * 2
      } else {
        this.val_xz = 0
        this.val_M = 0
      }

    },
    // 14场点击
    onC (v, i) {
      let aa = 'col' + v
      this.tableData[i][aa] = !this.tableData[i][aa]
      this.js_aa()
      this.$set(this.tableData, i, this.tableData[i])
    },
    isnumber (val) {
      val = val.replace(/[^0-9]/gi, "");
      // 此处还可以限制位数以及大小
      if (val >= 1 && val <= 99) {
        this.v_b = val
        if (this.v_b) {
          this.val_M = this.v_b * this.val_M_s
        }
      } else {
        this.v_b = 1
        if (this.v_b) {
          this.val_M = this.v_b * this.val_M_s
        }
      }
      return val;
    },
    async onDataList (val, i) {
      this.jkname = i
      let obj = {}
      if (i) {
        obj.issueNum = i
      }
      const res = await this.$http.get(`zucai/${val}/`, { params: obj });
      this.tableDatas = res.data
      res.data.data_obj.match_list.forEach((item, index) => {
        if (item.guanxi && item.guanxi.length) {
          item.gX = true
        }
        if (item.homeCoachBirthday) {
          var z_s = item.homeCoachBirthday.split('-')
        }
        if (item.guestCoachBirthday) {
          var k_s = item.guestCoachBirthday.split('-')
        }
        if (item.homeFoundDate) {
          var z_c = item.homeFoundDate.split('-')
        }
        if (item.guestFoundDate) {
          var k_c = item.guestFoundDate.split('-')
        }
        if (item.matchtime) {
          var d_b = item.matchtime.split('T')[0].split('-')
        }
        if (d_b && z_s && k_s && d_b.length == 3 && z_s.length == 3 && k_s.length == 3) {
          //  主客教练生日
          let oDate1 = new Date(d_b[0], z_s[1], z_s[2]);
          let oDate2 = new Date(d_b[0], k_s[1], k_s[2]);
          let oDate3 = new Date(d_b[0], d_b[1], d_b[2]);
          let nTime1 = oDate1.getTime() - oDate3.getTime();
          let nTime2 = oDate2.getTime() - oDate3.getTime();
          // console.log(nTime1 / (1000 * 3600 * 24))
          // console.log('k   ' + nTime2 / (1000 * 3600 * 24))

          if (Math.floor(nTime1 / (1000 * 3600 * 24)) <= 3 && Math.floor(nTime1 / (1000 * 3600 * 24)) >= 0 || Math.floor(nTime1 / (1000 * 3600 * 24)) >= -3 && Math.floor(nTime1 / (1000 * 3600 * 24)) <= 0) {
            // console.log(123)
            item.color_jl = `rgb(244, 104, 89)`
          }
          if (Math.floor(nTime2 / (1000 * 3600 * 24)) <= 3 && Math.floor(nTime2 / (1000 * 3600 * 24)) >= 0 || Math.floor(nTime2 / (1000 * 3600 * 24)) >= -3 && Math.floor(nTime2 / (1000 * 3600 * 24)) <= 0) {
            // console.log(123)
            item.color_jl = `rgb(244, 104, 89)`
          }
        }
        if (d_b && z_c && k_c && d_b.length == 3 && z_c.length == 3 && k_c.length == 3) {
          let oDate1 = new Date(d_b[0], z_c[1], z_c[2]);
          let oDate2 = new Date(d_b[0], k_c[1], k_c[2]);
          let oDate3 = new Date(d_b[0], d_b[1], d_b[2]);
          let nTime1 = oDate1.getTime() - oDate3.getTime();
          let nTime2 = oDate2.getTime() - oDate3.getTime();
          if (Math.floor(nTime1 / (1000 * 3600 * 24)) <= 3 && Math.floor(nTime1 / (1000 * 3600 * 24)) >= 0 || Math.floor(nTime1 / (1000 * 3600 * 24)) >= -3 && Math.floor(nTime1 / (1000 * 3600 * 24)) <= 0) {
            item.color_sj = `rgb(60, 60, 255)`
          }
          if (Math.floor(nTime2 / (1000 * 3600 * 24)) <= 3 && Math.floor(nTime2 / (1000 * 3600 * 24)) >= 0 || Math.floor(nTime2 / (1000 * 3600 * 24)) >= -3 && Math.floor(nTime2 / (1000 * 3600 * 24)) <= 0) {
            item.color_sj = `rgb(60, 60, 255)`
          }
        }
      })
      this.tableData = res.data.data_obj.match_list
      //  更改切换字符串
      let history_nums = [], new_nums = []
      res.data.history_nums.forEach(item => {
        let aa = {}
        aa.val = item
        history_nums.push(aa)
      })
      res.data.new_nums.forEach(item => {
        let aa = {}
        aa.val = item
        new_nums.push(aa)
      })
      this.options = history_nums
      this.value = res.data.data_obj.issueNum
      this.new_nums = new_nums
      // this.new_nums = res.data.new_nums
      if (val == 'zc14') {
        this.isTrue = false
        // 更改切换字符串
        let history_nums = [], new_nums = []
        res.data.history_nums.forEach(item => {
          let aa = {}
          aa.val = item.slice(2)
          aa.time = item.slice(0, 2)
          history_nums.push(aa)
        })
        res.data.new_nums.forEach(item => {
          let aa = {}
          aa.val = item.slice(2)
          aa.time = item.slice(0, 2)
          new_nums.push(aa)
        })
        this.value = res.data.data_obj.issueNum.slice(2)
        this.options = history_nums
        this.new_nums = new_nums
        this.zucai_true = true
        let scheduleId_l = []
        this.tableData.forEach(item => {
          item.o3 = 3
          item.o1 = 1
          item.o0 = 0
          item.col0 = false
          item.col1 = false
          item.col3 = false
          item.o_list = 0
          item.checked_q = false
          scheduleId_l.push(item.scheduleId)
        })

        let obj = {}
        obj.scheduleIDs = scheduleId_l.join(",")
        obj.companyID = 281
        obj.oddsType = 3
        const shceduleOdds = await this.$http.get('odds/shceduleOdds/', { params: obj });
        this.oddsList = shceduleOdds.data.oddsList
        this.tableData.forEach(item => {
          let a_s = shceduleOdds.data.oddsList.find(it => it.scheduleID == item.scheduleId)
          if (a_s) {
            item.firstUpOdds = a_s.firstUpOdds
            item.firstGoal = a_s.firstGoal
            item.firstGoal = a_s.firstGoal
            item.oddsID = a_s.oddsID
          }
        })
        // console.log(this.tableData)
      }

      if (val == 'jczq') {
        this.zucai_true = false
      }


      if (val == 'bd') {

        let list_s = []

        // 时间去重、
        res.data.data_obj.match_list.forEach(item => {
          if (item.matchtime) {
            list_s.push(item.matchtime.slice(0, 10))
          }
        })
        //日期排序
        function sortDownDate (a, b) {
          return Date.parse(a) - Date.parse(b);
        }
        list_s.sort(sortDownDate)



        var Today = new Date();

        var weekday = ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"];


        var s1 = Today.getFullYear() + "-" + (Today.getMonth() + 1) + "-" + Today.getDate();
        // console.log(s1)
        var s11 = new Date(`${s1} 10:00:00`).getTime()


        let list_s_s = [...new Set(list_s)]
        let timelist_s = []
        this.options_s = []
        let weekdayL_s = []
        list_s_s.forEach(item => {
          // 当前日期加一
          let startDate = new Date(item)
          startDate = +startDate + 1000 * 60 * 60 * 24;
          startDate = new Date(startDate);
          var nextStartDate = startDate.getFullYear() + "-" + (startDate.getMonth() + 1) + "-" + startDate.getDate();

          var s11 = new Date(`${item} 10:00:00`).getTime()
          var s22 = new Date(`${nextStartDate} 10:00:00`).getTime()
          let aa = { start: s11, end: s22 }
          // 周几
          var myDate = new Date(Date.parse(item.replace(new RegExp("-", "gm"), "/")));
          let bb = `${weekday[myDate.getDay()]}  ${item}  [10:00 -- 次日 10:00]}`

          weekdayL_s.push(bb)
          timelist_s.push(aa)
          this.options_s.push(item)
        })
        // console.log(timelist_s)
        this.timelist = timelist_s
        this.weekdayL = weekdayL_s
        this.options_s.push('全部')

        this.zucai_true = false
        this.isTrue = true
      } else {
        this.isTrue = false
      }

      // console.log(this.tableData)
    },
    // 最新彩票切换
    new_num (tade) {
      // console.log(tade.time, tade.val)
      let v = ''
      if (this.sty_name == 'zc14') {
        v = tade.time + tade.val
      } else {
        v = tade.val
      }
      // console.log(v)
      this.onDataList(this.sty_name, v)
    },
    // 足彩切换
    async onOptions (params) {
      // console.log(params)
      let v = ''
      if (this.sty_name == 'zc14') {
        this.tableData_aaa
        v = params.label + params.value
      } else {
        v = params.value
      }
      this.onDataList(this.sty_name, v)
      this.tableData = this.tableDatas.data_obj.match_list
      let scheduleId_l = []
      this.tableData.forEach(item => {
        item.o3 = 3
        item.o1 = 1
        item.o0 = 0
        item.col0 = false
        item.col1 = false
        item.col3 = false
        item.o_list = 0
        scheduleId_l.push(item.scheduleId)
      })

      if (this.sty_name == 'zc14') {
        let obj = {}
        obj.scheduleIDs = scheduleId_l.join(",")
        obj.companyID = 281
        obj.oddsType = 3
        const shceduleOdds = await this.$http.get('odds/shceduleOdds/', { params: obj });
        this.oddsList = shceduleOdds.data.oddsList
      }



      this.val_xz = 0
      this.val_M = 0
    },
    onOptions_s (v) {
      // console.log(v, this.timelist)
      if (v == this.timelist.length) {
        this.tableData = this.tableDatas.data_obj.match_list
        this.act = true
        this.weekday = ''
        this.checked = false
        return
      }
      this.act = false
      this.tableData = this.tableDatas.data_obj.match_list.filter(item => {
        return new Date(item.matchtime).getTime() >= this.timelist[v].start && new Date(item.matchtime).getTime() < this.timelist[v].end
      })
      this.weekday = this.weekdayL[v]
    },
    // 选择
    handleClick (tab, event) {
      this.val_xz = 0
      this.val_M = 0
      this.sty_name = tab.name

      this.onDataList(tab.name)
      this.value_s = '',
        this.weekday = ''
    },
    // 显示已停售比赛
    onchecked (v) {
      if (v) {
        this.tableData = this.tableDatas.data_obj.match_list.filter(item => {
          return item.matchState == 0
        })
      } else {
        this.tableData = this.tableDatas.data_obj.match_list
      }

    },
  }
}
</script>
<style lang = 'less'>
.zucai_box {
  .ys_s {
    color: #f50d0d;
    font-weight: 900;
  }
  .ppp {
    width: 200px;
    height: 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .dd {
    float: right;
    margin-top: 10px;
    width: 500px;
    display: flex;
    align-items: center;
    justify-content: center;
    /* flex-direction: column; */
    .el-input {
      width: 50px;
      display: flex;
      justify-content: center;
    }
    .el-input__inner {
      padding: 0 !important;
      height: 20px !important;
    }
    span {
      color: #999999;
      font-size: 14px;
    }
    b {
      color: #660000;
    }
  }
  .oddsList {
    display: flex;
    justify-content: space-around;
    span {
      display: inline-block;
      width: 40px;
    }
  }
  .quan_tj {
    display: flex;
    align-items: center;
    justify-content: space-around;
    .el-checkbox {
      display: flex;
      align-items: center;
    }
  }
}

.zucai_box .el-table .warning-row {
  background: rgba(160, 189, 226, 0.2) !important;
}
.zucai_box .el-table--enable-row-hover .el-table__body tr:hover > td {
  background-color: rgba(160, 189, 226, 0.5);
}
.zucai_box .el-table--mini td,
.zucai_box .el-table--mini th {
  padding: 0 !important;
}
.zucai_box .el-table .cell {
  font-size: 16px !important;
  height: 100%;
  line-height: 36px !important;
}
.zucai_box .cell span {
  display: block;
}
.guanxi {
  font-weight: 900;
  color: #2acd19;
}
.shij {
  position: relative;
  &:hover .cell_h {
    display: block;
  }
  .cell_h {
    display: none;
    position: absolute;
    bottom: 30px;
    left: 50%;
    font-size: 12px;
    transform: translateX(-50%);
    z-index: 9999999999999;
    background: #eee;
    width: 80%;
    color: #999;
    .cell_p {
      height: 20px;
      line-height: 20px;
    }
  }
}
</style>
<style lang = 'less' scoped >
.zucai_box {
  background: #fff;
}
a {
  &:hover {
    color: #91c1f8;
  }
}
[v-cloak] {
  display: none !important;
}
.zuc_s {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.cell_j {
  position: relative;
  &:hover .cell_s {
    display: block;
  }
  .cell_s {
    display: none;
    position: absolute;
    top: 30px;
    left: 50%;
    z-index: 9999999999999;
    font-size: 12px;
    transform: translateX(-50%);
    white-space: nowrap;
    background: #eee;
    line-height: 12px;
    /* color: #999; */
    /* padding: 0 2px; */
  }
}
</style>