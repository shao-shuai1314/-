<template>
  <div class="livecebter_box"
       v-cloak>
    <div class="zuc_s">
      <div>
        <!-- 最新彩票比赛 -->
        <el-link :type="value==item?'primary':''"
                 style="margin:0 10px"
                 v-for="item in new_nums"
                 :key="item.val"
                 @click="new_num(item)">{{item.val}}</el-link>
      </div>
      <div>
        <el-radio-group v-model="radio"
                        @change="on_radio">
          <el-radio :label="20">全部比赛</el-radio>
          <el-radio :label="0">未开场</el-radio>
          <el-radio :label="-1">已完场</el-radio>
          <el-radio :label="21">进行时</el-radio>
        </el-radio-group>
      </div>
    </div>

    <el-table :data="tableData"
              size="mini"
              border
              :header-cell-style="{
    'color': '#303133',
    'border-bottom': '1px rgb(103, 194, 58) solid',
    'text-align':'center',
    'font-size':'16px',
}"
              style="width: 100%">
      <el-table-column prop="num"
                       label=""
                       align="center"
                       width="30">
      </el-table-column>
      <el-table-column prop="matchtime"
                       label="比赛时间"
                       align="center"
                       width="">
        <template slot-scope="scope">
          <div style="display: flex;justify-content: center"
               :style="{ color: (scope.row.color_jl?scope.row.color_jl:scope.row.color_sj), fontWeight:(scope.row.color_jl||scope.row.color_sj?900:'')  }">
            {{scope.row.matchtime.replace("T"," ")　}}
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="num"
                       label="状 态"
                       align="center"
                       width="50">
        <template slot-scope="scope">
          <div style="display: flex;justify-content: center">
            {{z_t[scope.row.matchState]}}
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="sclassName"
                       label="赛 事"
                       align="center"
                       width="100">
        <template slot-scope="scope">
          <div style="display: flex;justify-content: center">
            <div style="width:150px;font-weight: 900;">
              <router-link target="_blank"
                           v-if="scope.row.sclassID"
                           :style="{'color':scope.row.color?scope.row.color:''}"
                           :to="{name:'league',params:{sclassID:scope.row.sclassID}}">{{scope.row.sclassName}}</router-link>
            </div>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="homeName"
                       label="主  队"
                       align="center"
                       width="">
        <template slot-scope="scope">
          <div class="fl-ss">
            <span>
              {{scope.row.home_order}}
            </span>
            <router-link target="_blank"
                         v-if="scope.row.hometeamID"
                         :to="{name:'lineup',params:{teamID:scope.row.hometeamID}}">{{scope.row.hometeamName}}</router-link>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="address"
                       align="center"
                       width="50"
                       label="比  分">
        <template slot-scope="scope">
          <div class="jinqium"
               @click="getmatchSeason(scope.row.matchSeason,scope.row.sclassName,scope.row.scheduleID)"
               style="cursor: pointer;">
            <span v-if="scope.row.matchState == -1"
                  @mouseover="onJ_l(scope.row.scheduleID)"
                  @mouseout="outStyle()">
              <span style="color:rgb(244, 104, 89);font-weight: 900;">{{scope.row.homeScore}}-{{scope.row.guestScore}}</span>
            </span>
            <span v-else-if="scope.row.matchState == 1||scope.row.matchState == 2||scope.row.matchState == 3||scope.row.matchState == 4||scope.row.matchState == 5">
              <span style="color:rgb(244, 104, 89);font-weight: 900;">{{scope.row.homeScore}}-{{scope.row.guestScore}}</span>
            </span>
            <span v-else>VS</span>
            <table class="jina">
              <tr v-for="(it,i) in j_l"
                  :key="i">
                <td class="jina1"
                    v-if="scope.row.hometeamID == it.teamID">
                  <svg class="icon"
                       aria-hidden="true">
                    <use :xlink:href="teamStyle[it.kind]"></use>
                  </svg>
                </td>
                <td class="jina1"
                    v-else></td>
                <td class="jina2"
                    v-if="scope.row.hometeamID == it.teamID">{{it.playerName}}</td>
                <td class="jina2"
                    v-else></td>
                <td class="jina3">{{it.happentime}}'</td>
                <td class="jina2"
                    v-if="scope.row.guestteamID == it.teamID">{{it.playerName}}</td>
                <td class="jina2"
                    v-else></td>
                <td class="jina1"
                    v-if="scope.row.guestteamID == it.teamID">
                  <svg class="icon"
                       aria-hidden="true">
                    <use :xlink:href="teamStyle[it.kind]"></use>
                  </svg>
                </td>
                <td class="jina1"
                    v-else></td>
              </tr>
            </table>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="guestName"
                       align="center"
                       label="客  队">
        <template slot-scope="scope">
          <div class="fl-ss">
            <router-link target="_blank"
                         v-if="scope.row.guestteamID"
                         :to="{name:'lineup',params:{teamID:scope.row.guestteamID}}">{{scope.row.guestteamName}}</router-link>
            <span>
              {{scope.row.guest_order}}
            </span>
          </div>
        </template>
      </el-table-column>

      <el-table-column prop="address"
                       align="center"
                       width="50"
                       label="半 场">
        <template slot-scope="scope">
          <div>
            <span v-if="scope.row.matchState == -1||scope.row.matchState == 1||scope.row.matchState == 2||scope.row.matchState == 3||scope.row.matchState == 4||scope.row.matchState == 5">
              <span style="color:rgb(244, 104, 89);">{{scope.row.homeHalfScore}}-{{scope.row.guestHalfScore}}</span>
            </span>
            <span v-else>VS</span>
          </div>
        </template>
      </el-table-column>

      <el-table-column prop="scheduleId"
                       align="center"
                       width="200"
                       v-if="bd"
                       label="欧赔">
        <template slot-scope="scope">
          <div v-for="(item,i) in oddsList"
               :key="i">
            <div v-if="item.scheduleID == scope.row.scheduleID"
                 class="oddsList">
              <span v-if="scope.row.color_ss1"
                    :class="scope.row.color_ss1"
                    class=" ys_s">
                {{item.firstUpOdds}}
              </span>
              <span v-else>
                {{item.firstUpOdds}}
              </span>

              <span v-if="scope.row.color_ss2"
                    :class="scope.row.color_ss2"
                    class=" ys_s">
                {{item.firstGoal}}
              </span>
              <span v-else>
                {{item.firstGoal}}
              </span>

              <span v-if="scope.row.color_ss3"
                    :class="scope.row.color_ss3"
                    class=" ys_s">
                {{item.firstDownOdds}}
              </span>
              <span v-else>
                {{item.firstDownOdds}}
              </span>
            </div>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="cg"
                       align="center"
                       width="40"
                       label="彩 果">
      </el-table-column>
    </el-table>
    <div class="wzsm_ss">
      <div class="tw">
        指数分布：
        <p>
          <span>
            <i class="ys_l"></i>
            首指={{S_z}}
          </span>
          <span>
            <i class="ys_y"></i>
            次指={{C_z}}
          </span>
          <span>
            <i class="ys_h"></i>
            末指={{M_z}}
          </span>
        </p>
        <p>
        </p>
        <p>
        </p>
      </div>
    </div>
  </div>
</template>
<script>
// import '../css/font/iconfont.js'
// import '../css/font1/iconfont.js'
export default {
  data () {
    return {
      tableData: [],
      options: [],
      value: '',
      new_nums: [],
      sty_name: 'zc14',
      options_s: [],
      value_s: '',
      timelist: [],
      weekdayL: [],
      weekday: '',
      isTrue: false,
      act: false,
      activeName: 'zc14',
      jkname: 'zc14',
      checked: false,
      zucai_true: true,
      val_xz: 0,
      val_M: 0,
      v_b: 1,
      oddsList: [
        {
          col0: false,
          col1: false,
          col3: false,
          o_list: 0
        }
      ],
      z_t: {
        '0': '未',
        '1': '上半场',
        '2': '中场',
        '3': '下半场',
        '4': '加时',
        '5': '点球',
        '-1': '完',
        '-10': '取消',
        '-11': '待定',
        '-12': '腰斩',
        '-13': '中断',
        '-14': '推迟',
      },
      S_z: 0,
      C_z: 0,
      M_z: 0,
      bd: true,
      radio: 20,
      teamStyle: ['', '#icon-jinqiu', "#icon-hongpai", "#icon-huangpai", '#icon-huanru', '#icon-huanchu', '', '#icon-dianqiu', "#icon-zuqiuwulongqiu", "#icon-lianghuangbianhong1", , , , , "#icon-zhugongbang",],
      j_l: []
    };
  },
  created () {
    this.onDataList()
  },
  watch: {
  },
  computed: {
  },

  methods: {
    // 显示进球图标
    async onJ_l (scheduleID) {
      var { data: res } = await this.$http.get(`/soccer/matchInfo/${scheduleID}/goalTj/`);
      // console.log(res.data)
      let j_l = res.data.filter(item => item.kind == 1 || item.kind == 7 || item.kind == 8)
      this.j_l = j_l
    },
    outStyle () {
      this.j_l = []
    },
    // 点击跳转
    getmatchSeason (matchSeason, sclassName, scheduleId) {
      // console.log(matchSeason)
      sessionStorage.setItem("matchSeason", matchSeason);
      sessionStorage.setItem("sclassName", sclassName);
      // this.$router.go(0);
      let routeUrl = this.$router.resolve({
        name: "history",
        params: { scheduleID: scheduleId }
      });
      window.open(routeUrl.href, '_blank');
    },

    async onDataList (val, i) {
      this.jkname = i
      let obj = {}
      if (i) {
        obj.issueNum = i
      }
      const res = await this.$http.get(`/soccer/todayMatch`);
      // 重要事件
      res.data.data.forEach((item, index) => {
        if (item.homeCoachBirthday) {
          var z_s = item.homeCoachBirthday.split('-')
        }
        if (item.guestCoachBirthday) {
          var k_s = item.guestCoachBirthday.split('-')
        }
        if (item.homeFoundDate) {
          var z_c = item.homeFoundDate.split('-')
        }
        if (item.guestFoundDate) {
          var k_c = item.guestFoundDate.split('-')
        }
        if (item.matchtime) {
          var d_b = item.matchtime.split('T')[0].split('-')
        }
        if (d_b && z_s && k_s && d_b.length == 3 && z_s.length == 3 && k_s.length == 3) {
          //  主客教练生日
          let oDate1 = new Date(d_b[0], z_s[1], z_s[2]);
          let oDate2 = new Date(d_b[0], k_s[1], k_s[2]);
          let oDate3 = new Date(d_b[0], d_b[1], d_b[2]);
          let nTime1 = oDate1.getTime() - oDate3.getTime();
          let nTime2 = oDate2.getTime() - oDate3.getTime();
          if (Math.floor(nTime1 / 86400) <= 1 && Math.floor(nTime1 / 86400) >= 0 || Math.floor(nTime1 / 86400) >= -1 && Math.floor(nTime1 / 86400) <= 0) {
            item.color_jl = `rgb(244, 104, 89)`
          }
          if (Math.floor(nTime2 / 86400) <= 1 && Math.floor(nTime2 / 86400) >= 0 || Math.floor(nTime2 / 86400) >= -1 && Math.floor(nTime2 / 86400) <= 0) {
            item.color_jl = `rgb(244, 104, 89)`
          }
        }
        if (d_b && z_c && k_c && d_b.length == 3 && z_c.length == 3 && k_c.length == 3) {
          let oDate1 = new Date(d_b[0], z_c[1], z_c[2]);
          let oDate2 = new Date(d_b[0], k_c[1], k_c[2]);
          let oDate3 = new Date(d_b[0], d_b[1], d_b[2]);
          let nTime1 = oDate1.getTime() - oDate3.getTime();
          let nTime2 = oDate2.getTime() - oDate3.getTime();
          if (Math.floor(nTime1 / 86400) <= 1 && Math.floor(nTime1 / 86400) >= 0 || Math.floor(nTime1 / 86400) >= -1 && Math.floor(nTime1 / 86400) <= 0) {
            item.color_sj = `rgb(60, 60, 255)`
          }
          if (Math.floor(nTime2 / 86400) <= 1 && Math.floor(nTime2 / 86400) >= 0 || Math.floor(nTime2 / 86400) >= -1 && Math.floor(nTime2 / 86400) <= 0) {
            item.color_sj = `rgb(60, 60, 255)`
          }
        }
      })
      res.data.data = res.data.data.filter(item => {
        return item.sclassID == 36 || item.sclassID == 37 || item.sclassID == 8 || item.sclassID == 9 || item.sclassID == 34 || item.sclassID == 31 || item.sclassID == 11 || item.sclassID == 12 || item.sclassID == 60 || item.sclassID == 192 || item.sclassID == 103 || item.sclassID == 113 || item.sclassID == 16 || item.sclassID == 17
      })
      this.tableDatas = res.data.data
      // console.log(res.data.history_nums)
      this.tableData = res.data.data
      console.log(this.tableData)
      // 欧赔

      let scheduleId_l = []
      this.tableData.forEach(item => {
        scheduleId_l.push(item.scheduleID)
      })

      let obj_s = {}
      obj_s.scheduleIDs = scheduleId_l.join(",")
      obj_s.companyID = 281
      obj_s.oddsType = 3
      const shceduleOdds = await this.$http.get('odds/shceduleOdds/', { params: obj_s });
      this.oddsList = shceduleOdds.data.oddsList
      let s_s = [], c_s = [], m_s = []
      this.tableData.forEach(item => {
        let a_s = shceduleOdds.data.oddsList.find(it => it.scheduleID == item.scheduleID)
        if (a_s) {
          item.firstUpOdds = a_s.firstUpOdds
          item.firstGoal = a_s.firstGoal
          item.firstDownOdds = a_s.firstDownOdds
          item.oddsID = a_s.oddsID
        }
        if (item.matchState == -1) {
          if (item.homeScore > item.guestScore) {
            if (item.firstUpOdds && item.firstGoal && item.firstDownOdds) {
              item.cg = 3
              m_s.push(item)
            }
          } else if (item.homeScore < item.guestScore) {
            if (item.firstUpOdds && item.firstGoal && item.firstDownOdds) {
              item.cg = 0
              s_s.push(item)
            }
          } else {
            if (item.firstUpOdds && item.firstGoal && item.firstDownOdds) {
              item.cg = 1
              c_s.push(item)
            }
          }
        }
      })
      m_s.forEach(item => {
        if (item.firstUpOdds > item.firstGoal && item.firstUpOdds > item.firstDownOdds) {
          item.color_ss1 = 'ys_h'
          item.color_ss = 'ys_h'
        } else if (item.firstUpOdds < item.firstGoal && item.firstUpOdds < item.firstDownOdds) {
          item.color_ss1 = 'ys_l'
          item.color_ss = 'ys_l'
        } else {
          if (item.firstUpOdds == item.firstGoal && item.firstUpOdds < item.firstDownOdds) {
            item.color_ss1 = 'ys_l'
            item.color_ss = 'ys_l'
          } else if (item.firstUpOdds == item.firstDownOdds && item.firstUpOdds < item.firstGoal) {
            item.color_ss1 = 'ys_l'
            item.color_ss = 'ys_l'
          } else if (item.firstUpOdds == item.firstGoal && item.firstUpOdds > item.firstDownOdds) {
            item.color_ss1 = 'ys_y'
            item.color_ss = 'ys_y'
          } else if (item.firstUpOdds == item.firstDownOdds && item.firstUpOdds > item.firstGoal) {
            item.color_ss1 = 'ys_y'
            item.color_ss = 'ys_y'
          } else {
            item.color_ss1 = 'ys_y'
            item.color_ss = 'ys_y'
          }
        }
      })
      c_s.forEach(item => {
        if (item.firstGoal > item.firstUpOdds && item.firstGoal > item.firstDownOdds) {
          item.color_ss2 = 'ys_h'
          item.color_ss = 'ys_h'
        } else if (item.firstGoal < item.firstUpOdds && item.firstGoal < item.firstDownOdds) {
          item.color_ss2 = 'ys_l'
          item.color_ss = 'ys_l'
        } else {
          if (item.firstGoa == item.firstUpOdds && item.firstGoa < item.firstDownOdds) {
            item.color_ss2 = 'ys_l'
            item.color_ss = 'ys_l'
          } else if (item.firstGoa == item.firstDownOdds && item.firstGoa < item.firstUpOdds) {
            item.color_ss2 = 'ys_l'
            item.color_ss = 'ys_l'
          } else if (item.firstGoa == item.firstUpOdds && item.firstGoa > item.firstDownOdds) {
            item.color_ss2 = 'ys_y'
            item.color_ss = 'ys_y'
          } else if (item.firstGoa == item.firstDownOdds && item.firstGoa > item.firstUpOdds) {
            item.color_ss2 = 'ys_y'
            item.color_ss = 'ys_y'
          } else {
            item.color_ss2 = 'ys_y'
            item.color_ss = 'ys_y'
          }
        }
      })
      s_s.forEach(item => {
        if (item.firstDownOdds > item.firstUpOdds && item.firstDownOdds > item.firstGoal) {
          item.color_ss3 = 'ys_h'
          item.color_ss = 'ys_h'
        } else if (item.firstDownOdds < item.firstUpOdds && item.firstDownOdds < item.firstGoal) {
          item.color_ss3 = 'ys_l'
          item.color_ss = 'ys_l'
        } else {
          if (item.firstDownOdds == item.firstGoal && item.firstDownOdds < item.firstUpOdds) {
            item.color_ss3 = 'ys_l'
            item.color_ss = 'ys_l'
          } else if (item.firstDownOdds == item.firstUpOdds && item.firstDownOdds < item.firstGoal) {
            item.color_ss3 = 'ys_l'
            item.color_ss = 'ys_l'
          } else if (item.firstDownOdds == item.firstGoal && item.firstDownOdds > item.firstUpOdds) {
            item.color_ss3 = 'ys_y'
            item.color_ss = 'ys_y'
          } else if (item.firstDownOdds == item.firstUpOdds && item.firstDownOdds > item.firstGoal) {
            item.color_ss3 = 'ys_y'
            item.color_ss = 'ys_y'
          } else {
            item.color_ss3 = 'ys_y'
            item.color_ss = 'ys_y'
          }
        }
      })
      this.S_z = Array.isArray(this.tableData.filter(item => item.color_ss == "ys_l")) ? this.tableData.filter(item => item.color_ss == "ys_l").length : 0
      this.C_z = Array.isArray(this.tableData.filter(item => item.color_ss == "ys_y")) ? this.tableData.filter(item => item.color_ss == "ys_y").length : 0
      this.M_z = Array.isArray(this.tableData.filter(item => item.color_ss == "ys_h")) ? this.tableData.filter(item => item.color_ss == "ys_h").length : 0
      let that = this
      // 实时更新
      async function scheduleIDs (scheduleIDs_l) {
        // console.log(scheduleIDs_l)
        const res_aa = await that.$http.get(`/soccer/matchChange`, { params: { scheduleIDs: scheduleIDs_l.join() } });
        that.tableData.forEach(item => {
          let dd = res_aa.data.data.find(ii => ii.scheduleID == item.scheduleID)
          if (dd) {
            item.homeScore = dd.homeScore
            item.guestScore = dd.guestScore
            item.homeHalfScore = dd.homeHalfScore
            item.guestHalfScore = dd.guestHalfScore
            item.home_order = dd.home_order
            item.guest_order = dd.guest_order
            item.matchState = dd.matchState
          }
        })
      }
      var timer = setInterval(function () {
        var date = new Date();
        var Y = date.getFullYear();
        var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1);
        var D = (date.getDate() < 10 ? '0' + date.getDate() : date.getDate());
        var h = (date.getHours() < 10 ? '0' + date.getHours() : date.getHours());
        var m = (date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes());
        var s = date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds();
        // 你已知的时间
        var new_t = new Date(Y, M, D, h, m, s);
        // 转化为时间戳毫秒数
        var new_s = new_t.getTime();
        let new_tableData = that.tableData.filter(item => {
          let aa, bb, cc, dd, ee, ff
          aa = item.matchtime.slice(0, 4)
          bb = item.matchtime.slice(5, 7)
          cc = item.matchtime.slice(8, 10)
          dd = item.matchtime.slice(11, 13)
          ee = item.matchtime.slice(14, 16)
          ff = item.matchtime.slice(17, 19)
          var t = new Date(aa, bb, cc, dd, ee, ff);
          // 转化为时间戳毫秒数
          var t_s = t.getTime();
          return t_s <= new_s && t.setTime(t_s + 1000 * 60 * 130) >= new_s
        })
        // 有正在比赛的
        if (new_tableData.length) {
          let scheduleIDs_l = []
          new_tableData.forEach(item => {
            scheduleIDs_l.push(item.scheduleID)
          })
          scheduleIDs(scheduleIDs_l)
        }
      }, 30000);
    },
    onOptions_s (v) {
      // console.log(v, this.timelist)
      if (v == this.timelist.length) {
        this.tableData = this.tableDatas.data_obj.match_list
        this.act = true
        this.weekday = ''
        this.checked = false
        return
      }
      this.act = false
      this.tableData = this.tableDatas.data_obj.match_list.filter(item => {
        return new Date(item.matchtime).getTime() >= this.timelist[v].start && new Date(item.matchtime).getTime() < this.timelist[v].end
      })
      this.weekday = this.weekdayL[v]
    },
    // 筛选比赛
    on_radio (v) {
      console.log(v)
      if (v == 20) {
        this.tableData = this.tableDatas
      } else if (v == 21) {
        this.tableData = this.tableDatas.filter(item => item.matchState == 1 || item.matchState == 2 || item.matchState == 3 || item.matchState == 4 || item.matchState == 5)

      } else {
        this.tableData = this.tableDatas.filter(item => item.matchState == v)
      }
    }
  }
}
</script>
<style lang = 'less'>
.livecebter_box {
  width: 1160px;
  margin-left: 20px;
  .wzsm_ss {
    height: 60px;
    align-items: center;
    display: flex;
    font-size: 14px;
    .tw {
      width: 100%;
      height: 30px;
      display: flex;
      align-items: center;
      p {
        height: 30px;
        margin-left: 20px;
        display: flex;
        align-items: center;
        span {
          height: 30px;
          margin: 0 10px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          svg {
            width: 30px;
            height: 30px;
          }
          i {
            display: inline-block;
            width: 26px;
            height: 20px;
            margin-right: 10px;
          }
          .icon {
            margin-right: 10px;
          }
        }
      }
    }
  }

  .ys_s {
    display: inline-block;
    height: 20px;
    margin-top: 6px;
    line-height: 20px;
    color: #fff;
  }
  .ys_l {
    background: #3c64db;
  }
  .ys_y {
    background: #d8cb29;
  }
  .ys_h {
    background: #ed5427;
  }
  .ppp {
    width: 200px;
    height: 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .dd {
    float: right;
    margin-top: 10px;
    width: 500px;
    display: flex;
    align-items: center;
    justify-content: center;
    /* flex-direction: column; */
    .el-input {
      width: 50px;
      display: flex;
      justify-content: center;
    }
    .el-input__inner {
      padding: 0 !important;
      height: 20px !important;
    }
    span {
      color: #999999;
      font-size: 14px;
    }
    b {
      color: #660000;
    }
  }
  .oddsList {
    display: flex;
    justify-content: space-around;
    span {
      display: inline-block;
      width: 40px;
    }
  }
  .quan_tj {
    display: flex;
    align-items: center;
    justify-content: space-around;
    .el-checkbox {
      display: flex;
      align-items: center;
    }
  }
}

.livecebter_box .el-table .warning-row {
  background: rgba(160, 189, 226, 0.2) !important;
}
.livecebter_box .el-table--enable-row-hover .el-table__body tr:hover > td {
  background-color: rgba(160, 189, 226, 0.5);
}
.livecebter_box .el-table--mini td,
.livecebter_box .el-table--mini th {
  padding: 0 !important;
}
.livecebter_box .el-table .cell {
  font-size: 16px !important;
  height: 100%;
  line-height: 36px !important;
}
.livecebter_box .el-table .fl-ss {
  display: flex;
  justify-content: space-between;
  span {
    font-size: 14px;
    min-width: 60px;
    display: flex;
    justify-content: center;
    color: #9a9a9a;
  }
  a {
    min-width: 100px;
    display: flex;
    justify-content: center;
  }
}
.livecebter_box .cell span {
  display: block;
}
</style>
<style lang = 'less' scoped >
.livecebter_box {
  background: #fff;
}
a {
  &:hover {
    color: #91c1f8;
  }
}
[v-cloak] {
  display: none !important;
}
.zuc_s {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.jinqium {
  position: relative;
  &:hover .jina {
    display: block;
  }
  .jina {
    display: none;
    position: absolute;
    left: 50%;
    bottom: 30px;
    /* margin-top: 3px; */
    margin-left: -200px;
    z-index: 999;
    width: 400px;
    background: #fff;
    text-align: center;
    /* border-top: 1px solid #d5e4f5;
    border-left: 1px solid #d5e4f5; */
    td {
      background: #fff;
      background: #cfdef0;
      padding: 6px 10px;
      font-size: 12px;
      text-align: center;
    }
    .jina1 {
      width: 40px;
      .icon {
        display: block;
        width: 40px;
        height: 20px;
        font-size: 20px;
      }
    }
    .jina2 {
      width: 165px;
      font-weight: 600;
    }
    .jina3 {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 40px;
    }
  }
}
</style>