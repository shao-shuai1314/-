<template>
  <div class="gWidth livecebter_box"
       v-cloak>
    <!-- 选项 -->
    <div class="livecebter_el-tabs">
      <el-tabs v-model="activeName"
               @tab-click="handleClick">
        <el-tab-pane label="足彩"
                     name="zc14"></el-tab-pane>
        <el-tab-pane label="足球"
                     name="jczq"></el-tab-pane>
      </el-tabs>
    </div>
    <Livecenter v-if="isTrue"></Livecenter>
    <Footballs v-else></Footballs>
  </div>
</template>
<script>
import Livecenter from './livecenter'
import Footballs from './footballLive'

import '../../css/font/iconfont.js'
import '../../css/font1/iconfont.js'
export default {
  components: {
    Footballs,
    Livecenter
  },
  data () {
    return {
      activeName: 'zc14',
      isTrue: true
    }
  },
  created () {
  },
  watch: {
  },
  computed: {
  },

  methods: {

    // 选择
    handleClick (tab, event) {
      console.log(tab.name)
      if (tab.name == 'zc14') {
        this.isTrue = true
      } else {
        this.isTrue = false
      }
    }
  }
}
</script>
<style lang = 'less'>
.livecebter_box {
  background: #fff;
}
.livecebter_el-tabs {
  width: 1160px;
  margin-left: 20px;
  background: #fff;
  height: 50px;
  padding-top: 20px;
}
</style>