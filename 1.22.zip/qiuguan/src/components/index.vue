<template>
  <div class="index_box gWidth">
    <div class="index_left fl">
      <!-- 第一板块 -->
      <div class="Part1">
        <!-- 左 -->
        <div class="Part1_fl fl">
          <!-- banner -->
          <el-carousel :interval="5000"
                       arrow="always"
                       trigger="click"
                       height="262px">
            <el-carousel-item v-for="(item,i) in banner_list"
                              :key="i"
                              v-if="item.img">
              <router-link target="_blank"
                           :to="{name:'newdetail',params:{recordId:item.recordId}}">
                <el-image style="height:100%"
                          :src="item.img?`https://www.qiuguantx.com/imgs/Journalism/${item.img}`: ''"></el-image>
                <h3 style="padding-left:10px">{{item.title}}</h3>
              </router-link>
            </el-carousel-item>
          </el-carousel>
          <!-- 推荐新闻 -->
          <div class="tj">
            <div class="fl"
                 v-for="(item,i) in rem_list"
                 :key="i"
                 v-if="item.img">
              <router-link target="_blank"
                           :to="{name:'newdetail',params:{recordId:item.recordId}}">
                <el-image :src="item.img?`https://www.qiuguantx.com/imgs/Journalism/${item.img}`: ''"></el-image>
                <p>
                  {{item.title}}
                </p>
              </router-link>
            </div>
          </div>
        </div>
        <!-- 右 -->
        <div class="Part1_fr fr">
          <div v-for="(value, key, index) in aa"
               :key="index">
            <h2 style="margin-bottom:-2px">
              {{key}}
              <router-link :to="{name:'news'}"
                           style="font-size:14px">更多>></router-link>
            </h2>
            <div class="sp">
              <span v-for="(it,i) in value.slice(0, 4)"
                    :key="i">
                <router-link :to="{name:'newdetail',params:{recordId:it.recordId}}"
                             target="_blank">
                  {{it.title}}
                </router-link>
              </span>

            </div>
          </div>
        </div>
      </div>
      <!-- 第二板块 -->
      <div class="Part2">
        <h2 style="font-weight: normal;height:30px;padding-left:10px;color:#E84B5B">
          <!-- <el-image style="width:200px" src="../../static/rm.gif"></el-image>           -->
          热门推荐
        </h2>
        <el-divider></el-divider>
        <ul class="">
          <li v-for="(item,index) in newList"
              :key="index">
            <router-link target="_blank"
                         :to="{name:'newdetail',params:{recordId:item.recordId}}">
              <div class="item_new">
                <div class="item_new_image">
                  <el-image :src="item.img?`https://www.qiuguantx.com/imgs/Journalism/${item.img}`: ''"></el-image>
                </div>
                <div class="item_new_text">
                  <p>{{item.title}}</p>
                  <div class="item_new_text_t">
                    <span>{{item.publicTime}}</span>
                    <b>{{item.Reprinted}}</b>
                  </div>
                </div>
              </div>
              <el-divider></el-divider>
            </router-link>
          </li>
        </ul>
      </div>
    </div>

    <!-- 右边内容 -->
    <div class="index_right fr">
      <!-- 第一板块  视频区 -->
      <div class="Part1_r">
        <div class="remen_qiu_box">
          <h2 style="font-weight: normal;height:30px;padding-left:10px;color:#E84B5B;padding-top:10px">
            <!-- <el-image style="width:200px" src="../../static/rm.gif"></el-image>           -->
            热门球队
          </h2>
          <!-- <h3>热门球队</h3> -->
          <div class="remen_qiu">
            <router-link target="_blank"
                         :to="{name:'league',params:{sclassID:36}}">
              <el-image src="https://qiuguantx.com/img/league_match/images/20200412115447.jpg"></el-image>
            </router-link>
            <router-link target="_blank"
                         :to="{name:'league',params:{sclassID:8}}">
              <el-image src="https://qiuguantx.com/img/league_match/images/20200415075216.jpg"></el-image>
            </router-link>
            <router-link target="_blank"
                         :to="{name:'league',params:{sclassID:34}}">
              <el-image src="https://qiuguantx.com/img/league_match/images/20190815175316.png"></el-image>
            </router-link>
            <router-link target="_blank"
                         :to="{name:'league',params:{sclassID:31}}">
              <el-image src="https://qiuguantx.com/img/league_match/images/20200415071847.jpg"></el-image>
            </router-link>
            <router-link target="_blank"
                         :to="{name:'league',params:{sclassID:11}}">
              <el-image src="https://qiuguantx.com/img/league_match/images/20200416070733.jpg"></el-image>
            </router-link>
            <router-link target="_blank"
                         :to="{name:'league',params:{sclassID:60}}">
              <el-image src="https://qiuguantx.com/img/league_match/images/20140111105821.jpg"></el-image>
            </router-link>
            <router-link target="_blank"
                         :to="{name:'league',params:{sclassID:192}}">
              <el-image src="https://qiuguantx.com/img/league_match/images/20210104160334.png"></el-image>
            </router-link>
            <router-link target="_blank"
                         :to="{name:'league',params:{sclassID:103}}">
              <el-image src="https://qiuguantx.com/img/league_match/images/20130423213803.jpg"></el-image>
            </router-link>
            <router-link target="_blank"
                         :to="{name:'league',params:{sclassID:113}}">
              <el-image src="https://qiuguantx.com/img/league_match/images/20200411101344.jpg"></el-image>
            </router-link>
          </div>
        </div>

        <!-- APP区 -->

        <div class="app">
          <el-image></el-image>
          <h5>关注球冠天下APP
            <p>最全的数据分析客户端</p>
          </h5>
        </div>
      </div>

      <!-- 第二板块 积分榜-->
      <div class="league_s">
        <h2 style="font-weight: normal;height:30px;padding-left:10px;color:#E84B5B;padding-top:20px">
          <!-- <el-image style="width:200px" src="../../static/rm.gif"></el-image>           -->
          积分榜
        </h2>
        <el-divider></el-divider>

        <el-tabs v-model="activeName"
                 :stretch="true"
                 @tab-click="handleClick">
          <el-tab-pane label="英超"
                       name="36"></el-tab-pane>
          <el-tab-pane label="德甲"
                       name="8"></el-tab-pane>
          <el-tab-pane label="西甲"
                       name="31"></el-tab-pane>
          <el-tab-pane label="法甲"
                       name="11"></el-tab-pane>
          <el-tab-pane label="意甲"
                       name="34"></el-tab-pane>
        </el-tabs>

        <el-table :data="leagueList"
                  size="mini">
          <el-table-column prop="rank"
                           label="排名"
                           align="center"
                           width="40">
            <template slot-scope="scope">
              <div :style="{'background':scope.row.colors}">
                {{scope.row.rank}}
              </div>
            </template>

          </el-table-column>
          <el-table-column prop="teamName"
                           label="球队"
                           align="center"
                           width="">
            <template slot-scope="scope">
              <router-link target="_blank"
                           :to="{name:'information',params:{teamID:scope.row.teamID}}">{{scope.row.teamName}}</router-link>
            </template>
          </el-table-column>
          <el-table-column prop="win_score"
                           align="center"
                           width="60"
                           label="胜/平/负">
            <template slot-scope="scope">
              <div>
                {{scope.row.win_score}}/{{scope.row.flat_score}}/{{scope.row.fail_score}}
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="score"
                           align="center"
                           width="40"
                           label="积分">
            <template slot-scope="scope">
              <div style="color:#e74c5b;">{{scope.row.score}}</div>
            </template>
          </el-table-column>
        </el-table>
        <div class="item_ss">
          <p v-for="(item,index) in color_data"
             :key="index">
            <span class="point"
                  :style="{'background':item.color}"></span>
            <span class="text">{{item.qualify}}</span><br>
          </p>

        </div>
      </div>

    </div>
  </div>
</template>
<script >
export default {
  data () {
    return {
      results: [],
      newList: [],
      stys: { 36: '英超', 31: "西甲", 34: "意甲", 8: "德甲", 11: "法甲" },
      activeName: '36',
      leagueList: [],
      color_data: [],
      banner_list: [],
      rem_list: [],
      yingc: [],
      xij: [],
      yij: [],
      dej: [],
      fj: [],
      aa: []

    };
  },
  created () {
    // this.rm()
    this.jk()
    // this.jk(31)
    // this.jk(34)
    // this.jk(8)
    // this.jk(11)
    this.league(36)
  },
  // mounted () {
  //   document.title = ''
  // },
  methods: {
    async jk (scroll_id) {
      let obj = {}
      if (scroll_id) {
        obj.scroll_id = scroll_id
      }
      const { data: res } = await this.$http.get(`/journalism/`, { params: obj });
      this.banner_list = res.data.slice(0, 5)
      this.rem_list = res.data.slice(5, 7)
      this.newList.push(...res.data);
      function gl (num, list) {
        return list.filter(iten => {
          return iten.sclassId == num
        })
      }
      const { data: sss } = await this.$http.get(`/journalism/`, { params: { scroll_id: res.scroll_id } });
      this.yingc = gl(36, [...sss.data, ...this.newList])
      this.xij = gl(31, [...sss.data, ...this.newList])
      this.yij = gl(34, [...sss.data, ...this.newList])
      this.dej = gl(8, [...sss.data, ...this.newList])
      this.fj = gl(11, [...sss.data, ...this.newList])
      this.aa = { '英超': this.yingc, "西甲": this.xij, "意甲": this.yij, "德甲": this.dej, "法甲": this.fj }
    },

    async league (val) {
      var { data: res } = await this.$http.get(`/soccer/sclass/${val}/schedule/`);
      //  升降级颜色
      function colors (list1, list2) {
        list1.forEach(items => {
          list2.forEach(item => {
            items.rank_data.forEach(it => {
              if (item.rank == it) {
                item.colors = items.color
              }
            })
          })
        })
      }
      try {
        colors(res.sclass_data.leagues_data.color_data, res.sclass_data.leagues_data.all_score)
      } catch (err) {
      }

      this.leagueList = res.sclass_data.leagues_data.all_score
      this.color_data = res.sclass_data.leagues_data.color_data

    },

    handleClick (tab, event) {
      this.league(tab.name)
    }

  },
}
</script>
<style lang = 'less' scoped >
a {
  &:hover .tit_p {
    color: #91c1f8;
  }
}

.index_box {
  &::after {
    content: '';
    display: block;
    height: 0;
    clear: both;
    visibility: hidden;
  }
  /* 第一板块 左边区域*/
  .Part1 {
    border-radius: 6px;
    height: 450px;
    width: 900px;
    padding: 10px;
    overflow: hidden;
    background: #fff;
    .Part1_fl {
      width: 490px;
      /* banner */
      .el-carousel {
        width: 490px;
        border-radius: 6px;
        .el-carousel__item h3 {
          position: absolute;
          bottom: 0;
          color: #fff;
          font-size: 14px;
          width: 100%;
          height: 50px;
          line-height: 30px;
          background: rgba(0, 0, 0, 0.5);
        }

        .el-carousel__item:nth-child(2n) {
          background-color: #99a9bf;
        }

        .el-carousel__item:nth-child(2n + 1) {
          background-color: #d3dce6;
        }
      }
      /* banner下内容 */
      .tj {
        width: 490px;
        height: 180px;
        margin-top: 10px;
        overflow: hidden;
        display: flex;
        justify-content: space-between;
        .el-image {
          width: 234px;
          height: 126px;
          border-radius: 6px;
        }
        p {
          width: 234px;
          line-height: 22px;
          margin-top: 6px;
          font-size: 14px;
          display: -webkit-box;
          -webkit-box-orient: vertical;
          -webkit-line-clamp: 2;
          overflow: hidden;
        }
      }
    }
  }
  /* banner右边 */
  .Part1_fr {
    a {
      &:hover {
        color: #91c1f8;
      }
    }
    width: 400px;
    div {
      margin-bottom: 10px;
    }

    h2 {
      font-size: 18px;
      /* color: #444; */
      margin-bottom: 10px;
      display: -webkit-box;
      -webkit-box-orient: vertical;
      -webkit-line-clamp: 2;
      overflow: hidden;
    }
    .sp {
      display: flex;
      flex-direction: row;
      flex-wrap: wrap;
    }
    span {
      width: 50%;
      line-height: 29px;
      display: -webkit-box;
      -webkit-box-orient: vertical;
      -webkit-line-clamp: 1;
      overflow: hidden;
      a {
        color: #3a4451;
      }
    }
  }

  /* ------------------------------------------------------------ */

  /* 第二板块 */
  .Part2 {
    width: 880px;
    background: #fff;
    margin-top: 10px;
    border-radius: 6px;
    padding: 20px 20px 0 20px;
    .item_new {
      display: flex;
      .item_new_image {
        width: 150px;
        height: 100px;
        overflow: hidden;
        margin-right: 20px;
        .el-image {
          width: 150px;
          height: 100px;
        }
      }
      .item_new_text {
        width: 100%;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        p {
          font-size: 18px;
          color: #333;
        }
        .item_new_text_t {
          display: flex;
          justify-content: space-between;
          span {
            font-size: 12px;
            color: #999;
          }
          b {
            font-size: 12px;
            color: #999;
          }
        }
      }
    }
    .load-more {
      width: 100%;
      height: 50px;
      line-height: 50px;
      text-align: center;
      background: #ececec;
      color: #888;
      cursor: pointer;
    }
  }
}

/* ---------------------------------------------- */
/* 右边内容 */
.index_right {
  width: 270px;
  height: 450px;
  background: #fff;
  padding: 10px 0;
  border-radius: 6px;
  .Part1_r {
    width: 100%;
    height: 470px;
    /* margin-right: 10px; */
    .remen_qiu_box {
      .remen_qiu {
        display: flex;
        flex-direction: row;
        flex-wrap: wrap;
        justify-content: space-between;
        margin-bottom: 10px;
        .el-image {
          margin: 10px 0;
          width: 60px;
          height: 60px;
        }
      }
    }
    .app {
      width: 250px;
      height: 150px;
      display: flex;
      justify-content: space-around;
      align-items: center;
      background: #444444;
      margin-left: 10px;
      .el-image {
        width: 102px;
        height: 102px;
      }
      h5 {
        font-size: 16px;
        color: #fff;
        p {
          font-size: 12px;
        }
      }
    }
  }
}

/* ----------------------------------------------- */
.league_s {
  background: #fff;
  border-radius: 6px;
  .el-tabs {
    width: 250px;
    margin-left: 10px;
    margin-top: -20px;
  }
  .el-table {
    width: 250px;
    margin-left: 10px;
    margin-top: -10px;
  }
  .item_ss {
    background-color: #f7f8fa;
    padding: 20px 10px;
    font-size: 12px;
    font-family: PingFangSC-Regular, PingFang SC;
    font-weight: 400;
    color: #333;
    .point {
      width: 30px;
      height: 20px;
      display: inline-block;
      margin-right: 10px;
    }
    p {
      display: flex;
      align-items: center;
      margin: 6px 0;
    }
  }
}
</style>