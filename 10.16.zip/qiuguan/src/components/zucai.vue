<template>
  <div class="gWidth zucai_box">
    <el-card>

      <!-- 选项 -->
      <el-tabs v-model="activeName"
               @tab-click="handleClick">
        <el-tab-pane label="足彩"
                     name="zc14"></el-tab-pane>
        <el-tab-pane label="竞彩"
                     name="jczq"></el-tab-pane>
        <el-tab-pane label="北京单场"
                     name="bd"></el-tab-pane>
      </el-tabs>

      <el-select v-model="value"
                 @change="onOptions"
                 placeholder="请选择">
        <el-option v-for="(item,index) in options"
                   :key="index"
                   :label="item"
                   :value="index">
        </el-option>
      </el-select>
      <el-select v-if="isTrue"
                 v-model="value_s"
                 style="margin-left:20px"
                 @change="onOptions_s"
                 placeholder="日期筛选">
        <el-option v-for="(item,index) in options_s"
                   :key="index"
                   :label="item"
                   :value="index">
        </el-option>
      </el-select>

      <el-checkbox style="margin-left:20px"
                   v-if="act && isTrue"
                   v-model="checked"
                   @change="onchecked">隐藏已停售比赛</el-checkbox>

      <div v-if="isTrue"
           style="margin-top:10px">
        <b>
          {{weekday}}
        </b>
      </div>

      <el-table :data="tableData"
                :key="Math.random()"
                size="mini"
                border
                :header-cell-style="{
    'color': '#303133',
    'border-bottom': '1px rgb(103, 194, 58) solid',
    'text-align':'center',
    'font-size':'16px',
}"
                style="width: 100%">
        <el-table-column prop="num"
                         label=""
                         align="center"
                         width="30">
        </el-table-column>
        <el-table-column prop="matchtime"
                         label="比赛时间"
                         align="center"
                         width="">
        </el-table-column>
        <el-table-column prop="sclassName"
                         label="联  赛"
                         align="center"
                         width="150">
          <template slot-scope="scope">
            <div style="display: flex;justify-content: center">
              <div :style="{background:scope.row.color}"
                   style="width:150px;">
                <router-link target="_blank"
                             v-if="scope.row.sclassId"
                             :style="{'color':scope.row.color?'#fff':''}"
                             :to="{name:'league',params:{sclassID:scope.row.sclassId}}">{{scope.row.sclassName}}</router-link>
              </div>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="homeName"
                         label="主  队"
                         align="center"
                         width="">
          <template slot-scope="scope">
            <div>
              <router-link target="_blank"
                           v-if="scope.row.hometeamId"
                           :to="{name:'information',params:{teamID:scope.row.hometeamId}}">{{scope.row.homeName}}</router-link>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="address"
                         align="center"
                         label="比  分">
          <template slot-scope="scope">
            <div>
              <router-link target="_blank"
                           :to="{name:'history',params:{scheduleID:scope.row.scheduleId}}">
                <span v-if="scope.row.matchState == -1">
                  <span>{{scope.row.homeScore}}-{{scope.row.guestScore}}</span>
                </span>
                <span v-else>VS</span>
              </router-link>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="guestName"
                         align="center"
                         label="客  队">
          <template slot-scope="scope">
            <div>
              <router-link target="_blank"
                           v-if="scope.row.guestteamId"
                           :to="{name:'information',params:{teamID:scope.row.guestteamId}}">{{scope.row.guestName}}</router-link>
            </div>
          </template>
        </el-table-column>
        <el-table-column v-if="zucai_true"
                         prop="guestName"
                         align="center"
                         label="选 项">
          <template slot-scope="scope">
            <div>
              <el-button size="mini"
                         :type="`${scope.row.col3?'primary':''}`"
                         @click="onC(scope.row.o3,scope.$index)"
                         circle>{{scope.row.o3}}</el-button>
              <el-button size="mini"
                         :type="`${scope.row.col1?'primary':''}`"
                         @click="onC(scope.row.o1,scope.$index)"
                         circle>{{scope.row.o1}}</el-button>
              <el-button size="mini"
                         :type="`${scope.row.col0?'primary':''}`"
                         @click="onC(scope.row.o0,scope.$index)"
                         circle>{{scope.row.o0}}</el-button>
            </div>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <div class="dd"
         v-if="zucai_true">
      <p class="ppp">
        倍数：
        <el-input :value="v_b"
                  @input="e => (v_b = isnumber(e))"></el-input>
        <span>1-99的整数</span>
      </p>

      <div>
        <span>{{v_b}}倍，</span>
        <span>共
          <b>{{val_xz}}</b> 注 , </span>
        <span>
          <b>{{val_M}}</b>元</span>
      </div>

    </div>

  </div>
</template>
<script >
export default {
  data () {
    return {
      tableData: [],
      options: [],
      value: '',

      options_s: [],
      value_s: '',

      timelist: [],
      weekdayL: [],
      weekday: '',
      isTrue: true,
      act: true,

      activeName: 'zc14',
      jkname: 'zc14',
      checked: false,

      zucai_true: true,
      val_xz: 0,
      val_M: 0,
      v_b: 1,
    };
  },
  created () {
    this.onDataList(0, 'zc14')

    var Today = new Date();

    var weekday = ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"];


    var s1 = Today.getFullYear() + "-" + (Today.getMonth() + 1) + "-" + Today.getDate();
    var s11 = new Date(`${s1} 10:00:00`).getTime()
    var myddy1 = Today.getDay();//获取存储当前日期
    Today.setTime(Today.getTime() + 24 * 60 * 60 * 1000);
    var s2 = Today.getFullYear() + "-" + (Today.getMonth() + 1) + "-" + Today.getDate();
    var s22 = new Date(`${s2} 10:00:00`).getTime()
    var myddy2 = Today.getDay();//获取存储当前日期
    Today.setTime(Today.getTime() + 24 * 60 * 60 * 1000);
    var s3 = Today.getFullYear() + "-" + (Today.getMonth() + 1) + "-" + Today.getDate();
    var s33 = new Date(`${s3} 10:00:00`).getTime()
    var myddy3 = Today.getDay();//获取存储当前日期
    Today.setTime(Today.getTime() + 24 * 60 * 60 * 1000);
    var s4 = Today.getFullYear() + "-" + (Today.getMonth() + 1) + "-" + Today.getDate();
    var s44 = new Date(`${s4} 10:00:00`).getTime()


    this.timelist = [
      {
        start: s11,
        end: s22
      },
      {
        start: s22,
        end: s33
      }, {
        start: s33,
        end: s44
      }
    ]

    this.weekdayL = [
      `${weekday[myddy1]}  ${s1}  [10:00 -- 次日 10:00]`,
      `${weekday[myddy2]}  ${s2}  [10:00 -- 次日 10:00]`,
      `${weekday[myddy3]}  ${s3}  [10:00 -- 次日 10:00]`
    ]

    this.options_s = [`${s1}`, `${s2}`, `${s3}`, `全部`]

  },
  watch: {
    v_b (v) {
      console.log(v == '')
      if (v <= 99) {
        this.v_b = v
        if (this.v_b) {
          this.val_M = this.v_b * this.val_M_s
        }
      } else if (v > 99 || v == '') {
        this.v_b = 1
        if (this.v_b) {
          this.val_M = this.v_b * this.val_M_s
        }
      }
    }
  },


  methods: {
    // 14场点击
    onC (v, i) {
      let aa = 'col' + v
      // console.log(aa)
      this.tableData[i][aa] = !this.tableData[i][aa]

      // 计算
      this.tableData.forEach(item => {
        if (item.col0 && item.col1 && item.col3) {
          item.o_list = 3
        } else if (item.col0 && item.col1 || item.col0 && item.col3 || item.col1 && item.col3) {
          item.o_list = 2
        } else if (item.col0 || item.col3 || item.col1) {
          item.o_list = 1
        } else {
          item.o_list = 0
        }
      })
      let a1 = this.tableData.filter(item => item.o_list == 1)
      let a2 = this.tableData.filter(item => item.o_list == 2)
      let a3 = this.tableData.filter(item => item.o_list == 3)

      // console.log(a1, a2, a3)
      if (a1.length + a2.length + a3.length == 14) {
        this.val_xz = Math.pow(1, a1.length) * Math.pow(2, a2.length) * Math.pow(3, a3.length)
        if (this.v_b) {
          this.val_M = this.val_xz * 2 * this.v_b
        } else {
          this.val_M = this.val_xz * 2
        }

        this.val_M_s = this.val_xz * 2

      } else {
        this.val_xz = 0
        this.val_M = 0
      }

      this.$set(this.tableData, i, this.tableData[i])
      // console.log(this.tableData[0].o_list)
    },
    isnumber (val) {
      val = val.replace(/[^0-9]/gi, "");
      // 此处还可以限制位数以及大小
      if (val >= 1 && val <= 99) {
        this.v_b = val
        if (this.v_b) {
          this.val_M = this.v_b * this.val_M_s
        }
      } else {
        this.v_b = 1
        if (this.v_b) {
          this.val_M = this.v_b * this.val_M_s
        }
      }
      return val;
    },


    async onDataList (i, val) {
      this.jkname = i
      const res = await this.$http.get(`zucai/${val}/`);
      this.tableDatas = res.data
      this.tableData = res.data[i].match_list

      this.options = []
      res.data.forEach(item => {
        // item.val1 =false
        this.options.push(item.issueNum)
      })
      this.value = this.options[i]
      if (val == 'zc14') {
        this.zucai_true = true
        this.tableData.forEach(item => {
          item.o3 = 3
          item.o1 = 1
          item.o0 = 0
          item.col0 = false
          item.col1 = false
          item.col3 = false
          item.o_list = 0
        })
      }

      if (val == 'jczq') {
        this.zucai_true = false
      }


      if (val == 'bd') {
        this.zucai_true = false
        this.isTrue = true
      } else {
        this.isTrue = false
      }

      console.log(this.tableData)
    },
    onOptions (v) {
      this.tableData = this.tableDatas[v].match_list
      this.tableData.forEach(item => {
        item.o3 = 3
        item.o1 = 1
        item.o0 = 0
        item.col0 = false
        item.col1 = false
        item.col3 = false
        item.o_list = 0
      })
      this.val_xz = 0
      this.val_M = 0
    },
    onOptions_s (v) {

      if (v == 3) {
        this.tableData = this.tableDatas[0].match_list
        this.act = true
        this.weekday = ''
        this.checked = false
        return
      }
      this.act = false
      this.tableData = this.tableDatas[0].match_list.filter(item => {
        return new Date(item.matchtime).getTime() >= this.timelist[v].start && new Date(item.matchtime).getTime() < this.timelist[v].end
      })
      this.weekday = this.weekdayL[v]
    },
    // 选择
    handleClick (tab, event) {
      this.val_xz = 0
      this.val_M = 0

      this.onDataList(0, tab.name)
      this.value_s = '',
        this.weekday = ''
    },
    // 显示已停售比赛
    onchecked (v) {
      if (v) {
        this.tableData = this.tableDatas[0].match_list.filter(item => {
          return item.matchState == 0
        })
      } else {
        this.tableData = this.tableDatas[0].match_list
      }

    },
  }
}
</script>
<style lang = 'less'>
.zucai_box {
  .ppp {
    width: 200px;
    height: 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .dd {
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    .el-input {
      width: 50px;
      display: flex;
      justify-content: center;
    }
    .el-input__inner {
      padding: 0 !important;
      height: 20px !important;
    }
    span {
      color: #999999;
      font-size: 14px;
    }
    b {
      color: #660000;
    }
  }
}

.zucai_box .el-table .warning-row {
  background: rgba(160, 189, 226, 0.2) !important;
}
.zucai_box .el-table--enable-row-hover .el-table__body tr:hover > td {
  background-color: rgba(160, 189, 226, 0.5);
}
.zucai_box .el-table--mini td,
.zucai_box .el-table--mini th {
  padding: 0 !important;
}
.zucai_box .el-table .cell {
  height: 100%;
  line-height: 36px !important;
}
.zucai_box .cell span {
  display: block;
}
</style>
<style lang = 'less' scoped >
.zucai_box {
  background: #fff;
}
a {
  &:hover {
    color: #91c1f8;
  }
}
</style>