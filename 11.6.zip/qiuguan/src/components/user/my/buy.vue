<template>
  <div class="">
    <h2>我的购买</h2>
    <!-- <button @click="qq">12345</button> -->
    <el-card style="margin-top:10px">
      <div class=""
           v-if="buy_list">
        有购买
      </div>

      <div class=""
           v-else>
        尚无购买
      </div>

    </el-card>
  </div>
</template>
<script >
export default {
  data () {
    return {
      buy_list: []
    };
  },
  created () {
    this.goumai()
  },
  methods: {
    async goumai () {
      let obj_s = {
        data_type: 'userPay',
      }
      const { data: res } = await this.$http.get(`/user/forecastNotes/`, { params: obj_s });
      this.buy_list = res.results
      console.log(res.results)
    }
  }
}
</script>
<style lang = 'less' scoped >
</style>