<template>
  <!-- 详细数据统计 -->
  <div class="playerTechStatisticsTwo">
    <el-divider content-position="left">
      <h6>球员详细数据统计</h6>
    </el-divider>
    <div class="sx">
      <el-select v-model="value"
                 size="mini"
                 @change="on_sx"
                 placeholder="请选择">
        <el-option v-for="item in options"
                   :key="item.value"
                   :label="item.label"
                   :value="item.value">
        </el-option>
      </el-select>
      <div class="js_jj">
        近
        <b>{{value}}</b>场比赛，
        <i style="margin-left:4px"></i>首发
        <b>{{First_num}}</b>次,
        <i style="margin-left:4px"></i>平均上场时间
        <b>{{playing_num}}</b>分钟,
        <i style="margin-left:4px"></i>均进
        <b>{{Goals_num}}</b>个,
        <i style="margin-left:4px"></i>取得
        <b>{{spf_l[0]}}胜{{spf_l[1]}}平{{spf_l[2]}}负</b>的战绩。</div>
      <div>
        <el-tag size="small"
                @click="on_kind(3)"
                :type="kind==3?'success':'info'">全部</el-tag>
        <el-tag size="small"
                @click="on_kind(1)"
                :type="kind==1?'success':'info'">联赛</el-tag>
        <el-tag size="small"
                :type="kind==2?'success':'info'"
                @click="on_kind(2)">杯赛</el-tag>
      </div>
    </div>

    <el-table :data="playerTj"
              size="mini"
              :header-cell-style="{
    'color': '#000',
       'background-color': 'rgb(131, 162, 202)',
    'font-size':'14px'
}"
              style="width: 100%">
      <el-table-column align="center"
                       label="">
        <template slot="header"
                  slot-scope="scope">
          <div style="color:rgb(248, 51, 71);font-size: 18px;">
            <b>球员详细数据统计</b>
          </div>
        </template>
        <el-table-column prop="sclassName"
                         label="赛事"
                         align="center"
                         width="">
        </el-table-column>
        <el-table-column prop="matchtime"
                         label="时间"
                         align="center"
                         width="">
        </el-table-column>
        <el-table-column prop="ItemTeamName"
                         label="代表球队"
                         align="center"
                         width="">
          <template slot-scope="scope">
            <router-link target="_blank"
                         :style="`color:${scope.row.color}`"
                         style="font-weight: 900;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"
                         v-if="scope.row.ItemTeamid"
                         :to="{name:'lineup',params:{teamID:scope.row.ItemTeamid}}">{{scope.row.ItemTeamName}}</router-link>
          </template>
        </el-table-column>
        <el-table-column prop="Score"
                         label="比分"
                         align="center"
                         width="">
          <template slot-scope="scope">
            <router-link target="_blank"
                         v-if="scope.row.NotTeamid"
                         :to="{name:'history',params:{scheduleID:scope.row.scheduleID}}">{{scope.row.Score}}</router-link>
          </template>
        </el-table-column>
        <el-table-column prop="NotTeamName"
                         label="对手"
                         align="center"
                         width="">
          <template slot-scope="scope">
            <router-link target="_blank"
                         style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"
                         v-if="scope.row.NotTeamid"
                         :to="{name:'lineup',params:{teamID:scope.row.NotTeamid}}">{{scope.row.NotTeamName}}</router-link>
          </template>
        </el-table-column>
        <el-table-column prop="FirstTeam"
                         label="首发"
                         align="center"
                         width="">
        </el-table-column>
        <el-table-column prop="playingTime"
                         label="出场"
                         align="center"
                         width="">
        </el-table-column>
        <el-table-column prop="Goals"
                         label="进球"
                         align="center"
                         width="">
          <template slot-scope="scope">
            <svg aria-hidden="true"
                 v-for="(item,i) in scope.row.notPenaltyGoals"
                 :key="i"
                 class="icon big_da">
              <use xlink:href="#icon-jinqiu"></use>
            </svg>
            <svg aria-hidden="true"
                 v-for="(item,i) in scope.row.penaltyGoals"
                 :key="i+Math.random()"
                 class="icon big_da">
              <use xlink:href="#icon-dianqiu"></use>
            </svg>
          </template>
        </el-table-column>
        <el-table-column prop="owngoals"
                         label="乌龙球"
                         align="center"
                         width="">
          <template slot-scope="scope">
            <svg aria-hidden="true"
                 v-for="(item,i) in scope.row.owngoals"
                 :key="i"
                 class="icon big_da">
              <use xlink:href="#icon-zuqiuwulongqiu"></use>
            </svg>
          </template>
        </el-table-column>
        <el-table-column prop="sclassName"
                         label="得牌"
                         align="center"
                         width="">
          <template slot-scope="scope">
            <svg aria-hidden="true"
                 v-for="(item,i) in scope.row.yellow"
                 :key="i"
                 class="icon big_da ">
              <use xlink:href="#icon-huangpai"></use>
            </svg>
            <svg aria-hidden="true"
                 v-for="(item,i) in scope.row.red"
                 :key="i+Math.random()"
                 class="icon big_da ">
              <use xlink:href="#icon-hongpai"></use>
            </svg>

          </template>
        </el-table-column>
      </el-table-column>
    </el-table>

  </div>
</template>
<script >
import '../../../css/font/iconfont.js'
import '../../../css/font1/iconfont.js'
export default {
  data () {
    return {
      playerTj: [],
      options: [{
        value: '10',
        label: '近10场'
      }, {
        value: '20',
        label: '近20场'
      }, {
        value: '50',
        label: '近50场'
      }],
      value: 10,
      kind: 3,
      teamStyle: ['', '#icon-jinqiu', "#icon-hongpai", "#icon-huangpai", '#icon-huanru', '#icon-huanchu', '', '#icon-dianqiu', "#icon-zuqiuwulongqiu", "#icon-lianghuangbianhong1", , , , , "#icon-zhugongbang",],
      playing_num: 0,
      Goals_num: 0,
      First_num: 0,
      spf_l: [0, 0, 0]
    }
  },
  created () {
    this.playerTechStatisticsTwo()
  },
  methods: {
    async playerTechStatisticsTwo () {
      const { data } = await this.$http.get(`/teamInfo/player/${this.$route.params.playerID}/playerTechStatisticsTwo/`);
      // console.log(data.playerTj)
      data.playerTj.forEach(item => {
        item.Goals = item.notPenaltyGoals + item.penaltyGoals
        item.matchtime = item.matchtime.slice(0, 10)
        if (item.isFirstTeam) {
          item.FirstTeam = '是'
        } else {
          item.FirstTeam = '否'
        }
        if (item.teamID == item.hometeamID) {
          item.ItemTeamName = item.hometeamName
          item.NotTeamName = item.guestteamName
          item.ItemTeamid = item.hometeamID
          item.NotTeamid = item.guestteamID
          item.Score = `${item.homeScore}-${item.guestScore}`
          if (item.homeScore > item.guestScore) {
            item.color = 'rgb(255, 0, 0)'
          } else if (item.homeScore == item.guestScore) {
            item.color = '#000'
          } else {
            item.color = 'rgb(51, 102, 255)'
          }
        } else {
          item.ItemTeamName = item.guestteamName
          item.NotTeamName = item.hometeamName
          item.ItemTeamid = item.guestteamID
          item.NotTeamid = item.hometeamID
          item.Score = `${item.guestScore}-${item.homeScore}`
          if (item.homeScore > item.guestScore) {
            item.color = 'rgb(51, 102, 255)'
          } else if (item.homeScore == item.guestScore) {
            item.color = '#000'
          } else {
            item.color = 'rgb(255, 0, 0)'
          }
        }
      })
      this.playerTj = data.playerTj
      this.playerTj_list = data.playerTj
      this.on_sx(this.value)

    },
    On_tj (v, kind) {
      // 统计首发分钟进球胜平负
      let First_num = 0, playing_num = 0, Goals_num = 0, s_num = 0, p_num = 0, f_num = 0, list_num = []
      if (kind) {
        list_num = this.playerTj_list.slice(0, v).filter(item => item.kind == kind)
      } else {
        list_num = this.playerTj_list.slice(0, v)
      }
      list_num.forEach(item => {
        // 首发次数
        if (item.isFirstTeam) {
          First_num++
        }
        // 平均上场时间
        if (item.playingTime) {
          playing_num += item.playingTime
        }
        // 平均进球
        let jq = item.notPenaltyGoals + item.penaltyGoals
        Goals_num += jq
        // 胜平负
        if (item.color) {
          if (item.color == 'rgb(255, 0, 0)') {
            s_num++
          } else if (item.color == '#000') {
            p_num++
          } else {
            f_num++
          }
        }
      })
      this.First_num = First_num
      this.playing_num = (playing_num / v).toFixed(2)
      this.Goals_num = (Goals_num / v).toFixed(2)
      this.spf_l = [s_num, p_num, f_num]
      // console.log((playing_num / 10).toFixed(2))
      // console.log((Goals_num / 10).toFixed(2))
      // console.log(s_num, p_num, f_num)


    },
    // 筛选
    on_sx (v) {
      if (this.kind) {
        if (this.kind == 3) {
          this.playerTj = this.playerTj_list.slice(0, v)
          this.On_tj(v)
        } else {
          this.playerTj = this.playerTj_list.filter(item => item.kind == this.kind).slice(0, v)
          this.On_tj(v, this.kind)
        }
      } else {
        this.playerTj = this.playerTj_list.slice(0, v)
      }
    },
    on_kind (v) {
      this.kind = v
      this.on_sx(this.value)
    }

  }
}
</script>
<style lang = 'less' >
.playerTechStatisticsTwo {
  .js_jj {
    font-size: 12px;
    b {
      color: red;
    }
  }
  h6 {
    font-size: 18px;
    font-weight: 900;
  }
  .el-select {
    width: 100px;
  }
  .big_da {
    height: 20px;
  }
  .sx {
    display: flex;
    justify-content: space-between;
    align-items: center;
    .el-tag {
      margin-left: 10px;
      cursor: pointer;
    }
  }
}
</style>

