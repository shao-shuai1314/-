<template>
  <div class="gWidth livecebter_box"
       v-cloak>
    <el-card>
      <!-- 选项 -->
      <el-tabs v-model="activeName"
               @tab-click="handleClick">
        <el-tab-pane label="足彩"
                     name="zc14"></el-tab-pane>
        <!-- <el-tab-pane label="竞彩"
                     name="jczq"></el-tab-pane>
        <el-tab-pane label="北京单场"
                     name="bd"></el-tab-pane> -->
      </el-tabs>
      <div class="zuc_s">
        <div>
          <el-select v-model="value"
                     @change="onOptions"
                     placeholder="请选择">
            <el-option v-for="(item,index) in options"
                       :key="index"
                       :label="item.val"
                       :value="{value:item.val,label:item.time}">
            </el-option>
          </el-select>
          <!-- 最新彩票比赛 -->
          <el-link :type="value==item?'primary':''"
                   style="margin:0 10px"
                   v-for="item in new_nums"
                   :key="item.val"
                   @click="new_num(item)">{{item.val}}</el-link>
        </div>
        <div>
          <el-radio-group v-model="radio"
                          @change="on_radio">
            <el-radio :label="20">全部比赛</el-radio>
            <el-radio :label="0">未开场</el-radio>
            <el-radio :label="-1">已完场</el-radio>
            <el-radio :label="21">进行时</el-radio>
          </el-radio-group>
        </div>
        <div>
          <el-checkbox style="margin-left:20px"
                       v-if="isTrue"
                       v-model="checked"
                       @change="onchecked">隐藏已停售比赛</el-checkbox>
          <el-select v-if="isTrue"
                     v-model="value_s"
                     style="margin-left:20px"
                     @change="onOptions_s"
                     placeholder="日期筛选">
            <el-option v-for="(item,index) in options_s"
                       :key="index"
                       :label="item"
                       :value="index">
            </el-option>
          </el-select>
        </div>

      </div>

      <div v-if="isTrue"
           style="margin-top:10px">
        <b>
          {{weekday}}
        </b>
      </div>

      <el-table :data="tableData"
                size="mini"
                border
                :header-cell-style="{
    'color': '#303133',
    'border-bottom': '1px rgb(103, 194, 58) solid',
    'text-align':'center',
    'font-size':'16px',
}"
                style="width: 100%">
        <el-table-column prop="num"
                         label=""
                         align="center"
                         width="30">
        </el-table-column>
        <el-table-column prop="matchtime"
                         label="比赛时间"
                         align="center"
                         width="">
          <template slot-scope="scope">
            <div style="display: flex;justify-content: center">
              {{scope.row.matchtime.replace("T"," ")　}}
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="num"
                         label="状 态"
                         align="center"
                         width="50">
          <template slot-scope="scope">
            <div style="display: flex;justify-content: center">
              {{z_t[scope.row.matchState]}}
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="sclassName"
                         label="赛 事"
                         align="center"
                         width="100">
          <template slot-scope="scope">
            <div style="display: flex;justify-content: center">
              <div style="width:150px;font-weight: 900;">
                <router-link target="_blank"
                             v-if="scope.row.sclassId"
                             :style="{'color':scope.row.color?scope.row.color:''}"
                             :to="{name:'league',params:{sclassID:scope.row.sclassId}}">{{scope.row.sclassName}}</router-link>
              </div>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="homeName"
                         label="主  队"
                         align="center"
                         width="">
          <template slot-scope="scope">
            <div class="fl-ss">
              <span>
                {{scope.row.home_order}}
              </span>
              <router-link target="_blank"
                           v-if="scope.row.hometeamId"
                           :to="{name:'lineup',params:{teamID:scope.row.hometeamId}}">{{scope.row.homeName}}</router-link>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="address"
                         align="center"
                         width="50"
                         label="比  分">
          <template slot-scope="scope">
            <div @click="getmatchSeason(scope.row.matchSeason,scope.row.sclassName,scope.row.scheduleId)"
                 style="cursor: pointer;">
              <span v-if="scope.row.matchState == -1||scope.row.matchState == 1||scope.row.matchState == 2||scope.row.matchState == 3||scope.row.matchState == 4||scope.row.matchState == 5">
                <span style="color:rgb(244, 104, 89);font-weight: 900;">{{scope.row.homeScore}}-{{scope.row.guestScore}}</span>
              </span>
              <span v-else>VS</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="guestName"
                         align="center"
                         label="客  队">
          <template slot-scope="scope">
            <div class="fl-ss">
              <router-link target="_blank"
                           v-if="scope.row.guestteamId"
                           :to="{name:'lineup',params:{teamID:scope.row.guestteamId}}">{{scope.row.guestName}}</router-link>
              <span>
                {{scope.row.guest_order}}
              </span>
            </div>
          </template>
        </el-table-column>

        <el-table-column prop="address"
                         align="center"
                         width="50"
                         label="半 场">
          <template slot-scope="scope">
            <div>
              <span v-if="scope.row.matchState == -1||scope.row.matchState == 1||scope.row.matchState == 2||scope.row.matchState == 3||scope.row.matchState == 4||scope.row.matchState == 5">
                <span style="color:rgb(244, 104, 89);">{{scope.row.homeHalfScore}}-{{scope.row.guestHalfScore}}</span>
              </span>
              <span v-else>VS</span>
            </div>
          </template>
        </el-table-column>

        <el-table-column prop="scheduleId"
                         align="center"
                         width="200"
                         v-if="bd"
                         label="欧赔">
          <template slot-scope="scope">
            <div v-for="(item,i) in oddsList"
                 :key="i">
              <div v-if="item.scheduleID == scope.row.scheduleId"
                   class="oddsList">
                <span v-if="scope.row.color_ss1"
                      :class="scope.row.color_ss1"
                      class=" ys_s">
                  {{item.firstUpOdds}}
                </span>
                <span v-else>
                  {{item.firstUpOdds}}
                </span>

                <span v-if="scope.row.color_ss2"
                      :class="scope.row.color_ss2"
                      class=" ys_s">
                  {{item.firstGoal}}
                </span>
                <span v-else>
                  {{item.firstGoal}}
                </span>

                <span v-if="scope.row.color_ss3"
                      :class="scope.row.color_ss3"
                      class=" ys_s">
                  {{item.firstDownOdds}}
                </span>
                <span v-else>
                  {{item.firstDownOdds}}
                </span>

              </div>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="cg"
                         align="center"
                         width="40"
                         label="彩 果">
        </el-table-column>
      </el-table>
      <div class="wzsm_ss">
        <div class="tw">
          指数分布：
          <p>
            <span>
              <i class="ys_l"></i>
              首指={{S_z}}
            </span>
            <span>
              <i class="ys_y"></i>
              次指={{C_z}}
            </span>
            <span>
              <i class="ys_h"></i>
              末指={{M_z}}
            </span>
          </p>
          <p>
            <!-- <span>
              <svg class="icon"
                   aria-hidden="true">
                <use xlink:href="#icon-jinqiu"></use>
              </svg>
              进球
            </span>
            <span>
              <svg class="icon"
                   aria-hidden="true">
                <use xlink:href="#icon-dianqiu"></use>
              </svg>
              点球
            </span>
            <span>
              <svg class="icon"
                   aria-hidden="true">
                <use xlink:href="#icon-wulongqiu"></use>
              </svg>
              乌龙球
            </span>
            <span>
              <svg class="icon"
                   aria-hidden="true">
                <use xlink:href="#icon-hongpai"></use>
              </svg>
              红牌
            </span> -->
          </p>
          <p>
          </p>
        </div>
      </div>
    </el-card>

  </div>
</template>
<script >
import '../css/font2/iconfont.js'

export default {
  data () {
    return {
      tableData: [],
      options: [],
      value: '',
      new_nums: [],
      sty_name: 'zc14',
      options_s: [],
      value_s: '',
      timelist: [],
      weekdayL: [],
      weekday: '',
      isTrue: false,
      act: false,
      activeName: 'zc14',
      jkname: 'zc14',
      checked: false,
      zucai_true: true,
      val_xz: 0,
      val_M: 0,
      v_b: 1,
      oddsList: [
        {
          col0: false,
          col1: false,
          col3: false,
          o_list: 0
        }
      ],
      z_t: {
        '0': '未',
        '1': '上半场',
        '2': '中场',
        '3': '下半场',
        '4': '加时',
        '5': '点球',
        '-1': '完',
        '-10': '取消',
        '-11': '待定',
        '-12': '腰斩',
        '-13': '中断',
        '-14': '推迟',
      },
      S_z: 0,
      C_z: 0,
      M_z: 0,
      bd: true,
      radio: 20
    };
  },
  created () {
    this.onDataList('zc14')
  },
  watch: {
  },
  computed: {
  },

  methods: {
    // 点击跳转
    getmatchSeason (matchSeason, sclassName, scheduleId) {
      // console.log(matchSeason)
      sessionStorage.setItem("matchSeason", matchSeason);
      sessionStorage.setItem("sclassName", sclassName);
      // this.$router.go(0);
      let routeUrl = this.$router.resolve({
        name: "history",
        params: { scheduleID: scheduleId }
      });
      window.open(routeUrl.href, '_blank');
    },

    // 14场点击
    onC (v, i) {
      let aa = 'col' + v
      // console.log(aa)
      this.tableData[i][aa] = !this.tableData[i][aa]
      this.js_aa()
      this.$set(this.tableData, i, this.tableData[i])
      // console.log(this.tableData)
    },
    isnumber (val) {
      val = val.replace(/[^0-9]/gi, "");
      // 此处还可以限制位数以及大小
      if (val >= 1 && val <= 99) {
        this.v_b = val
        if (this.v_b) {
          this.val_M = this.v_b * this.val_M_s
        }
      } else {
        this.v_b = 1
        if (this.v_b) {
          this.val_M = this.v_b * this.val_M_s
        }
      }
      return val;
    },
    async onDataList (val, i) {
      this.jkname = i
      let obj = {}
      if (i) {
        obj.issueNum = i
      }
      const res = await this.$http.get(`zucai/${val}/`, { params: obj });
      this.tableDatas = res.data
      // console.log(res.data.history_nums)
      this.tableData = res.data.data_obj.match_list
      //  更改切换字符串
      let history_nums = [], new_nums = []
      res.data.history_nums.forEach(item => {
        let aa = {}
        aa.val = item
        history_nums.push(aa)
      })
      res.data.new_nums.forEach(item => {
        let aa = {}
        aa.val = item
        new_nums.push(aa)
      })
      this.options = history_nums
      // this.options = res.data.history_nums
      this.value = res.data.data_obj.issueNum
      this.new_nums = new_nums

      // 欧赔
      if (val != 'bd') {
        let scheduleId_l = []
        this.tableData.forEach(item => {
          scheduleId_l.push(item.scheduleId)
        })

        let obj_s = {}
        obj_s.scheduleIDs = scheduleId_l.join(",")
        obj_s.companyID = 281
        obj_s.oddsType = 3
        const shceduleOdds = await this.$http.get('odds/shceduleOdds/', { params: obj_s });
        this.oddsList = shceduleOdds.data.oddsList
        let s_s = [], c_s = [], m_s = []
        this.tableData.forEach(item => {
          let a_s = shceduleOdds.data.oddsList.find(it => it.scheduleID == item.scheduleId)
          if (a_s) {
            item.firstUpOdds = a_s.firstUpOdds
            item.firstGoal = a_s.firstGoal
            item.firstDownOdds = a_s.firstDownOdds
            item.oddsID = a_s.oddsID
          }
          if (item.matchState == -1) {
            if (item.homeScore > item.guestScore) {
              item.cg = 3
              m_s.push(item)
            } else if (item.homeScore < item.guestScore) {
              item.cg = 0
              s_s.push(item)
            } else {
              item.cg = 1
              c_s.push(item)
            }
          }
        })
        m_s.forEach(item => {
          if (item.firstUpOdds > item.firstGoal && item.firstUpOdds > item.firstDownOdds) {
            item.color_ss1 = 'ys_h'
            item.color_ss = 'ys_h'
          } else if (item.firstUpOdds < item.firstGoal && item.firstUpOdds < item.firstDownOdds) {
            item.color_ss1 = 'ys_l'
            item.color_ss = 'ys_l'
          } else {
            if (item.firstUpOdds == item.firstGoal && item.firstUpOdds < item.firstDownOdds) {
              item.color_ss1 = 'ys_l'
              item.color_ss = 'ys_l'
            } else if (item.firstUpOdds == item.firstDownOdds && item.firstUpOdds < item.firstGoal) {
              item.color_ss1 = 'ys_l'
              item.color_ss = 'ys_l'
            } else if (item.firstUpOdds == item.firstGoal && item.firstUpOdds > item.firstDownOdds) {
              item.color_ss1 = 'ys_y'
              item.color_ss = 'ys_y'
            } else if (item.firstUpOdds == item.firstDownOdds && item.firstUpOdds > item.firstGoal) {
              item.color_ss1 = 'ys_y'
              item.color_ss = 'ys_y'
            } else {
              item.color_ss1 = 'ys_y'
              item.color_ss = 'ys_y'
            }
          }
        })
        c_s.forEach(item => {
          if (item.firstGoal > item.firstUpOdds && item.firstGoal > item.firstDownOdds) {
            item.color_ss2 = 'ys_h'
            item.color_ss = 'ys_h'
          } else if (item.firstGoal < item.firstUpOdds && item.firstGoal < item.firstDownOdds) {
            item.color_ss2 = 'ys_l'
            item.color_ss = 'ys_l'
          } else {
            if (item.firstGoa == item.firstUpOdds && item.firstGoa < item.firstDownOdds) {
              item.color_ss2 = 'ys_l'
              item.color_ss = 'ys_l'
            } else if (item.firstGoa == item.firstDownOdds && item.firstGoa < item.firstUpOdds) {
              item.color_ss2 = 'ys_l'
              item.color_ss = 'ys_l'
            } else if (item.firstGoa == item.firstUpOdds && item.firstGoa > item.firstDownOdds) {
              item.color_ss2 = 'ys_y'
              item.color_ss = 'ys_y'
            } else if (item.firstGoa == item.firstDownOdds && item.firstGoa > item.firstUpOdds) {
              item.color_ss2 = 'ys_y'
              item.color_ss = 'ys_y'
            } else {
              item.color_ss2 = 'ys_y'
              item.color_ss = 'ys_y'
            }
          }
        })
        s_s.forEach(item => {
          if (item.firstDownOdds > item.firstUpOdds && item.firstDownOdds > item.firstGoal) {
            item.color_ss3 = 'ys_h'
            item.color_ss = 'ys_h'
          } else if (item.firstDownOdds < item.firstUpOdds && item.firstDownOdds < item.firstGoal) {
            item.color_ss3 = 'ys_l'
            item.color_ss = 'ys_l'
          } else {
            if (item.firstDownOdds == item.firstGoal && item.firstDownOdds < item.firstUpOdds) {
              item.color_ss3 = 'ys_l'
              item.color_ss = 'ys_l'
            } else if (item.firstDownOdds == item.firstUpOdds && item.firstDownOdds < item.firstGoal) {
              item.color_ss3 = 'ys_l'
              item.color_ss = 'ys_l'
            } else if (item.firstDownOdds == item.firstGoal && item.firstDownOdds > item.firstUpOdds) {
              item.color_ss3 = 'ys_y'
              item.color_ss = 'ys_y'
            } else if (item.firstDownOdds == item.firstUpOdds && item.firstDownOdds > item.firstGoal) {
              item.color_ss3 = 'ys_y'
              item.color_ss = 'ys_y'
            } else {
              item.color_ss3 = 'ys_y'
              item.color_ss = 'ys_y'
            }
          }
        })
        this.S_z = Array.isArray(this.tableData.filter(item => item.color_ss == "ys_l")) ? this.tableData.filter(item => item.color_ss == "ys_l").length : 0
        this.C_z = Array.isArray(this.tableData.filter(item => item.color_ss == "ys_y")) ? this.tableData.filter(item => item.color_ss == "ys_y").length : 0
        this.M_z = Array.isArray(this.tableData.filter(item => item.color_ss == "ys_h")) ? this.tableData.filter(item => item.color_ss == "ys_h").length : 0


        let that = this
        // this.$set(this.tableData, 0, {          matchtime: "2020-11-06T15:40:00", color: "#FF3333",
        //   guestHalfScore: 0,
        //   guestName: "利兹联",
        //   guestScore: 0,
        //   guest_order: "12",
        //   guest_red: 0,
        //   guestteamId: 56,
        //   homeHalfScore: 0,
        //   homeName: "水晶宫",
        //   homeScore: 0,
        //   home_order: "13",
        //   home_red: 0,
        //   hometeamId: 35,
        //   issueNum: "2020059",
        //   isturn: 0,
        //   matchSeason: "2020-2021",
        //   matchState: 0,
        //   num: 1,
        //   round: 8,
        //   scheduleId: 1903873,
        //   sclassId: 36,
        //   sclassName: "英超",
        //   temperature: null,
        //   weather: null,        })
        // this.$set(this.tableData, 1, {          matchtime: "2020-11-06T15:40:00", color: "#FF3333",
        //   guestHalfScore: 0,
        //   guestName: "利兹联",
        //   guestScore: 0,
        //   guest_order: "12",
        //   guest_red: 0,
        //   guestteamId: 56,
        //   homeHalfScore: 0,
        //   homeName: "水晶宫",
        //   homeScore: 0,
        //   home_order: "13",
        //   home_red: 0,
        //   hometeamId: 35,
        //   issueNum: "2020059",
        //   isturn: 0,
        //   matchSeason: "2020-2021",
        //   matchState: 0,
        //   num: 1,
        //   round: 8,
        //   scheduleId: 1903874,
        //   sclassId: 36,
        //   sclassName: "英超",
        //   temperature: null,
        //   weather: null,        })

        // 实时更新
        async function scheduleIDs (scheduleIDs_l) {
          // console.log(res_aa)
          const res_aa = await that.$http.get(`/soccer/matchChange`, { params: { scheduleIDs: scheduleIDs_l.join() } });
          // console.log(that.tableData)
          // res_aa.data.data[0].homeScore = 0
          // res_aa.data.data[0].homeScore++
          // res_aa.data.data[0].matchState = 1

          that.tableData.forEach(item => {
            let dd = res_aa.data.data.find(ii => ii.scheduleID == item.scheduleId)
            // console.log(dd)
            if (dd) {
              item.homeScore = dd.homeScore
              item.guestScore = dd.guestScore
              item.homeHalfScore = dd.homeHalfScore
              item.guestHalfScore = dd.guestHalfScore
              item.home_order = dd.home_order
              item.guest_order = dd.guest_order
              item.matchState = dd.matchState
            }

            // console.log(item.homeScore)
            // if (res_aa.data.data.find(ii => ii.scheduleId == item.scheduleId).length) {
            //   item = res_aa.data.data.find(ii => ii.scheduleId == item.scheduleId)
            // }

          })
          console.log(that.tableData)
        }
        var timer = setInterval(function () {
          var date = new Date();
          var Y = date.getFullYear();
          var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1);
          var D = (date.getDate() < 10 ? '0' + date.getDate() : date.getDate());
          var h = (date.getHours() < 10 ? '0' + date.getHours() : date.getHours());
          var m = (date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes());
          var s = date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds();
          // 你已知的时间
          var new_t = new Date(Y, M, D, h, m, s);
          // 转化为时间戳毫秒数
          var new_s = new_t.getTime();
          let new_tableData = that.tableData.filter(item => {
            let aa, bb, cc, dd, ee, ff
            aa = item.matchtime.slice(0, 4)
            bb = item.matchtime.slice(5, 7)
            cc = item.matchtime.slice(8, 10)
            dd = item.matchtime.slice(11, 13)
            ee = item.matchtime.slice(14, 16)
            ff = item.matchtime.slice(17, 19)
            var t = new Date(aa, bb, cc, dd, ee, ff);
            // 转化为时间戳毫秒数
            var t_s = t.getTime();
            return t_s <= new_s && t.setTime(t_s + 1000 * 60 * 130) >= new_s
          })
          // 有正在比赛的
          if (new_tableData.length) {
            // console.log(new_tableData)
            let scheduleIDs_l = []
            new_tableData.forEach(item => {
              scheduleIDs_l.push(item.scheduleId)
            })
            scheduleIDs(scheduleIDs_l)
          }
        }, 30000);
        // clearInterval(timer)
      }
      if (val == 'zc14') {
        this.isTrue = false
        // 更改切换字符串
        let history_nums = [], new_nums = []
        res.data.history_nums.forEach(item => {
          let aa = {}
          aa.val = item.slice(2)
          aa.time = item.slice(0, 2)
          history_nums.push(aa)
        })
        res.data.new_nums.forEach(item => {
          let aa = {}
          aa.val = item.slice(2)
          aa.time = item.slice(0, 2)
          new_nums.push(aa)
        })
        this.value = res.data.data_obj.issueNum.slice(2)
        this.options = history_nums
        this.new_nums = new_nums
        // console.log(this.options)
      }
      if (val == 'jczq') {
        this.zucai_true = false
      }
      if (val == 'bd') {
        let list_s = []
        // 时间去重、
        res.data.data_obj.match_list.forEach(item => {
          if (item.matchtime) {
            list_s.push(item.matchtime.slice(0, 10))
          }
        })
        //日期排序
        function sortDownDate (a, b) {
          return Date.parse(a) - Date.parse(b);
        }
        list_s.sort(sortDownDate)
        var Today = new Date();
        var weekday = ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"];
        var s1 = Today.getFullYear() + "-" + (Today.getMonth() + 1) + "-" + Today.getDate();
        // console.log(s1)
        var s11 = new Date(`${s1} 10:00:00`).getTime()
        let list_s_s = [...new Set(list_s)]
        let timelist_s = []
        this.options_s = []
        let weekdayL_s = []
        list_s_s.forEach(item => {
          // 当前日期加一
          let startDate = new Date(item)
          startDate = +startDate + 1000 * 60 * 60 * 24;
          startDate = new Date(startDate);
          var nextStartDate = startDate.getFullYear() + "-" + (startDate.getMonth() + 1) + "-" + startDate.getDate();
          var s11 = new Date(`${item} 10:00:00`).getTime()
          var s22 = new Date(`${nextStartDate} 10:00:00`).getTime()
          let aa = { start: s11, end: s22 }
          // 周几
          var myDate = new Date(Date.parse(item.replace(new RegExp("-", "gm"), "/")));
          let bb = `${weekday[myDate.getDay()]}  ${item}  [10:00 -- 次日 10:00]}`
          weekdayL_s.push(bb)
          timelist_s.push(aa)
          this.options_s.push(item)
        })
        // console.log(timelist_s)
        this.timelist = timelist_s
        this.weekdayL = weekdayL_s
        this.options_s.push('全部')

        this.zucai_true = false
        this.isTrue = true
      } else {
        this.isTrue = false
      }

      // console.log(this.tableData)
    },
    // 最新彩票切换
    new_num (tade) {
      // console.log(tade.time, tade.val)
      let v = ''
      if (this.sty_name == 'zc14') {
        v = tade.time + tade.val
      } else {
        v = tade.val
      }
      // console.log(v)
      this.onDataList(this.sty_name, v)
    },
    // 足彩切换
    async onOptions (params) {
      this.radio = 20
      // console.log(params)
      let v = ''
      if (this.sty_name == 'zc14') {
        this.tableData_aaa
        v = params.label + params.value
      } else {
        v = params.value
      }
      this.onDataList(this.sty_name, v)
      this.tableData = this.tableDatas.data_obj.match_list
      let scheduleId_l = []
      this.tableData.forEach(item => {
        item.o3 = 3
        item.o1 = 1
        item.o0 = 0
        item.col0 = false
        item.col1 = false
        item.col3 = false
        item.o_list = 0
        scheduleId_l.push(item.scheduleId)
      })

      if (this.sty_name == 'zc14') {
        let obj = {}
        obj.scheduleIDs = scheduleId_l.join(",")
        obj.companyID = 281
        obj.oddsType = 3
        const shceduleOdds = await this.$http.get('odds/shceduleOdds/', { params: obj });
        this.oddsList = shceduleOdds.data.oddsList
      }
      this.val_xz = 0
      this.val_M = 0
    },
    onOptions_s (v) {
      // console.log(v, this.timelist)
      if (v == this.timelist.length) {
        this.tableData = this.tableDatas.data_obj.match_list
        this.act = true
        this.weekday = ''
        this.checked = false
        return
      }
      this.act = false
      this.tableData = this.tableDatas.data_obj.match_list.filter(item => {
        return new Date(item.matchtime).getTime() >= this.timelist[v].start && new Date(item.matchtime).getTime() < this.timelist[v].end
      })
      this.weekday = this.weekdayL[v]
    },
    // 选择
    handleClick (tab, event) {
      this.radio = 20
      this.val_xz = 0
      this.val_M = 0
      this.sty_name = tab.name
      this.onDataList(tab.name)
      this.value_s = '',
        this.weekday = ''
    },
    // 显示已停售比赛
    onchecked (v) {
      if (v) {
        this.tableData = this.tableDatas.data_obj.match_list.filter(item => {
          return item.matchState == 0
        })
      } else {
        this.tableData = this.tableDatas.data_obj.match_list
      }
    },
    // 筛选比赛
    on_radio (v) {
      console.log(v)
      if (v == 20) {
        this.tableData = this.tableDatas.data_obj.match_list
      } else if (v == 21) {
        this.tableData = this.tableDatas.data_obj.match_list.filter(item => item.matchState == 1 || item.matchState == 2 || item.matchState == 3 || item.matchState == 4 || item.matchState == 5)

      } else {
        this.tableData = this.tableDatas.data_obj.match_list.filter(item => item.matchState == v)
      }
    }
  }
}
</script>
<style lang = 'less'>
.livecebter_box {
  .wzsm_ss {
    height: 60px;
    align-items: center;
    display: flex;
    font-size: 14px;
    .tw {
      width: 100%;
      height: 30px;
      display: flex;
      align-items: center;
      p {
        height: 30px;
        margin-left: 20px;
        display: flex;
        align-items: center;
        span {
          height: 30px;
          margin: 0 10px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          svg {
            width: 30px;
            height: 30px;
          }
          i {
            display: inline-block;
            width: 26px;
            height: 20px;
            margin-right: 10px;
          }
          .icon {
            margin-right: 10px;
          }
        }
      }
    }
  }

  .ys_s {
    display: inline-block;
    height: 20px;
    margin-top: 6px;
    line-height: 20px;
    color: #fff;
  }
  .ys_l {
    background: #3c64db;
  }
  .ys_y {
    background: #d8cb29;
  }
  .ys_h {
    background: #ed5427;
  }
  .ppp {
    width: 200px;
    height: 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .dd {
    float: right;
    margin-top: 10px;
    width: 500px;
    display: flex;
    align-items: center;
    justify-content: center;
    /* flex-direction: column; */
    .el-input {
      width: 50px;
      display: flex;
      justify-content: center;
    }
    .el-input__inner {
      padding: 0 !important;
      height: 20px !important;
    }
    span {
      color: #999999;
      font-size: 14px;
    }
    b {
      color: #660000;
    }
  }
  .oddsList {
    display: flex;
    justify-content: space-around;
    span {
      display: inline-block;
      width: 40px;
    }
  }
  .quan_tj {
    display: flex;
    align-items: center;
    justify-content: space-around;
    .el-checkbox {
      display: flex;
      align-items: center;
    }
  }
}

.livecebter_box .el-table .warning-row {
  background: rgba(160, 189, 226, 0.2) !important;
}
.livecebter_box .el-table--enable-row-hover .el-table__body tr:hover > td {
  background-color: rgba(160, 189, 226, 0.5);
}
.livecebter_box .el-table--mini td,
.livecebter_box .el-table--mini th {
  padding: 0 !important;
}
.livecebter_box .el-table .cell {
  font-size: 16px !important;
  height: 100%;
  line-height: 36px !important;
}
.livecebter_box .el-table .fl-ss {
  display: flex;
  justify-content: space-between;
  span {
    font-size: 14px;
    min-width: 60px;
    display: flex;
    justify-content: center;
    color: #9a9a9a;
  }
  a {
    min-width: 100px;
    display: flex;
    justify-content: center;
  }
}
.livecebter_box .cell span {
  display: block;
}
</style>
<style lang = 'less' scoped >
.livecebter_box {
  background: #fff;
}
a {
  &:hover {
    color: #91c1f8;
  }
}
[v-cloak] {
  display: none !important;
}
.zuc_s {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
</style>