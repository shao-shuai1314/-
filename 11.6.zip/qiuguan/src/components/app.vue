<template>
  <div class="app_box">
    <el-card>
      {{val_xz}}
    </el-card>
    <el-table :data="tableData"
              :key="Math.random()"
              size="mini"
              border
              :header-cell-style="{
    'color': '#303133',
    'border-bottom': '1px rgb(103, 194, 58) solid',
    'text-align':'center',
    'font-size':'16px',
}"
              style="width: 100%">
      <el-table-column prop="num"
                       label=""
                       align="center"
                       width="30">
      </el-table-column>
    </el-table>

    <el-button @click="aa">111</el-button>
  </div>
</template>
<script >
export default {
  data () {
    return {
      val_xz: 0,
      tableData: []
    };
  },
  methods: {
    aa () {
      this.val_xz = 1
    },
  }
}
</script>
<style lang = 'less' scoped >
.app_box {
  width: 100%;
  height: 765px;
  background-color: #fff !important;
  background: url('/static/appbj.png') no-repeat center;
}
</style>