<template>
  <div class="contract_box">
    <h2 >法律声明</h2>
    <el-divider></el-divider>
    <p>
      本网站所提供的数据仅供体育爱好者进行比赛浏览观看研究之用，任何人不得利用本网站所提供的信息进行任何非法活动，否则责任自负。所有本网站内刊载之广告，均为广告客户的个人意见及表达方式，与本站无任何关系。所有广告内容不得违反国家法律规定，不得涉及反动、 迷信、淫秽、赌博等有害内容，如有违者，本网站有权随时予以删除，并保留与有关部门合作追究的权利。
    </p>


  </div>
</template>
<script >
export default {
  data () {
    return {
    };
  },
  methods: {
  }
}
</script>
<style lang = 'less' scoped >
.contract_box{
    p{
    padding: 10px 0;
    text-indent: 20px;
    font-size: 14px;
    color: #666;
  }
}
</style>