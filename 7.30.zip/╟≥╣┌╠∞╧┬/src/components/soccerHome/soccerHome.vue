<template>
  <div>
    <!-- 路由占位符 -->
    <router-view></router-view>
  </div>
</template>
<script >
export default {
  name: 'HelloWorld',
  data () {
    return {
    };
  },
  methods: {
  }
}
</script>
<style lang = 'less' scoped >
</style>