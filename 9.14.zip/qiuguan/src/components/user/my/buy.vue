<template>
  <div class="">
    <h2>我的购买</h2>
    <el-card style="margin-top:10px">
      <div class="">
        尚无购买
      </div>

    </el-card>
  </div>
</template>
<script >
export default {
  data () {
    return {
    };
  },
  methods: {
  }
}
</script>
<style lang = 'less' scoped >
</style>