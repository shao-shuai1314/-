<template>
  <div class="aboutus_box">
    <h2>关于我们</h2>

    <el-divider></el-divider>

    <p>
      北京野马尘埃文化发展有限公司于2011年正式创建。是一家以互联网信息服务（移动互联网应用等）为主的研发、运营、销售及投资的高科技文化创意企业。项目团队在产品策划、数据分析、技术实现等方面具有国内领先水平，运营团队在互联网产品的市场营销、运营服务、用户发展等方面具有丰富的资源和经验。
    </p>
    <p>
      2017年起，野马尘埃文化开始向互联网体育大数据方向发力，并逐步切入中国体育垂直市场。公司运用拥有自主知识产权的信息服务系统软件研发出了具有自主创新能力的互联网+体育大数据服务平台——球冠天下。通过人工智能算法，结合比赛基本面、球队技战术大数据、前方情报等多维度分析，为用户提供及时、全面、准确的体育大数据分析和赛事资讯服务。
    </p>

  </div>
</template>
<script >
export default {
  data () {
    return {
    };
  },
  methods: {
  }
}
</script>
<style lang = 'less' scoped >
.aboutus_box{
  p{
    padding: 10px 0;
    text-indent: 20px;
    font-size: 14px;
    color: #666;
  }
}
</style>