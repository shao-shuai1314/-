<template>
  <div class="history_table1">
    12345
  </div>

</template>
<script>
export default {
  data () {
    return {

    }
  }
}
</script>

