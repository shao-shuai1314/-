<template>
  <div class="coach_bix-s">
    <el-table :data="home_list"
              border
              size="mini"
              :header-cell-style="{
    'color': '#303133',
    'font-weight:':900,
    'font-size':'14px',
}"
              style="width: 100%">
      <el-table-column prop="date"
                       align="center"
                       width="">
        <template slot="header"
                  slot-scope="scope">
          <div class="tableData-header">
            <!-- <b>{{TeamNameInfo[0]}} &nbsp; &nbsp; &nbsp; &nbsp;VS&nbsp; &nbsp; &nbsp; &nbsp; {{TeamNameInfo[2]}}</b> -->
            <b>{{CoachNameInfo[0]}}
              <i style="margin-left:20px"></i>vs
              <i style="margin-left:20px"></i>{{TeamNameInfo[2]}}</b>
          </div>
        </template>
        <el-table-column prop="date"
                         width="">
          <template slot="header"
                    slot-scope="scope">
            <div class="tableData-xheader">
              <b>
                <span style="margin-left:50px">总：</span>
                <span>{{Win}}胜， </span>
                <span>{{flat}}平， </span>
                <span>{{load}}负 </span>
                <span style="margin-left:80px">
                  <span>其中主场：</span>
                  <span>{{s}}胜，</span>
                  <span>{{p}}平，</span>
                  <span>{{f}}负</span>
                </span>
              </b>
            </div>
          </template>
          <el-table-column prop="matchSeason"
                           label="赛季"
                           align="center"
                           width="170">
            <template slot-scope="scope">
              <span>
                {{scope.row.classname}} ({{scope.row.matchSeason}})
              </span>
            </template>
          </el-table-column>
          <el-table-column prop="matchtime"
                           label="比赛时间"
                           align="center"
                           width="180">
          </el-table-column>
          <el-table-column prop="place"
                           align="center"
                           width=""
                           label="主队">
            <template slot-scope="scope">
              <span class="spspsps">
                <router-link target="_blank"
                             class="span"
                             :to="{name:'lineup',params:{teamID:scope.row.hometeamID}}">
                  {{scope.row.homeName}}
                </router-link>
                <router-link target="_blank"
                             class="span"
                             style="margin-left:20px"
                             v-if="scope.row.homeCoachId"
                             :style="{'color':(scope.row.colors)}"
                             :to="{name:'playerDetails',params:{playerID:scope.row.homeCoachId}}">
                  ({{scope.row.homeCoachName}})
                </router-link>
              </span>
            </template>
          </el-table-column>
          <el-table-column prop="country"
                           align="center"
                           width="50"
                           label="比分">
            <template slot-scope="scope">
              <router-link target="_blank"
                           :to="{name:'history',params:{scheduleID:scope.row.scheduleID}}">
                {{scope.row.homeScore}} - {{scope.row.guestScore}}
              </router-link>
            </template>
          </el-table-column>
          <el-table-column prop="birthday"
                           align="center"
                           width=""
                           label="客队">
            <template slot-scope="scope">
              <span class="spspsps">
                <router-link target="_blank"
                             class="span"
                             :to="{name:'lineup',params:{teamID:scope.row.guestteamID}}">
                  {{scope.row.guestName}}
                </router-link>
                <router-link target="_blank"
                             class="span"
                             style="margin-left:20px"
                             v-if="scope.row.guestCoachId"
                             :style="{'color':(scope.row.colorss)}"
                             :to="{name:'playerDetails',params:{playerID:scope.row.guestCoachId}}">
                  ({{scope.row.guestCoachName}})
                </router-link>
              </span>
            </template>
          </el-table-column>

        </el-table-column>
      </el-table-column>
    </el-table>

    <el-table :data="guest_list"
              border
              size="mini"
              :header-cell-style="{
    'color': '#303133',
    'font-weight:':900,
    'font-size':'14px',
}"
              style="width: 100%">
      <el-table-column prop="date"
                       align="center"
                       width="">
        <template slot="header"
                  slot-scope="scope">
          <div class="tableData-header">
            <!-- <b>{{TeamNameInfo[0]}} &nbsp; &nbsp; &nbsp; &nbsp;VS&nbsp; &nbsp; &nbsp; &nbsp; {{TeamNameInfo[2]}}</b> -->
            <b>{{CoachNameInfo[2]}}
              <i style="margin-left:20px"></i> vs
              <i style="margin-left:20px"></i>{{TeamNameInfo[0]}}</b>
          </div>
        </template>
        <el-table-column prop="date"
                         width="">
          <template slot="header"
                    slot-scope="scope">
            <div class="tableData-xheader">
              <b>
                <span style="margin-left:50px">总：</span>
                <span>{{Win_f}}胜， </span>
                <span>{{flat_f}}平， </span>
                <span>{{load_f}}负 </span>
                <span style="margin-left:80px">
                  <span>其中主场：</span>
                  <span>{{ss}}胜，</span>
                  <span>{{pp}}平，</span>
                  <span>{{ff}}负</span>
                </span>
              </b>
            </div>
          </template>
          <el-table-column prop="matchSeason"
                           label="赛季"
                           align="center"
                           width="170">
            <template slot-scope="scope">
              <span>
                {{scope.row.classname}} ({{scope.row.matchSeason}})
              </span>
            </template>
          </el-table-column>
          <el-table-column prop="matchtime"
                           label="比赛时间"
                           align="center"
                           width="180">
          </el-table-column>
          <el-table-column prop="place"
                           align="center"
                           width=""
                           label="主队">
            <template slot-scope="scope">
              <span class="spspsps">
                <router-link target="_blank"
                             class="span"
                             :to="{name:'lineup',params:{teamID:scope.row.hometeamID}}">
                  {{scope.row.homeName}}
                </router-link>
                <router-link target="_blank"
                             class="span"
                             style="margin-left:20px"
                             v-if="scope.row.homeCoachId"
                             :style="{'color':(scope.row.colors)}"
                             :to="{name:'playerDetails',params:{playerID:scope.row.homeCoachId}}">
                  ({{scope.row.homeCoachName}})
                </router-link>
              </span>
            </template>
          </el-table-column>
          <el-table-column prop="country"
                           align="center"
                           width="50"
                           label="比分">
            <template slot-scope="scope">
              <router-link target="_blank"
                           :to="{name:'history',params:{scheduleID:scope.row.scheduleID}}">
                {{scope.row.homeScore}} - {{scope.row.guestScore}}
              </router-link>
            </template>
          </el-table-column>
          <el-table-column prop="birthday"
                           align="center"
                           width=""
                           label="客队">
            <template slot-scope="scope">
              <span class="spspsps">
                <router-link target="_blank"
                             class="span"
                             :to="{name:'lineup',params:{teamID:scope.row.guestteamID}}">
                  {{scope.row.guestName}}
                </router-link>
                <router-link target="_blank"
                             class="span"
                             style="margin-left:20px"
                             v-if="scope.row.guestCoachId"
                             :style="{'color':(scope.row.colorss)}"
                             :to="{name:'playerDetails',params:{playerID:scope.row.guestCoachId}}">
                  ({{scope.row.guestCoachName}})
                </router-link>
              </span>
            </template>
          </el-table-column>

        </el-table-column>
      </el-table-column>
    </el-table>
  </div>
</template>
<script >
export default {
  data () {
    return {
      guest_list: [],
      home_list: [],
      TeamNameInfo: [],
      CoachNameInfo: [],
      Win: 0,
      flat: 0,
      load: 0,
      Win_f: 0,
      flat_f: 0,
      load_f: 0,
      s: '',
      p: '',
      f: '',
      ss: '',
      pp: '',
      ff: ''

    };
  },
  created () {
    this.onDataList()
    // 标题
    let datas_ss = [sessionStorage.getItem('sclassName'), sessionStorage.getItem('matchSeason')]
    var temp_ss = sessionStorage.getItem("TeamName").split(",")
    document.title = `${temp_ss[0]} vs ${temp_ss[2]} - ${datas_ss[1]}${datas_ss[0]} -  教练对阵球队`
  },
  methods: {
    async onDataList () {
      const res = await this.$http.get(`/soccer/matchInfo/${this.$route.params.scheduleID}/coachAgainstTeam/`);

      this.TeamNameInfo = sessionStorage.getItem('TeamName').split(',')
      this.CoachNameInfo = sessionStorage.getItem('CoachName').split(',')

      var that = this

      let s = [], p = [], f = [], ss = [], pp = [], ff = []
      let Win = [], flat = [], load = [], Win_f = [], flat_f = [], load_f = []

      col_spf(res.data.home_list, this.CoachNameInfo[1], s, p, f, Win, flat, load)
      col_spf(res.data.guest_list, this.CoachNameInfo[3], ss, pp, ff, Win_f, flat_f, load_f)

      this.s = s.length
      this.p = p.length
      this.f = f.length
      this.Win = Win[0]
      this.flat = flat[0]
      this.load = load[0]

      this.ss = ss.length
      this.pp = pp.length
      this.ff = ff.length
      console.log(Win)
      this.Win_f = Win_f[0]
      this.flat_f = flat_f[0]
      this.load_f = load_f[0]



      function col_spf (list, coachId, s, p, f, Win, flat, load) {


        if (list) {
          // let s = [], p = [], f = []
          list.forEach(item => {
            // 主场胜平负、
            if (coachId == item.homeCoachId) {
              if (item.homeScore > item.guestScore) {
                s.push(item)
              } else if (item.homeScore < item.guestScore) {
                f.push(item)
              } else {
                p.push(item)
              }
            }
            item.matchtime = item.matchtime.replace('T', ' ')
            if (item.homeCoachId == coachId) {
              if (item.homeScore > item.guestScore) {
                item.colors = '#ff0000'
              } else if (item.homeScore < item.guestScore) {
                item.colors = '#36F'
              } else {
                item.colors = '#444'
              }
            } else if (item.guestCoachId == coachId) {
              if (item.guestScore > item.homeScore) {
                item.colorss = '#ff0000'
              } else if (item.guestScore < item.homeScore) {
                item.colorss = '#36F'
              } else {
                item.colorss = '#444'
              }
            }
          })
          list.sort(function (a, b) {
            return Date.parse(b.matchtime.replace(/-/g, "/")) - Date.parse(a.matchtime.replace(/-/g, "/"));
          });
          // 胜平负
          Win.push(list.filter(item => {
            return item.colors == '#ff0000' || item.colorss == '#ff0000'
          }).length)
          flat.push(list.filter(item => {
            return item.colors == '#444' || item.colorss == '#444'
          }).length)
          load.push(list.filter(item => {
            return item.colors == '#36F' || item.colorss == '#36F'
          }).length)
          // console.log(Win)

        }

      }
      this.home_list = res.data.home_list
      this.guest_list = res.data.guest_list
    }
  }
}
</script>
<style lang = 'less' scoped >
.span {
  color: #878a90;
  font-weight: 900;
}
.tableData-header {
  font-size: 18px;
  color: rgb(248, 51, 71);
}
.tableData-xheader {
  font-size: 16px;
  color: #409eff;
  b {
    margin: 0 20px;
  }
}
a {
  &:hover {
    color: #409eff;
  }
}
.spspsps {
  font-size: 14px;
  width: 100%;
  line-height: 36px !important;
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>
