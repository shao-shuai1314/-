<template>
  <div class="">
    <h2>我的购买</h2>
    <!-- <button @click="qq">12345</button> -->
    <el-card style="margin-top:10px">
      <div class="">
        尚无购买
      </div>

    </el-card>
  </div>
</template>
<script >
export default {
  data () {
    return {
    };
  },
  methods: {
    qq () {
      // let aa = { "status": 200, "data": { "username": "邵帅测试", "mobile": "15194799065", "email": "", "date_joined": "2020-08-20T14:06:55.099091", "headPortrait": "202081511523422.jpg", "is_editor": true, "QiuGuanBi": 9 } }
      // sessionStorage.setItem("user_g", JSON.stringify(aa));
      // this.$router.push({ name: 'goldpay' });
    }
  }
}
</script>
<style lang = 'less' scoped >
</style>