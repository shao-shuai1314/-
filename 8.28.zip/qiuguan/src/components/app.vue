<template>
  <div class="app_box">

  </div>
</template>
<script >
export default {
  data () {
    return {
    };
  },
  methods: {
  }
}
</script>
<style lang = 'less' scoped >
.app_box {
  width: 100%;
  height: 765px;
  background-color: #fff !important;
  background: url('../assets/appbj.png') no-repeat center;
}
</style>