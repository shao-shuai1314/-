<template>
  <div>赛前分析</div>
</template>
