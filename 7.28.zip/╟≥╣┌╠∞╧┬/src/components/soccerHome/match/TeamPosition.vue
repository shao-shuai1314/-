<template>
  <baidu-map :center="center"
             :zoom="zoom"
             @ready="handler"
             style="height:1080px"
             :scroll-wheel-zoom='true'
             @click="getClickInfo">
  </baidu-map>
</template>
<script>
export default {
  name: 'TestBaiDu',
  data () {
    return {
      zoom: 13,
      center: { lng: 109.45744048529967, lat: 36.49771311230842 },
    }
  },
  methods: {
    handler ({ BMap, map }) {
      var point = new BMap.Point(-0.146155, 51.537118);
      var point1 = new BMap.Point(-2.966320663690567, 53.43880855091014);
      var point2 = new BMap.Point(-1.841006, 52.486797);

      map.centerAndZoom(point, 8)

      var marker = new BMap.Marker(point); // 创建标注
      var marker1 = new BMap.Marker(point1); // 创建标注
      var marker2 = new BMap.Marker(point2); // 创建标注


      // 文本
      var label = new BMap.Label('球队：，球场:'); // 该坐标点显示的文本信息与显示位置
      marker.setLabel(label); // 把文本信息设置到maker上 
      // 以下操作为根据需要默认不显示文本信息，鼠标经过坐标点是显示
      label.setStyle({  // 隐藏坐标点文本信息
        display: "none"
      });
      // 鼠标经过时显示坐标点文本信息
      marker.addEventListener("mouseover", function (e) {
        var label = this.getLabel();
        label.setStyle({
          display: "block"
        });
      });
      // 鼠标离开时隐藏文本信息
      marker.addEventListener("mouseout", function (e) {
        var label = this.getLabel();
        label.setStyle({
          display: "none"
        });
      });



      map.addOverlay(marker); // 将标注添加到地图中
      map.addOverlay(marker1); // 将标注添加到地图中
      map.addOverlay(marker2); // 将标注添加到地图中


      marker.setAnimation(BMAP_ANIMATION_BOUNCE);
      marker1.setAnimation(BMAP_ANIMATION_BOUNCE);


      var circle = new BMap.Circle(point, 6, { strokeColor: 'Red', strokeWeight: 6, strokeOpacity: 1, Color: 'Red', fillColor: '#f03' })
      map.addOverlay(circle)

    },
    getClickInfo (e) {
      console.log(e.point.lng)
      console.log(e.point.lat)
      this.center.lng = e.point.lng
      this.center.lat = e.point.lat
    }
  }
}
</script>